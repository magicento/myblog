<?php
/**
* Joomla/Mambo Community Builder
* @version $Id: admin_language.php 914 2010-03-01 23:26:49Z beat $
* @package Community Builder
* @subpackage Core CB Admin Language file (English)
* @since 1.2.2
* @author Beat
* @copyright (C) 2005 - 2010 www.joomlapolis.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

// ensure this file is being included by a parent file:
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

// This file is intentionally empty: by default, language translation is not needed for English.
// to change backend translations, you can take a look at admin_reference_language.php file.

?>