<?php
// WARNING: No blank line or spaces before the "< ? p h p" above this.

// IMPORTANT: This file should be made in UTF-8 (without BOM) only.
// CB will automatically convert to site's local character set.

/**
* Joomla/Mambo Community Builder
* @version $Id: cbteamplugins_language.php 1149 2010-07-06 14:25:51Z beat $
* @package Community Builder
* @subpackage Default CB-Team Plugins Language file (English)
* @author Beat, Nant and JoomlaJoe
* @copyright (C) www.joomlapolis.com
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

// ensure this file is being included by a parent file:
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

// 1.2 Stable:
// ProfileBook plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'Add Rating to Stats List' => '在统计中显示评分',
'Status Field Rating Label' => '状态信息中的评分字段名称',
'Unistall Mode' => '卸载模式',
'Leave database table and existing items' => '保留数据表及现有留言',
'Remove database table and existing items' => '删除数据表及现有留言',
'Provides each registered user with there own Guestbook like system. Version 1.2 RC is compatible natively with CB 1.2 Stable (and Joomla 1.5.X, Joomla 1.0.x and Mambo 4.5.2 - 4.6.5).' => '本插件的功能是为每一个注册用户提供他/她自己的留言本，从而使其他会员或游客在观看该用户的资料时可以发表留言。<p><h3>技术支持</h3>如果您在使用中遇到问题，欢迎到 <a href="http://www.joomlagate.com/forum/" target="_blank">Joomla! 中文论坛（Joomla! 之门）</a> 发帖讨论。</p><p>中文汉化：<a href="http://www.baijianpeng.com" target="_blank">白建鹏 </a></p><a href="http://www.joomlagate.com/forum/topic-15442/" target="_blank" title="用支付宝向 Joomla之门（joomlagate.com）捐款，鼓励我们汉化更多优秀的 Joomla! 扩展"><img src="http://www.joomlagate.com/images/logo-green.gif" alt="用支付宝向 Joomla之门（joomlagate.com）捐款，鼓励我们汉化更多优秀的 Joomla! 扩展" border="0" /></a>',
'Profile Book' => '留言本',
'Main settings' => '主要设定',
'Entries per Page' => '每页条目数量',
'Sort Order' => '排序',
'Ascending' => '升序',
'Descending' => '降序',
'Enabled features' => '启用的功能',
'Anonymous Entries' => '允许匿名留言',
'Yes, only for not logged-in guests' => '是，仅限未登录游客',
'Yes, also for logged-in users' => '是，已登录会员也允许匿名留言',
'Enable Captcha integration' => '使用验证码保护',
'Enable User Rating' => '允许评分',
'Yes, Optional' => '是，可选',
'Yes, Optional but Remind' => '是，可选，不过要提示',
'Yes, Mandatory' => '是，必须评分',
'Content interpreters' => '内容',
'Show title' => '显示标题',
'Allow Smilies' => '允许使用表情图释',
'Allow BBCode' => '允许使用 BBCode',
'Special BB-codes' => '特殊 BB-code',
'Allow [img] BBCode' => '允许 [img] 按钮',
'Allow [video] BBCode' => '允许 [video] 按钮',
'More features' => '更多功能',
'Enable Gesture' => '启用手势',
'Show editor by default' => '默认显示编辑器',
'Hidden' => '隐藏',
'Visible' => '显示',
'Extra fields' => '额外字段',
'Show name' => '显示姓名',
'Show email' => '显示 email',
'Use Location Field' => '使用位置字段',
'- Select Field -' => '- 选择字段 -',
'Use Web Address Field' => '使用网址字段',
'Web Address Field' => '网址字段',
'Name' => '名称',
'Entry' => '留言',
'Profile Book Description' => '个人留言本介绍',
'Created On: %s' => '发表于: %s',
'Edited By %s On: %s' => '由 %s 在 %s 编辑过',
'<br /><strong>[Notice: </strong><em>Last Edit by Site Moderator</em><strong>]</strong>' => '<br /><strong>[注意： </strong><em>已由管理人员修改过</em><strong>]</strong>',
'Users Feedback:' => '用户反馈：',
'Edited by Site Moderator' => '已由管理人员修改过',
'Comments' => '留言',
'Name' => '名称',
'Email' => 'Email',
'Location' => '位置',
'This user currently doesn\'t have any posts.' => '还没有发表任何内容。',
'User Rating' => '用户评分',
'Web Address' => '网址',
'Submit Entry' => '提交',
'Update Entry' => '更新',
'Enable Profile Entries' => 'Enable Profile Entries',
'Auto Publish' => '自动发布',
'Notify Me' => '通知我',
'Enable visitors to your profile to make comments about you and your profile.' => 'Enable visitors to your profile to make comments about you and your profile.',
'Enable Auto Publish if you want entries submitted to be automatically approved and displayed on your profile.' => 'Enable Auto Publish if you want entries submitted to be automatically approved and displayed on your profile.',
'Enable Notify Me if you would like to receive an email notification each time someone submits an entry.  This is recommended if you are not using the Auto Publish feature.' => 'Enable Notify Me if you would like to receive an email notification each time someone submits an entry.  This is recommended if you are not using the Auto Publish feature.',
'Enable Profile Blog' => '启用日记',
'Enable Profile Wall' => '启用涂鸦墙',
'Enable your blog on your profile.' => 'Enable your blog on your profile.',
'Enable the wall on your profile so yourself and visitors can write on it.' => 'Enable the wall on your profile so yourself and visitors can write on it.',
'Enable Notify Me if you\'d like to receive an email notification each time someone submits an entry. This is recommended if you are not using the Auto Publish feature.' => 'Enable Notify Me if you\'d like to receive an email notification each time someone submits an entry. This is recommended if you are not using the Auto Publish feature.',
'Bold' => '粗体',
'Italic' => '斜体',
'Underline' => '下划线',
'Quote' => '引用',
'Code' => '代码',
'List' => '列表',
'List' => '列表',
'Image' => '图像',
'Link' => '链接',
'Close' => '关闭',
'Color' => '颜色',
'Size' => '字号',
'Item' => '条目',
'Bold text: [b]text[/b]' => '粗体字: [b]text[/b]',
'Italic text: [i]text[/i]' => '斜体字: [i]text[/i]',
'Underline text: [u]text[/u]' => '下划线: [u]text[/u]',
'Quoted text: [quote]text[/quote]' => '引用文字: [quote]text[/quote]',
'Code display: [code]code[/code]' => '代码: [code]code[/code]',
'Unordered List: [ul] [li]text[/li] [/ul] - Hint: a list must contain List Items' => '无序列表: [ul] [li]text[/li] [/ul] - Hint: a list must contain List Items',
'Ordered List: [ol] [li]text[/li] [/ol] - Hint: a list must contain List Items' => '有序列表: [ol] [li]text[/li] [/ol] - Hint: a list must contain List Items',
'Image: [img size=(01-499)]http://www.google.com/images/web_logo_left.gif[/img]' => '图像: [img size=(01-499)]http://www.google.com/images/web_logo_left.gif[/img]',
'Link: [url=http://www.zzz.com/]This is a link[/url]' => '链接: [url=http://www.zzz.com/]This is a link[/url]',
'Close all open bbCode tags' => '关闭全部未闭合的 bbCode 标记',
'Color: [color=#FF6600]text[/color]' => '颜色: [color=#FF6600]text[/color]',
'Size: [size=1]text size[/size] - Hint: sizes range from 1 to 5' => '字号: [size=1]text size[/size] - Hint: sizes range from 1 to 5',
'List Item: [li] list item [/li] - Hint: a list item must be within a [ol] or [ul] List' => '列表条目: [li] list item [/li] - Hint: a list item must be within a [ol] or [ul] List',
'Dimensions' => '尺寸',
'File Types' => '文件类型',
'Submit' => '提交',
'Preview' => '预览',
'Cancel' => '取消',
'User Comments' => '用户评论',
'Your Feedback' => '您的反馈',
'Edit' => '编辑',
'Update' => '更新',
'Delete' => '删除',
'Publish' => '发布',
'Sign Profile Book' => '我要留言',
'Give Feedback' => '发表反馈',
'Edit Feedback' => '编辑反馈',
'Un-Publish' => '取消发布',
'Not Published' => '未发布',
'Color' => '颜色',
'Size' => '大小',
'Very Small' => '很小',
'Small' => '小',
'Normal' => '正常',
'Big' => '大',
'Very Big' => '很大',
'Close All Tags' => '关闭全部标记',
'Standard' => '标准',
'Red' => '红色',
'Purple' => '紫色',
'Blue' => '蓝色',
'Green' => '绿色',
'Yellow' => '黄色',
'Orange' => '橙色',
'Darkblue' => '深蓝',
'Gold' => '金色',
'Brown' => '褐色',
'Silver' => '银色',
'You have received a new entry in your %s' => 'You have received a new entry in your %s',
'%s has just submitted a new entry in your %s.' => '%s has just submitted a new entry in your %s.',
'An entry in your %s has just been updated' => 'An entry in your %s has just been updated',
'%s has just submitted an edited entry for %s in your %s.' => '%s has just submitted an edited entry for %s in your %s.',
"\n\nYour current setting is that you need to review entries in your %1\$s. Please login, review the new entry and publish if you agree. Direct access to your %1\$s:\n%2\$s\n" => "\n\nYour current setting is that you need to review entries in your %1\$s. Please login, review the new entry and publish if you agree. Direct access to your %1\$s:\n%2\$s\n",
"\n\nYour current setting is that new entries in your %1\$s are automatically publihed. To see the new entry, please login. You can then see the new entry and take appropriate action if needed. Direct access to your %1\$s:\n%2\$s\n" => "\n\nYour current setting is that new entries in your %1\$s are automatically publihed. To see the new entry, please login. You can then see the new entry and take appropriate action if needed. Direct access to your %1\$s:\n%2\$s\n",
'Name is Required!' => '必须填写姓名！',
'Email Address is Required!' => '必须填写 Email 地址！',
'Comment is Required!' => '必须填写内容！',
'User Rating is Required!' => '必须评分！',
'You have not selected a User Rating. Do you really want to provide an Entry without User Rating ?' => 'You have not selected a User Rating. Do you really want to provide an Entry without User Rating ?',
'Return Gesture' => '返回手势',
'Profile Rating' => 'Profile Rating',
'You have not selected your User Rating.' => 'You have not selected your User Rating.',
'Would you like to give a User Rating ?' => 'Would you like to give a User Rating ?',
'Do you really want to delete permanently this Comment and associated User Rating ?' => 'Do you really want to delete permanently this Comment and associated User Rating ?',
'You are about to edit somebody else\'s text as a site Moderator. This will be clearly noted. Proceed ?' => 'You are about to edit somebody else\'s text as a site Moderator. This will be clearly noted. Proceed ?',
'Hidden' => 'Hidden',
'Feedback from %s: ' => '来自 %s 的反馈: ',
'Poor' => '差',
'Best' => '很好',
// 1.2:
'Vote %s star' => '评分 %s 星',
'Vote %s stars' => '评分 %s 星',
'Cancel Rating' => '取消评分',
'Average Profile Rating by other users' => 'Average Profile Rating by other users',
// 1.2.1:
'Title' => '标题',
'Title is Required!' => '必须填写标题！',
'NEW' => '新',
'Mark Read' => '标记为已读',
'Mark Unread' => '标记为未读',
'You have %s new %s post' => 'You have %s new %s post',
'You have %s new %s posts' => 'You have %s new %s posts',
'Add new blog entry' => '撰写新日记',
'Wall entry' => '涂鸦墙条目',
'Write on the wall' => '开始涂鸦',
'Entry' => '内容',
'Blog text' => '日记内容',
'Save Blog Entry' => '保存日记',
'Video' => '视频',
'Video: [video type=youtube]id[/video] - Hint: id is only the embedding id of the video' => '视频: [video type=youtube]id[/video] - 提示： id 是指要插入的视频的嵌入 id',
// module:
'%s added a new guestbook entry to %s' => '%s 在 %s 发表了新留言',
'%s wrote a new blog "%s"' => '%s 撰写了新日记 "%s"',
'%s wrote a new blog' => '%s 撰写了新日记',
'%s added a new wall entry to %s' => '%s 在 %s 添加了新涂鸦',
'%s added a new wall entry' => '%s 新增了涂鸦条目',
'No entries have been made!' => '还没有作品发表。',
// 1.2.2:
'Untranslated strings on this page' => '本页未翻译字串',
'Translations on this page' => '本页翻译',
'English string' => '英文字串',
'Translated string' => '翻译字串'
) );

// Profile Gallery plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'CB Profile Gallery' => 'CB Profile Gallery',
'CB Gallery 1.2 RC1 - Provides an all-in-one CB Profile Gallery plugin.' => 'CB Gallery 1.2 RC1 - 本插件的功能是为每一个注册会员在其个人资料页面上提供一个功能完善的相册（图库）系统。<p><h3>技术支持</h3>如果您在使用中遇到问题，欢迎到 <a href="http://www.joomlagate.com/forum/" target="_blank">Joomla! 中文论坛（Joomla! 之门）</a> 发帖讨论。</p><p>中文汉化：<a href="http://www.baijianpeng.com" target="_blank">白建鹏 </a></p><a href="http://www.joomlagate.com/forum/topic-15442/" target="_blank" title="用支付宝向 Joomla之门（joomlagate.com）捐款，鼓励我们汉化更多优秀的 Joomla! 扩展"><img src="http://www.joomlagate.com/images/logo-green.gif" alt="用支付宝向 Joomla之门（joomlagate.com）捐款，鼓励我们汉化更多优秀的 Joomla! 扩展" border="0" /></a>',
'This plugin was created by Nick A. with the (much needed) support of JoomlaJoe and Beat B. Alternative icon set contributed by Rembrandt. ' => '本插件由 Nick A. 开发（在 JoomlaJoe 和 Beat B. 的支持下）。备选图标集由 Rembrandt 提供。',
'This plugin is distributed under a limited GNU/GPL license and cannot be modified to work with anything else outside of the Community Builder suite supported by the Joomlapolis.com site' => '本插件基于 GNU/GPL 许可协议分发，不允许在修改之后用于除 Joomlapolis.com 所开发的 Community Builder 系列软件之外的任何场合。',
'Donations:' => '捐款：',
'Please support further development of this plugin and CB by donating at www.joomlapolis.com' => '欢迎前往  www.joomlapolis.com 网站捐款，以支持本插件以及 CB 的后续开发。',
'Parameters:' => '参数：',
'Please look at the relevant tab for additional parameters' => '参看对应的标签页来设置更多参数',
'Approval Tab Enabled' => '启用审批标签页',
'Moderator Notification' => '通知管理人员',
'This tab contains a basic no-frills image Gallery for CB profiles' => 'This tab contains a basic no-frills image Gallery for CB profiles',
'Current Items' => '当前条目',
'Gallery Automatically Enabled' => '自动启用图库',
'Allow User to Enable' => '允许用户启用',
'Gallery Operations Mode' => '图库运行模式',
'Images' => '图像',
'Files' => '文档',
'Images and Files' => '图像及文档',
'Image File List' => '允许的图片格式',
'Other File List' => '允许的文档格式',
'Sort Option' => '排序方式',
'Older items first' => '旧的在前',
'Newer items first' => '新的在前',
'Public' => '任何人',
'Registered Only' => '仅限注册会员',
'Registered Only - Stealth' => '仅限注册会员 - 隐身模式',
'Connections Only' => '仅限好友',
'Connections Only - Stealth' => '仅限好友 - 隐身模式',
'Allow Access Mode Override' => '允许用户自定义访问权限',
'Allow Moderator FE Uploads' => '允许管理人员代为上传',
'Default (thumbnail)' => '默认（缩略图）',
'Table list' => '表格式列表',
'Thumbnail lightbox' => '缩略图 lightbox',
'Display Format Parameters' => '显示格式参数',
'Allow Display Format Override' => '允许用户自定义显示格式',
'Autopublish' => '自动发布',
'Allow Auto-publish Override' => '允许用户自定义自动发布',
'Auto-approve' => '自动批准',
'Allow Auto-approve Override' => '允许用户自定义自动批准',
'Gallery Button Icons' => '图库按钮',
'Over-ride' => '自定义',
'Gallery Icon List' => '图库按钮',
'Items Quota' => '图片数量限额',
'Maximum width' => '最大宽度',
'Maximum height' => '最大高度',
'Maximum size' => '单个图片最大体积',
'Maximum thumbnail width' => '缩略图最大宽度',
'Maximum thumbnail height' => '缩略图最大高度',
'Storage quota' => '储存空间限额',
'Keeps track of number of stored items' => 'Keeps track of number of stored items',
'Date of last update to Gallery items in this profile' => 'Date of last update to Gallery items in this profile',
'Last Update' => '最后更新',
'Enable Gallery' => '启用相册',
'Select Yes or No to turn-on or off the Gallery Tab' => 'Select Yes or No to turn-on or off the Gallery Tab',
'Short Greeting' => '简短问候',
'Enter a short greeting for your gallery viewers' => 'Enter a short greeting for your gallery viewers',
'Item Quota' => '照片限额',
'The admin may use this to over-ride the default value of allowable items for each profile owner' => 'The admin may use this to over-ride the default value of allowable items for each profile owner',
'No Items published in this profile gallery' => 'No Items published in this profile gallery',
'Title:' => '标题：',
'Description:' => '描述：',
'Image File:' => '图像文件：',
'Submit New Gallery Entry' => '提交新图片',
'Submit Gallery Entry' => '提交图片',
'A file must be selected via the Browse button' => 'A file must be selected via the Browse button',
'A gallery item title must be entered' => 'A gallery item title must be entered',
'Autopublish items' => '自动发布条目',
'Select Yes or No to autopublish or not newly uploaded gallery items' => 'Select Yes or No to autopublish or not newly uploaded gallery items',
'Current Storage' => '当前储存情况',
'This field keeps track of the total size of all uploaded gallery items - like a quota usage field. Value is in bytes.' => 'This field keeps track of the total size of all uploaded gallery items - like a quota usage field. Value is in bytes.',
'Greetings - connections only viewing enabled' => 'Greetings - connections only viewing enabled',
'Sorry - connections only viewing enabled for this gallery that currently has %1$d items in it.' => 'Sorry - connections only viewing enabled for this gallery that currently has %1$d items in it.',
'Automatically approve' => '自动批准',
'This value can be set by the admin to over-ride the gallery plugin backend default approval parameter' => 'This value can be set by the admin to over-ride the gallery plugin backend default approval parameter',
'Storage Quota (KB)' => '储存空间限额(KB)',
'This value can be set by the admin to over-ride the gallery plugin backend default user quota' => 'This value can be set by the admin to over-ride the gallery plugin backend default user quota',
'Maximum allowable single upload size exceeded - gallery item rejected' => 'Maximum allowable single upload size exceeded - gallery item rejected',
'File extension not authorized' => '文件类型不正确',
/**
 * Parameters available for use in _pg_QuotaMessage language string
 * %1$d ~ Total count of items uploaded
 * %2$d ~ Maximum uploaded items allowed
 * %3$d ~ Total KB of uploaded items
 * %4$d ~ Maximum KB of uploaded items allowed
 * %5$d ~ Consumed storage percentage of uploaded items
 * %6$d ~ Free storage percentage of uploaded items
 * %7$d ~ Maximum single upload size
 */
' [Your current quota marks: %1$d/%2$d items %3$d/%4$d Kbytes (%5$d%% consumed - %6$d%% free)]' => ' [Your current quota marks: %1$d/%2$d items %3$d/%4$d Kbytes (%5$d%% consumed - %6$d%% free) - single upload size %7$d Kbytes]',
'This file would cause you to exceed you quota - gallery item rejected' => 'This file would cause you to exceed you quota - gallery item rejected',
'Access Mode' => '访问权限',
'Select desirable access mode: Public access, Registered users only, Connected users only, REG-S for Registered-stealth, CON-S for Connections-stealth' => 'Select desirable access mode: Public access, Registered users only, Connected users only, REG-S for Registered-stealth, CON-S for Connections-stealth',
'Allow Public Access' => '允许游客查看',
'Allow Registered Access' => '允许注册会员查看',
'Allow Connections Access' => '允许好友查看',
'Registered Stealth Access' => '注册会员隐身查看',
'Connections Stealth Access' => '好友隐身查看',
'Display Format' => '显示格式',
'Select Display Format to apply for gallery viewing.' => 'Select Display Format to apply for gallery viewing.',
'Pictures gallery list format' => 'Pictures gallery list format',
'File list format' => '文件列表格式',
'Picture gallery list lightbox format' => 'Picture gallery list lightbox format',
'Gallery repository successfully created!' => 'Gallery repository successfully created!',
'Gallery repository could not be created! Please notify system admin!' => 'Gallery repository could not be created! Please notify system admin!',
'Image ToolBox failure! - Please notify system admin - ' => 'Image ToolBox failure! - Please notify system admin - ',
'The file upload has failed! - Please notify your system admin!' => 'The file upload has failed! - Please notify your system admin!',
/**
 * Parameters available for use in _pg_FileUploadSucceeded and _pg_FileUploadAndTnSucceeded language strings
 * %1$s ~ Name of uploaded file in user repository
 */
'The file %1$s has been successfully uploaded!' => 'The file %1$s has been successfully uploaded!',
'The file %1$s has been successfully uploaded and tn%1$s thumbnail created!' => 'The file %1$s has been successfully uploaded and tn%1$s thumbnail created!',
'Only Registered Members Allowed to view the %1$d items in this Gallery!' => 'Only Registered Members Allowed to view the %1$d items in this Gallery!',
'Delete' => '删除',
'Publish' => '发布',
'Unpublish' => '取消发布',
'Approve' => '批准',
'Revoke' => 'Revoke',
'Default setting' => '默认设定',
'Are you sure you want to delete selected item ? The selected item will be deleted and cannot be undone!' => 'Are you sure you want to delete selected item ? The selected item will be deleted and cannot be undone!',
'Max single upload (KB)' => 'Max single upload (KB)',
'This value can be set by the admin to over-ride the gallery plugin backend default maximum single upload size' => 'This value can be set by the admin to over-ride the gallery plugin backend default maximum single upload size',
'Updated' => '已更新',
'Title' => '标题',
'Description' => '描述',
'Download' => '下载',
'Actions' => '动作',
'Never' => '从不',
'Gallery Moderation' => '图库审核',
'This tab contains all pending autorization gallery items' => 'This tab contains all pending autorization gallery items',
'New Gallery Item just uploaded' => '新图片上传成功',
/**
 * Parameters available for use in _pg_MSGBODY_NEW language string
 * %1\$s ~ item type
 * %2\$s ~ item title
 * %3\$s ~ item description
 * %4\$s ~ username
 * %5\$s ~ profile link
 */
"A new Gallery item has just been uploaded and may require approval.\n"
."This email contains the item details\n\n"
."Gallery Item Type - %1\$s\n"
."Gallery Item Title - %2\$s\n"
."Gallery Item Description - %3\$s\n\n"
."Username - %4\$s\n"
."Profile Link - %5\$s \n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"A new Gallery item has just been uploaded and may require approval.\n"
."This email contains the item details\n\n"
."Gallery Item Type - %1\$s\n"
."Gallery Item Title - %2\$s\n"
."Gallery Item Description - %3\$s\n\n"
."Username - %4\$s\n"
."Profile Link - %5\$s \n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n",

'Your Gallery Item has been approved!' => 'Your Gallery Item has been approved!',

"A Gallery item in your Gallery Tab has just been approved by a moderator.\n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"A Gallery item in your Gallery Tab has just been approved by a moderator.\n\n\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n",

'Your Gallery Item has been revoked!' => 'Your Gallery Item has been revoked!',

"A Gallery item in your Gallery Tab has just been revoked by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"A Gallery item in your Gallery Tab has just been revoked by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n",

'Your Gallery Item has been deleted!' => 'Your Gallery Item has been deleted!',

"A Gallery item in your Gallery Tab has just been deleted by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n"
=>
"A Gallery item in your Gallery Tab has just been deleted by a moderator.\n\n\n"
."If you feel that this action is unjustified please contact one of our moderators.\n"
."Please do not respond to this message as it is automatically generated and is for information purposes only\n",

'Your Gallery item is pending approval by a site moderator.' => 'Your Gallery item is pending approval by a site moderator.',
'Your Gallery item quota has been reached. You must delete an item in order to upload a new one or you may contact the admin to increase your quota.' => 'Your Gallery item quota has been reached. You must delete an item in order to upload a new one or you may contact the admin to increase your quota.',
'Failed to be add index.html to the plugin gallery - please contact administrator!' => 'Failed to be add index.html to the plugin gallery - please contact administrator!',
'No item uploaded!' => '还没有上传照片',
/**
 * Parameters available for use in _pgModeratorViewMessage
 * %1$d ~ Total count of items uploaded
 * %2$d ~ Maximum uploaded items allowed
 * %3$d ~ Total KB of uploaded items
 * %4$d ~ Maximum KB of uploaded items allowed
 * %5$s ~ access mode setting
 * %6$s ~ display format setting
 * %7$s ~ single upload size
 */
'<font color="red">Moderator data:<br />'
.'Items - %1$d<br />'
.'Item Quota - %2$d<br />'
.'Storage - %3$d<br />'
.'Storage Quota - %4$d<br />'
.'Access Mode - %5$s<br />'
.'Display Mode - %6$s<br /></font>'
=>
'<font color="red">Moderator data:<br />'
.'Items - %1$d<br />'
.'Item Quota - %2$d<br />'
.'Storage - %3$d<br />'
.'Storage Quota - %4$d<br />'
.'Access Mode - %5$s<br />'
.'Display Mode - %6$s<br />'
.'Single Upload Size - %7$s<br /></font>',

'Image ' => '图像 ',
' of ' => ' of ',
'Image {x} of {y}' => '第 {x} 张（共 {y} 张）',
/**
 * Following section defines language strings used in CB Gallery Module
 */
'No Viewable Items' => 'No Viewable Items',
'No items rendered' => 'No items rendered',

'Edit Gallery Item' => 'Edit Gallery Item',
'Edit' => '编辑',
'Update' => '更新',

'Bad File - Item rejected' => 'Bad File - Item rejected',
'Not logged on' => 'Not logged on',
'No connected items' => 'No connected items'
) );

// Privacy plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'Visible on profile'					=>	'Visible on profile',
'Only to logged-in users'				=>	'仅针对已登录会员',
'Only for direct connections'			=>	'Only for direct connections',
'Only for %s'							=>	'仅针对 %s',
'Also for connections\' connections'	=>	'同时针对好友的好友',
'Invisible on profile'					=>	'Invisible on profile',
'Access only to logged-in users. Please login.'						=>	'Access only to logged-in users. Please login.',
'Access only to logged-in users. Please login or %s.'				=>	'Access only to logged-in users. Please login or %s.',
'register'															=>	'register',
'Access only with login'											=>	'Access only with login',
'Access only to directly connected users'							=>	'Access only to directly connected users',
'Access only to directly connected users and friends of friends'	=>	'Access only to directly connected users and friends of friends',
));

// Activity plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'%s joined, welcome !'					=>	'%s 加入了，欢迎！',
'%s updated his profile'				=>	'%s 更新了他的个人资料',
'%s updated their profile'				=>	'%s 更新了他们的个人资料',

'%s and %s'								=>	'%s 和 %s',
'%s, %s and %s'							=>	'%s, %s 和 %s'	,
'%s, %s, %s and %s more'				=>	'%s, %s, %s 和 %s 以及更多会员',

'%s and %s are now connected'			=>	'%s 和 %s 现在是好友了',
'%s is now connected to %s'				=>	'%s is now connected to %s',
'%s are now connected to %s'			=>	'%s are now connected to %s',

'%s added a new picture'				=>	'%s 上传了新照片',
'%s added new pictures'					=>	'%s 上传了新照片',
'%s added %s new pictures'				=>	'%s 增加了 %s 张新照片',
'%s commented to %s\'s %s'				=>	'%s commented to %s\'s %s',
'%s rated %s\'s %s'						=>	'%s rated %s\'s %s',
'picture'								=>	'照片',
'pictures'								=>	'照片',
'profile'								=>	'个人资料',

'%s added a new gallery'				=>	'%s 新建了图库',

'%s signed the guestbook of %s'			=>	'%s 在 %s 的留言本上发言了',
'%s wrote on the wall of %s'			=>	'%s 在 %s 的涂鸦墙上发言了',
'%s posted a new note to %s'			=>	'%s posted a new note to %s',
'%s updated a %s in %s'					=>	'%s updated a %s in %s',
'%s updated a %s in %s\'s %s'			=>	'%s updated a %s in %s\'s %s',
'%s updated a %s in the %s'				=>	'%s updated a %s in the %s',

'%s wrote a new %s'						=>	'%s wrote a new %s',
'%s wrote a new %s "%s"'				=>	'%s wrote a new %s "%s"',
'%s replied to %s'						=>	'%s replied to %s',
'%s replied to %s "%s"'					=>	'%s replied to %s "%s"',
'%s edited his %s'						=>	'%s edited his %s',
'forum post'							=>	'论坛帖子',
'comment'								=>	'评论',
'note'									=>	'note',
'tag'									=>	'标签',
'rating'								=>	'评分',

'%s created the group "%s"'				=>	'%s 创建了“%s”这个群组',
'%s joined the group "%s"'				=>	'%s 加入了“%s”这个群组',

'%s subscribed to %s'					=>	'%s 订阅了 %s',
'%s upgraded to %s'						=>	'%s 升级到了 %s',
'%s donated %s'							=>	'%s 捐款 %s',
'%s donated %s, thank you very much'	=>	'%s 捐款 %s，非常感谢',
'%s donated'							=>	'%s 捐款了',
'%s donated, thank you very much'		=>	'%s 捐款了，非常感谢',
'%s purchased something'				=>	'%s 买了一些东西',
'%s purchased something, thank you'		=>	'%s 买了一些东西，谢谢',
'%s purchased a %s'						=>	'%s 买了一个 %s',
'%s purchased a %s, thank you'			=>	'%s 买了一个 %s，谢谢',

));

// Ratings fields plugin: (new method: UTF8 encoding here):
CBTxt::addStrings( array(
'Thank you for rating!'					=>	'感谢您的评分！',
'Click on a star to rate!'				=>	'点击星星图标来评分！',
// Rate 1 Star:
'Rate %s %s'							=>	'Rate %s %s',
'Cancel Rating'							=>	'取消评分',
// following rating strings can be used/changed in field's param
'Self'									=>	'自己',
'Visitor'								=>	'访客',
'Rating'								=>	'评分',
'Star'									=>	'星',
'Stars'									=>	'星',
'Poorest'								=>	'最差',
'Poor'									=>	'差',
'Average'								=>	'一般',
'Good'									=>	'好',
'Better'								=>	'很好',
'Best'									=>	'最好'
));

// Forum integration plugin:
CBTxt::addStrings( array(
'Found %s Forum Posts'					=>	'找到了 %s 个论坛帖子',
'Forum Posts'							=>	'论坛帖子',
'Last %s Forum Posts'					=>	'论坛上最新 %s 个帖子',
'Moderator'								=>	'版主',
'Administrator'							=>	'管理员',
'ONLINE'								=>	'在线',
'OFFLINE'								=>	'离线',
'Online Status: '						=>	'在线状态：',
'View Profile: '						=>	'查看个人资料：',
'Send Private Message: '				=>	'发送站内信：',
'Date'									=>	'日期',
'Subject'								=>	'主题',
'Category'								=>	'类别',
'Hits'									=>	'点击',
'Karma: '								=>	'声望：',
'Posts: '								=>	'帖子：',
'Forum Statistics'						=>	'论坛统计',
'Forum Ranking'							=>	'论坛等级',
'Total Posts'							=>	'帖子总数',
'Karma'									=>	'声望',
'No matching forum posts found.'		=>	'没有找到匹配的论坛帖子。',
'This user has no forum posts.'			=>	'此会员还没有在论坛发帖。',
'Your Subscriptions'					=>	'您的订阅',
'Action'								=>	'操作',
'No subscriptions found for you.'		=>	'没有找到您的订阅。',
'Your Favorites'						=>	'您的收藏',
'No favorites found for you.'			=>	'没有找到您的收藏。',
'Remove'								=>	'移除',
'Remove All'							=>	'移除全部',
'Unsubscribe'							=>	'取消订阅',
'Unsubscribe All'						=>	'全部取消订阅',
'Are you sure you want to unsubscribe from this forum subscription?'				=>	'您确定要取消对这个话题的订阅吗？',
'Are you sure you want to unsubscribe from all your forum subscriptions?'			=>	'您确定要取消全部的论坛订阅吗？',
'Are you sure you want to remove this favorite thread?'								=>	'您确定要移除对这个话题的收藏吗？',
'Are you sure you want to remove all your favorite threads?'						=>	'您确定要取消对话题的全部收藏吗？',
'The forum component is not installed.  Please contact your site administrator.'	=>	'论坛组件还未安装。请与网站管理员联系。',
'Male'									=>	'男',
'Female'								=>	'女'
));

// Facebook integration plugin:
CBTxt::addStrings( array(
'Facebook'									=>	'Facebook',
'Synced from Facebook; do not change here, but at Facebook as: %s'											=>	'Synced from Facebook; do not change here, but at Facebook as: %s',
'Profile Image'								=>	'个人资料照片',
'First, Middle, and Last Name'				=>	'First, Middle, and Last Name',
'First Name'								=>	'名字',
'Last Name'									=>	'姓氏',
'About Me'									=>	'个人简介',
'Activities'								=>	'Activities',
'Birthday'									=>	'生日',
'Favorite Books'							=>	'喜爱的书籍',
'Country'									=>	'国家',
'State'										=>	'省份',
'City'										=>	'城市',
'Zip'										=>	'邮编',
'Interests'									=>	'兴趣爱好',
'Looking For'								=>	'寻找',
'Interested In'								=>	'Interested In',
'Favorite Movies'							=>	'喜爱的电影',
'Favorite Music'							=>	'喜爱的音乐',
'Political View'							=>	'政治立场',
'Favorite Quotes'							=>	'喜爱的名言',
'Relationship Status'						=>	'关系状态',
'Religious Views'							=>	'宗教信仰',
'Sex'										=>	'性别',
'Status'									=>	'状态',
'Favorite TV Shows'							=>	'喜爱的电视节目',
'View Facebook Profile'						=>	'View Facebook Profile',
'Connect this account to your Facebook account'																=>	'Connect this account to your Facebook account',
'Link'										=>	'链接',
'Login with your Facebook account'			=>	'Login with your Facebook account',
'Sign in'									=>	'Sign in',
'Are you sure you want to unlink this account from your Facebook account?'									=>	'Are you sure you want to unlink this account from your Facebook account?',
'Unlink this account from your Facebook account'															=>	'Unlink this account from your Facebook account',
'Unlink'									=>	'Unlink',
'Please change your password from profile edit before unlinking to allow further login after unlinked.'	=>	'Please change your password from profile edit before unlinking to allow further login after unlinked.',
'Please change your email from profile edit before unlinking to allow further login after unlinked.'		=>	'Please change your email from profile edit before unlinking to allow further login after unlinked.',
'Would you like to do this now?'			=>	'Would you like to do this now?',
'Facebook account successfully unlinked!'	=>	'Facebook account successfully unlinked!',
'Facebook account successfully linked!'		=>	'Facebook account successfully linked!',
'Facebook credentials failed to load.'		=>	'Facebook credentials failed to load.',
'Error %s: %s'								=>	'Error %s: %s'
));

// Twitter integration plugin:
CBTxt::addStrings( array(
'Twitter'											=>	'Twitter',
'Synced from Twitter; do not change here, but at Twitter as: '												=>	'Synced from Twitter; do not change here, but at Twitter as: ',
'Picture'											=>	'照片',
'Name'												=>	'名称',
'View Twitter Profile'								=>	'View Twitter Profile',
'Connect this account to your Twitter account'		=>	'Connect this account to your Twitter account',
'Link'												=>	'Link',
'Login with your Twitter account'					=>	'Login with your Twitter account',
'Sign in'											=>	'Sign in',
'Are you sure you want to unlink this account from your Twitter account?'									=>	'Are you sure you want to unlink this account from your Twitter account?',
'Unlink this account from your Twitter account'		=>	'Unlink this account from your Twitter account',
'Unlink'											=>	'Unlink',
'Please change your password from profile edit before unlinking to allow further login after unlinked.'	=>	'Please change your password from profile edit before unlinking to allow further login after unlinked.',
'Please change your email from profile edit before unlinking to allow further login after unlinked.'		=>	'Please change your email from profile edit before unlinking to allow further login after unlinked.',
'Would you like to do this now?'					=>	'Would you like to do this now?',
'Twitter account successfully unlinked!'			=>	'Twitter account successfully unlinked!',
'Twitter account successfully linked!'				=>	'Twitter account successfully linked!',
'Twitter credentials failed to load.'				=>	'Twitter credentials failed to load.'
));

// IMPORTANT WARNING: The closing tag, "?" and ">" has been intentionally omitted - CB works fine without it.
// This was done to avoid errors caused by custom strings being added after the closing tag. ]
// With such tags, always watchout to NOT add any line or space or anything after the "?" and the ">".
