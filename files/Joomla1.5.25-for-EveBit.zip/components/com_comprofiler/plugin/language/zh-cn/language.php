<?php
/*************************************************************
* Joomla Community Builder
* @version $Id: simplified_chinese.php 315 2008-04-01 18:00:00Z baijianpeng&Eric Cheng $
* @package Community Builder
* @subpackage simplified chinese Language file (JianTi ZhongWen)
* @author http://www.joomlagate.com http://www.webtmp.cn
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
*************************************************************/



// ensure this file is being included by a parent file:
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

//Field Labels
DEFINE('_UE_HITS','点击');
DEFINE('_UE_USERNAME','用户名');
DEFINE('_UE_Address','地址');
DEFINE('_UE_City','县/市');
DEFINE('_UE_State','省/州');
DEFINE('_UE_PHONE','电话');
DEFINE('_UE_FAX','传真');
DEFINE('_UE_ZipCode','邮政编码');
DEFINE('_UE_Country','国家');
DEFINE('_UE_Occupation','职业');
DEFINE('_UE_Company','公司');
DEFINE('_UE_Interests','兴趣');
DEFINE('_UE_Birthday','生日');
DEFINE('_UE_AVATAR','图片');
DEFINE('_UE_Website','网站');
DEFINE('_UE_Location','地区');
DEFINE('_UE_EDIT_TITLE','编辑您的详细资料');
DEFINE('_UE_YOUR_NAME','姓名');
DEFINE('_UE_EMAIL','E-Mail');
DEFINE('_UE_UNAME','用户名');
DEFINE('_UE_PASS','密码');
DEFINE('_UE_VPASS','再次输入密码');
DEFINE('_UE_SUBMIT_SUCCESS','提交成功!');
DEFINE('_UE_SUBMIT_SUCCESS_DESC','您的项目已经成功的提交给网站管理员, 将会在审核后发布于网站上.');
DEFINE('_UE_WELCOME','欢迎!');
DEFINE('_UE_WELCOME_DESC','欢迎来到我们网站的用户专区');
DEFINE('_UE_CONF_CHECKED_IN','检查项目目前都已经回存');
DEFINE('_UE_CHECK_TABLE','检查表格');
DEFINE('_UE_CHECKED_IN','回存');
DEFINE('_UE_CHECKED_IN_ITEMS',' 项目');
DEFINE('_UE_PASS_MATCH','密码不相符');
DEFINE('_UE_USERNAME_DESC','设为&quot;是&quot;将允许用户帐号被修改. 如果设为&quot;否&quot;,用户帐号注册后将无法被修改.');
DEFINE('_UE_ALLOW_EMAIL_USERCONTR','用户隐藏 E-mail');
DEFINE('_UE_ALLOW_EMAIL_USERCONTR_DESC','&quot;是&quot;.将允许用户能够于公开的信息中隐藏个人的E-Mail. 注: 这个设定只能够于这个组件之中控制显示 E-Mail!');
DEFINE('_UE_USERAPPROVAL_SUCCESSFUL','用户将成功地被允许!');

//Front End Profile Lables
DEFINE('_UE_MEMBERSINCE','注册日期');
DEFINE('_UE_LASTONLINE','最后登录日期');
DEFINE('_UE_ONLINESTATUS','在线状态');
DEFINE('_UE_ISONLINE','在线');
DEFINE('_UE_ISOFFLINE','离线');
DEFINE('_UE_PROFILE_TITLE',' 个人资料页');
DEFINE('_UE_UPDATEPROFILE','更新您的个人资料');
DEFINE('_UE_UPDATEAVATAR','更新您的照片');
DEFINE('_UE_CONTACT_INFO_HEADER','联系信息');
DEFINE('_UE_ADDITIONAL_INFO_HEADER','额外信息');
DEFINE('_UE_REQUIRED_ERROR','必填字段!');
DEFINE('_UE_FIELD_REQUIRED',' 必填!');
DEFINE('_UE_DELETE_AVATAR','删除图片');

//Administrator Tab Names
DEFINE('_UE_USERPROFILE','用户信息');
DEFINE('_UE_USERLIST','用户列表');
DEFINE('_UE_AVATARS','图片');
DEFINE('_UE_REGISTRATION','注册');
DEFINE('_UE_SUBSCRIPTION','订阅');
DEFINE('_UE_INTEGRATION','整合');

//Administrator Labels
DEFINE('_UE_FIELD_NAME','字段名称');
DEFINE('_UE_EXPLANATION','说明');
DEFINE('_UE_FIELD_EXPLAINATION','决定若是您要这个字段设置为必填字段或者是否显示于会员信息中.');
DEFINE('_UE_CONFIG','设定');
DEFINE('_UE_CONFIG_DESC','修改设定');
DEFINE('_UE_VERSION','您所使用的版本是 ');
DEFINE('_UE_BY','CB 是针对 Joomla 1.0 及 1.5，Mambo 4.5.2 平台的自定义组件，开发者：');
DEFINE('_UE_CURRENT_SETTINGS','目前的设定');
DEFINE('_UE_A_EXPLANATION','说明');
DEFINE('_UE_DISPLAY','显示?');
DEFINE('_UE_REQUIRED','必填?');
DEFINE('_UE_YES','是');
DEFINE('_UE_NO','否');

//Admin Avatar Tab Labels
DEFINE('_UE_AVATAR_DESC','设为&quot;是&quot;, 如果您要让已注册用户可以使用个人图片功能 (透过个人资料管理)');
DEFINE('_UE_AVHEIGHT','最大图片高度');
DEFINE('_UE_AVWIDTH','最大图片宽度');
DEFINE('_UE_AVSIZE','最大图片大小<br/><b>单位: Kb</b>');
DEFINE('_UE_AVATARUPLOAD','允许图片上传');
DEFINE('_UE_AVATARUPLOAD_DESC','设为 &quot;是&quot; 如果您要让已注册用户可以自行上传个人图片.');
DEFINE('_UE_AVATARGALLERY','使用头像图库');
DEFINE('_UE_AVATARGALLERY_DESC','设为 &quot;是&quot; 如果您要让已注册用户可以由图片画廊中选择图像.');
DEFINE('_UE_TNWIDTH','最大缩略图宽度');
DEFINE('_UE_TNHEIGHT','最大缩略图高度');

//Admin User List Tab Labels
DEFINE('_UE_USERLIST_TITLE','用户列表标题');
DEFINE('_UE_USERLIST_TITLE_DESC','用户列表标题');
DEFINE('_UE_LISTVIEW','列表');
DEFINE('_UE_PICTLIST','图片列表');
DEFINE('_UE_PICTDETAIL','图片细节');
DEFINE('_UE_NUM_PER_PAGE','用户每页');
DEFINE('_UE_NUM_PER_PAGE_DESC','每页显示用户数量');
DEFINE('_UE_VIEW_TYPE','显示类型');
DEFINE('_UE_VIEW_TYPE_DESC','显示类型');
DEFINE('_UE_ALLOW_EMAIL','E-Mail 链接');
DEFINE('_UE_ALLOW_EMAIL_DESC','允许 E-Mail 链接. 注: 这个设定只会应用于自定义的 E-Mail 字段中');
DEFINE('_UE_ALLOW_WEBSITE','网站链接');
DEFINE('_UE_ALLOW_WEBSITE_DESC','允许网站链接');
DEFINE('_UE_ALLOW_IM','即时信息链接');
DEFINE('_UE_ALLOW_IM_DESC','允许即时信息链接');
DEFINE('_UE_ALLOW_ONLINESTATUS','在线状态');
DEFINE('_UE_ALLOW_ONLINESTATUS_DESC','显示在线状态');
DEFINE('_UE_ALLOW_EMAIL_DISPLAY_DESC','注: 这个设定只会应用在用户主要的 E-Mail 地址.');
DEFINE('_UE_ALLOW_EMAIL_REPLYTO','Emails 寄出 "从:"');
DEFINE('_UE_ALLOW_EMAIL_REPLYTO_DESC','寄给用户 Email 的范本设定: 寄出者格式: 选择从:<ol>'
		.'<li>"从:" 用户 Email 地址 (没有 "Reply-To:" 字段:<br/>用户收到所有的回信以及错误举报, 获得较好的隐私权)</li>'
		.'<li>"从:" 管理员 Email 地址, 以及 "Reply-To:" 用户 Email 地址:<br/>这是 SPF spam-checking compliant, 但是管理员可能会收到错误的回信</li></ol>');
DEFINE('_UE_A_FROM_USER', '用户地址');
DEFINE('_UE_A_FROM_ADMIN', '管理员, "Reply-To": 用户');

//Admin Moderate Tab labels
DEFINE('_UE_MODERATE','群组管理');
DEFINE('_UE_AVATARUPLOADAPPROVALGROUP','版主群组');
DEFINE('_UE_AVATARUPLOADAPPROVALGROUP_DESC','所选择的群组中的所有用户及其以上都将成为版主.');
DEFINE('_UE_ALLOWUSERREPORTS','允许用户举报');
DEFINE ('_UE_ALLOWUSERREPORTS_DESC','允许用户举报有不当行为的用户给版主.');
DEFINE ('_UE_AVATARUPLOADAPPROVAL','需要上传图片审核');
DEFINE ('_UE_AVATARUPLOADAPPROVAL_DESC','所有经由用户上传的图片皆必须审核通过后才会被显示.');
DEFINE ('_UE_ALLOWUSERPROFILEBANNING_DESC','让板主去预防用户个人资料被公开显示.');
DEFINE ('_UE_ALLOWUSERPROFILEBANNING','允许个人资料禁用');

//Admin Registration tab labels
DEFINE('_UE_NAME_FORMAT','姓名格式');
DEFINE('_UE_DATE_FORMAT','日期格式');
DEFINE('_UE_NAME_FORMAT_DESC','选择您想要显示的 姓名/用户名 字段格式.');
DEFINE('_UE_DATE_FORMAT_DESC','选择您想要显示的 日期 字段格式.');
DEFINE ('_UE_REG_CONFIRMATION_DESC','设为 &quot;是&quot; 系统将在用户注册完成以后发送内附确认链接的 E-Mail 给会员.');
DEFINE ('_UE_REG_CONFIRMATION','需要 E-Mail 确认');
DEFINE ('_UE_REG_ADMIN_APPROVAL','需要管理员批准');
DEFINE ('_UE_REG_ADMIN_APPROVAL_DESC','所有的用户注册都须经由管理员批准');
DEFINE ('_UE_REG_EMAIL_NAME','注册 E-Mail 名称');
DEFINE ('_UE_REG_EMAIL_NAME_DESC','请输入您在发送 Email 时所要显示的名称');
DEFINE ('_UE_REG_EMAIL_FROM','注册 E-Mail 地址');
DEFINE ('_UE_REG_EMAIL_FROM_DESC','当寄信给注册者时您想要显示的 E-Mail 地址');
DEFINE ('_UE_REG_EMAIL_REPLYTO','注册回信的 E-Mail');
DEFINE ('_UE_REG_EMAIL_REPLYTO_DESC','您所要使用的回信 E-Mail 地址');
DEFINE ('_UE_REG_PEND_APPR_MSG','等候批准的 Email');
DEFINE ('_UE_REG_WELCOME_MSG','欢迎加入的 Email');
DEFINE ('_UE_REG_REJECT_MSG','驳回的 E-Mail');
DEFINE ('_UE_REG_PEND_APPR_SUB','等待批准的主题');
DEFINE ('_UE_REG_WELCOME_SUB','欢迎的主题');
DEFINE ('_UE_REG_PEND_APPR_SUB_DESC','等待批准的主题');
DEFINE ('_UE_REG_WELCOME_SUB_DESC','欢迎的主题');
DEFINE ('_UE_REG_REJECT_SUB_DESC','驳回的主题');
DEFINE ('_UE_REG_SIGNATURE','E-Mail 签名');
DEFINE ('_UE_REG_ADMIN_PA_SUB','动作要求! 新的注册用户正等待批准');
DEFINE ('_UE_REG_ADMIN_PA_MSG','一位新的用户已经在 [SITEURL] 注册并且等待批准.\n'
.'这封邮件包含了他们的详细资料\n\n'
.'姓名 - [NAME]\n'
.'E-Mail - [EMAILADDRESS]\n'
.'用户名 - [USERNAME]\n\n\n'
.'请不要回覆这份由系统自动产生出来的信息，因为这只是一份举报用的邮件而已\n');
DEFINE ('_UE_REG_ADMIN_SUB','新用户注册');
DEFINE ('_UE_REG_ADMIN_MSG','一位新用户已经在 [SITEURL] 注册.\n'
.'这封邮件包含了他们的详细资料\n\n'
.'会员名称 - [NAME]\n'
.'E-Mail - [EMAILADDRESS]\n'
.'用户名 - [USERNAME]\n\n\n'
.'请不要回覆这份由系统自动产生出来的信息，因为这只是一份举报用的邮件而已\n');
DEFINE('_UE_REG_EMAIL_TAGS','[NAME] - <b>用户姓名</b><br />'
.'[USERNAME] - 用户名<br />'
.'[DETAILS] - 帐号详细信息譬如 E-Mail 地址、用户名<br />'
.'[PASSWORD] - 用户所选的密码 (只在按下"注册"所寄出的第一封 email)<br />'
.'[CONFIRM] - 如果确认功能已经启动将会加入确认链接<br />'
.'[FIELDNAME] - 这将会把跟此用户相关的值加到要寄出的 Email 地址. 只要在 [ ] 之间加入您想要的资料库字段名称.<br />'
);

//Registration form
DEFINE('_UE_REG_COMPLETE_NOPASS','<div class="componentheading">注册完成!</div>'
.'<p>您的密码已经发送到您所输入的电子邮箱了.</p>'
.'<p>当您收到密码后就可以登录了</p>');
DEFINE('_UE_REG_COMPLETE','<div class="componentheading">注册完成!</div>'
.'<p>您现在可以登录了.</p>');
DEFINE('_UE_REG_COMPLETE_NOPASS_NOAPPR','<div class="componentheading">注册完成!</div>'
.'<p>您的注册资料需要批准. 一旦批准后您的密码将传送到您所输入的 E-Mail 地址.</p>'
.'<p>当您收到批准以及密码后就可以登录了</p>');
DEFINE('_UE_REG_COMPLETE_NOAPPR','<div class="componentheading">注册完成!</div>'
.'<p>您的注册资料需要批准. 一旦批准后您将会收到一份已接受的通知信到您所输入的 Email 地址.</p>'
.'<p>当您收到批准后就可以登录了.</p>');
DEFINE('_UE_REG_COMPLETE_CONF','<div class="componentheading">注册完成!</div>'
.'<p>一封告知您如何完成您注册手续的邮件已经发送到您提供的电子邮件地址. 请检查您的电子邮件来完成您的注册.</p>'
.'<p>请检查您的信箱(包括“垃圾邮件”目录) 来完成注册过程.</p>'
.'<p>如果想让系统再次发送激活邮件，只需尝试用你的用户名和密码登录一下即可。</p>');
DEFINE('_UE_REG_COMPLETE_NOPASS_CONF','<div class="componentheading">注册完成!</div>'
.'<p>您的密码已经传送到您所输入的 E-Mail 中.</p>'
.'<p>请检查您的信箱(包括“垃圾邮件”目录) ，当您收到您的密码和遵照注册确认指示就可以进行登录.</p>');

// User List Labels
DEFINE ('_UE_HAS','已拥有');
DEFINE ('_UE_USERS','个注册用户');
DEFINE ('_UE_SEARCH_ALERT','请输入一个值来搜索!');
DEFINE ('_UE_SEARCH','寻找用户');
DEFINE ('_UE_ENTER_EMAIL','输入用户 E-Mail, 姓名或用户名');
DEFINE ('_UE_SEARCH_BUTTON','搜索');
DEFINE ('_UE_SHOW_ALL','显示所有用户');
DEFINE ('_UE_NAME','姓名');
DEFINE ('_UE_UL_USERNAME','用户名');
DEFINE ('_UE_USERTYPE','用户类型');
DEFINE ('_UE_VIEWPROFILE','查看个人资料');
DEFINE ('_UE_LIST_ALL','列出所有');
DEFINE ('_UE_PAGE','页');
DEFINE ('_UE_RESULTS','结果');
DEFINE ('_UE_OF_TOTAL','共计');
DEFINE ('_UE_NO_RESULTS','没有结果');
DEFINE ('_UE_FIRST_PAGE','最前页');
DEFINE ('_UE_PREV_PAGE','上一页');
DEFINE ('_UE_NEXT_PAGE','下一页');
DEFINE ('_UE_END_PAGE','最后页');
DEFINE('_UE_CONTACT','联系');
DEFINE('_UE_INSTANT_MESSAGE','即时信息');
DEFINE('_UE_IMAGEAVAILABLE','照片');
DEFINE('_UE_INFO','信息');
DEFINE('_UE_PROFILE','个人资料');
DEFINE('_UE_PRIVATE_MESSAGE','站内信');
DEFINE('_UE_ADDITIONAL','额外信息');
DEFINE('_UE_NO_DATA','没有提供');
DEFINE('_UE_CLICKTOVIEW','点击前往');
DEFINE('_UE_CLICKTOSORTBY','点击使用 %s 为排序');		// %s replaced by sorting name
DEFINE('_UE_UL_USERNAME_NAME','用户名(姓名)');

//mod_userextraslogin
DEFINE('_UE_NO_ACCOUNT','尚无帐号?');
DEFINE('_UE_CREATE_ACCOUNT','建立一个');
DEFINE('_UE_REGISTER','注册');
DEFINE('_UE_FORGOT_PASSWORD','忘记密码?');
DEFINE('_LOGIN_NOT_CONFIRMED','您的注册程序尚未完成! 请检查您的 E-Mail 观看刚刚重寄的更进一步的指示. 如您未发现信件, 请检查您的垃圾邮件目录. 并请确定您的电子信箱帐号不会马上删除垃圾信. 如果已经发生了, 就重新再尝试登录以获得另一封新的指示信件');
DEFINE('_LOGIN_NOT_APPROVED','您的帐号尚未被批准!');
DEFINE('_UE_USER_CONFIRMED','您的帐号目前已经启用, 您可以进行登录!');
DEFINE('_UE_USER_NOTCONFIRMED','您的帐号目前尚未启动, 请检查您的 E-Mail 并遵循指示来完成您的注册程序.');


//Avatar
DEFINE('_UE_UPLOAD_UPLOAD','上传');
DEFINE('_UE_UPLOAD_SUBMIT','提交一张新照片来上传');
DEFINE('_UE_UPLOAD_SELECT_FILE','选择文件');
DEFINE('_UE_UPLOAD_ERROR_TYPE','请只使用 jpeg, jpg 或者 png 格式图片');
DEFINE('_UE_UPLOAD_ERROR_EMPTY','上传前请先选择一个文件');
DEFINE('_UE_UPLOAD_ERROR_NAME','图片档名仅能包含英文字母或数字且不能有空格.');
DEFINE('_UE_UPLOAD_ERROR_SIZE','图档大小超出了管理员所设置的最大值.');
DEFINE('_UE_UPLOAD_ERROR_WIDTHHEIGHT','图片的高度或宽度超出了管理员所设置的最大值.');
DEFINE('_UE_UPLOAD_ERROR_WIDTH','图档的宽度超出了管理员所设置的最大值.');
DEFINE('_UE_UPLOAD_ERROR_HEIGHT','图档的高度超出了管理员所设置的最大值.');
DEFINE('_UE_UPLOAD_ERROR_CHOOSE','您尚未由艺廊中选择一个图片...');
DEFINE('_UE_UPLOAD_UPLOADED','您的照片已经上传.');
DEFINE('_UE_UPLOAD_GALLERY','由图片库中选择一个');
DEFINE('_UE_UPLOAD_CHOOSE','确认选择');
DEFINE('_UE_UPLOAD_UPDATED','您的照片已被设置.');
DEFINE('_UE_USER_PROFILE_NOT','您的个人资料无法被更新.');
DEFINE('_UE_USER_PROFILE_UPDATED','您的个人资料已经更新.');
DEFINE('_UE_USER_RETURN_A','如果您在几秒内未被带回个人资料页面');
DEFINE('_UE_USER_RETURN_B','点击这里');
//DEFINE('_UPDATE','更新');

//Moderator
DEFINE('_UE_USERPROFILEBANNED','这个个人资料已经遭到版主禁用.');
DEFINE('_UE_REQUESTUNBANPROFILE','请求取消禁用');
DEFINE('_UE_REPORTUSER','举报用户');
DEFINE('_UE_BANPROFILE','禁用个人资料');
DEFINE('_UE_UNBANPROFILE','取消禁用个人资料');
DEFINE('_UE_REPORTUSER_TITLE','举报用户');
DEFINE('_UE_USERREASON','举报用户的原因');
DEFINE('_UE_BANREASON','禁用的原因');
DEFINE('_UE_SUBMITFORM','提交');
DEFINE('_UE_NOUNBANREQUESTS','没有取消禁用的请求需要处理');
DEFINE('_UE_IMAGE_MODERATE','管理图片');
DEFINE('_UE_APPROVE_IMAGE','批准图片');
DEFINE('_UE_REJECT_IMAGE','驳回图片');
DEFINE('_UE_MODERATE_TITLE','版主');
DEFINE('_UE_NOIMAGESTOAPPROVE','没有图片需要处理');
DEFINE('_UE_USERREPORT_MODERATE','管理用户举报');
DEFINE('_UE_REPORT','举报');
DEFINE('_UE_REPORTEDONDATE','举报日期');
DEFINE('_UE_REPORTEDUSER','举报用户');
DEFINE('_UE_REPORTEDBY','举报由');
DEFINE('_UE_PROCESSUSERREPORT','处理');
DEFINE('_UE_NONEWUSERREPORTS','没有新的用户举报');
DEFINE('_UE_USERUNBAN_SUCCESSFUL','成功地取消被禁用的用户个人资料.');
DEFINE('_UE_REPORTUSERSACTIVITY','描述用户活动');
DEFINE('_UE_USERREPORT_SUCCESSFUL','用户举报成功地提交了.');
DEFINE('_UE_USERBAN_SUCCESSFUL','用户个人资料成功地被禁用.');
DEFINE('_UE_FUNCTIONALITY_DISABLED','此项功能目前停用中.');
DEFINE('_UE_UPLOAD_PEND_APPROVAL','您的照片目前等待版主批准中.');
DEFINE('_UE_UPLOAD_SUCCESSFUL','您的照片已成功上传.');
DEFINE('_UE_UNBANREQUEST','取消禁用个人资料请求');
DEFINE('_UE_USERUNBANREQUEST_SUCCESSFUL','您取消禁用的要求已经成功地提交.');
DEFINE('_UE_USERREPORT','用户举报');
DEFINE('_UE_VIEWUSERREPORTS','查看用户举报');
DEFINE('_UE_USERREQUESTRESPONSE','查看用户举报');
DEFINE('_UE_MODERATORREQUESTRESPONSE','查看用户举报');
DEFINE('_UE_REPORTBAN_TITLE','禁用报告');
DEFINE('_UE_REPORTUNBAN_TITLE','禁用报告');

DEFINE('_UE_UNBANREQUIREACTION',' 取消禁用请求');
DEFINE('_UE_USERREPORTSREQUIREACTION','用户举报');
DEFINE('_UE_IMAGESREQUIREACTION','图片');
DEFINE('_UE_NOACTIONREQUIRED','没有等待处理中的事件');

DEFINE('_UE_UNBAN_MODERATE','取消禁用个人资料请求');
DEFINE('_UE_BANNEDUSER','遭禁用用户');
DEFINE('_UE_BANNEDREASON','禁用原因');
DEFINE('_UE_BANNEDON','禁用日期');
DEFINE('_UE_BANNEDBY','禁用由');

DEFINE('_UE_MODERATORBANRESPONSE','版主回应');
DEFINE('_UE_USERBANRESPONSE','用户回应');

DEFINE('_UE_IMAGE_ADMIN_SUB','图片等待批准中');
DEFINE('_UE_IMAGE_ADMIN_MSG','一位用户已提交图片等待批准. 请登录进行适当的处理.');
DEFINE('_UE_USERREPORT_SUB','用户举报等待检阅中');
DEFINE('_UE_USERREPORT_MSG','有一位用户提交了关于另一位用户的举报且需要您的检阅. 请登录进行适当的处里.');
DEFINE('_UE_IMAGEAPPROVED_SUB','图片已批准');
DEFINE('_UE_IMAGEAPPROVED_MSG','您的照片已经被版主批准了');
DEFINE('_UE_IMAGEREJECTED_SUB','图片驳回');
DEFINE('_UE_IMAGEREJECTED_MSG','您的照片已经被版主给驳回了. 请登录并提交一个新的图片.');
DEFINE('_UE_BANUSER_SUB','用户个人资料已禁用.');
DEFINE('_UE_BANUSER_MSG','您的用户个人资料已遭到管理员禁用,请登录并检阅遭禁用的原因.');
DEFINE('_UE_UNBANUSER_SUB','用户个人资料已取消禁用');
DEFINE('_UE_UNBANUSER_MSG','您的用户个人资料已被管理员取消禁用了. 您的个人资料目前可以再给所有用户观看.');
DEFINE('_UE_UNBANUSERREQUEST_SUB','取消禁用请求等待检阅中');
DEFINE('_UE_UNBANUSERREQUEST_MSG','一位用户提出取消禁用个人资料的申请. 请登录进行适当的处里.');


//Alpha 3 Build
DEFINE('_UE_IMAGE','缩略图');
DEFINE('_UE_FORMATNAME','名称格式');

//Alpha 4 Build
DEFINE('_UE_ADMINREQUIREDFIELDS','管理员必须的字段');
DEFINE('_UE_ADMINREQUIREDFIELDS_DESC','设为是可以让管理员遵守用户管理字段的必要设定.设为否将在管理员的用户管理忽略必须的状态.');
DEFINE('_UE_CANCEL','取消');
DEFINE('_UE_NA','N/A');
DEFINE('_UE_MODERATOREMAIL','发送 E-Mail 给版主');
DEFINE('_UE_MODERATOREMAIL_DESC','设为是则当发生需要版主注意时版主将收到email.');

//Beta 1 Build
DEFINE('_UE_UPDATE','更新');

//Beta 2 Build
DEFINE('_UE_FIELDONPROFILE','此字段在个人资料可见');
DEFINE('_UE_FIELDNOPROFILE','此字段在个人资料不可见');
DEFINE('_UE_FIELDREQUIRED','此字段必填');
DEFINE('_UE_NOT_AUTHORIZED','您没有权限观看此页面的内容!');
DEFINE('_UE_ALLOW_LISTVIEWBY','允许存取到:');
DEFINE('_UE_ALLOW_LISTVIEWBY_DESC','选择一个您想要观看列表的群组. 此等级的所有用户或等级更高的都可以存取.');
DEFINE('_UE_ALLOW_PROFILEVIEWBY','允许群取到:');
DEFINE('_UE_ALLOW_PROFILEVIEWBY_DESC','选择一个您想要看个人资料的群组. 此等级的所有用户或等级更高的都可以存取.');

//Beta 3 Build
DEFINE('_UE_NOLISTFOUND','没有已发布的用户列表!');
DEFINE('_UE_ALLOW_PROFILELINK','允许链接至用户资料');
DEFINE('_UE_ALLOW_PROFILELINK_DESC','设为是可允许列表中用户资料链接至该用户个人资料页面,设为否, 则可防止链接到个人资料.');
DEFINE('_UE_REGISTERFORPROFILE','请登录或注册来查看或修改您的个人资料.');
DEFINE('_UE_UPLOAD_ERROR_GDNOTINSTALLED','GD2 Image Library 并非安装或是架构在 PHP 系统之中!  请联系您的系统管理员来关闭自动转存图片尺寸的功能.');
DEFINE('_UE_UPLOAD_ERROR_UPLOADFAILED','上传/处理图片时发生错误!');
DEFINE('_UE_TOC','同意服务条款与声明');
DEFINE('_UE_TOC_REQUIRED','您进行注册前必须同意服务条款与声明!');
DEFINE('_UE_REG_TOC_MSG','启用注册服务条款与声明');
DEFINE('_UE_REG_TOC_DESC','设为是则用户必须同意服务条款与声明后才能够进行注册!');
DEFINE('_UE_REG_TOC_URL_MSG','服务条款与声明链接网址');
DEFINE('_UE_REG_TOC_URL_DESC','输入服务条款与声明的网址.');
DEFINE('_UE_LASTUPDATEDON','最后更新');

//Beta 4 Build
DEFINE('_UE_EMAILFORMWARNING','重要:<ol>'
		.'<li>您个人资料的 email 地址是: <strong>%s</strong>.</li>'
		.'<li>请确认地址无误还有您的阻挡垃圾信设定, 因为收信人将使用该地址来回信.</li>'
		.'<li>请注意信件可能无法寄达因为收信者的 email 还有阻挡垃圾信设定.</li>'
		.'</ol>');
DEFINE('_UE_EMAILFORMSUBJECT','主题:');
DEFINE('_UE_EMAILFORMMESSAGE','信息:');
DEFINE('_UE_EMAILFORMTITLE','给用户 %s 发送邮件');
DEFINE('_UE_GENERAL','一般');
DEFINE('_UE_SENDEMAILNOTICE',"------注意: ------\r\n\r\n此信息是由 %s 在 %s ( %s )发送给您. \r\n\r\n该用户无法得知您的E-Mail. 直接回信收信者将知道您的 E-Mail 地址.");
DEFINE('_UE_SENDEMAILNOTICE_REPLYTO',"\r\n\r\n回信时, 请小心确认 %s 的 email 地址是 %s.");
DEFINE('_UE_SENDEMAILNOTICE_DISCLAIMER',"\r\n\r\n%s 所有者对于 email 的内容以及用户的 email 地址无法负责.");
DEFINE('_UE_SENDEMAILNOTICE_MESSAGEHEADER',"\r\n\r\n\r\n------ 信息从 %s 给您: ------\r\n\r\n");
DEFINE('_UE_SENDPMSNOTICE','注: 此信息是由连线系统自动产生. 里面有要连接的用户的地址, 如果您要可以让您更方便的回信.');
DEFINE('_UE_SENDEMAIL','发送 E-Mail');
DEFINE('_UE_SENTEMAILSUCCESS','您的 E-Mail已成功发送!');
DEFINE('_UE_SENTEMAILFAILED','发送您的 E-Mail失败! 请再试一次.');
DEFINE('_UE_ALLOW_EMAIL_DISPLAY','E-Mail 处理中');
DEFINE('_UE_REGISTERDATE','注册日期');
DEFINE('_UE_ACTION','执行');
DEFINE('_UE_USER','用户');
DEFINE('_UE_USERAPPROVAL_MODERATE','用户 批准/驳回');
DEFINE('_UE_USERPENDAPPRACTION','用户');
DEFINE('_UE_APPROVEUSER','处理用户');
DEFINE('_UE_REG_REJECT_SUB','您的注册申请已经被驳回!');
DEFINE('_UE_USERREJECT_MSG',"您的注册申请在 %s 已经被驳回, 以下为原因: \n%s");
DEFINE('_UE_COMMENT','拒绝注解');
DEFINE('_UE_APPROVE','批准');
DEFINE('_UE_REJECT','拒绝');
DEFINE('_UE_USERREJECT_SUCCESSFUL','用户已成功被拒绝!');
DEFINE('_UE_USERAPPROVE_SUCCESSFUL','用户已成功被批准!');
DEFINE('_LOGIN_REJECTED','您的注册要求已经被拒绝!');
DEFINE('_UE_EMAILFOOTER','注: 这是来自于 %s (%s) 自动地产生的信息.');
DEFINE('_UE_MODERATORUSERAPPOVAL','版主批准用户');
DEFINE('_UE_MODERATORUSERAPPOVAL_DESC','此设定允许版主于网站前台批准等待中的用户.');
DEFINE('_UE_REG_COMPLETE_NOAPPR_CONF','<div class="componentheading">注册完成!</div>'
.'<p>您的注册申请需要批准以及 E-Mail 确认. 请依照发送给您的 E-Mail 中的确认步骤.一旦批准您将从您所输入的 e-mail 地址收到接受通知.</p>'
.'<p>当您收到批准后您就可以登录.</p>');
DEFINE('_UE_REG_COMPLETE_NOPASS_NOAPPR_CONF','<div class="componentheading">注册完成!</div>'
.'<p>您的注册申请需要批准以及 E-Mail 确认. 请依照发送给您的 E-Mail 中的确认步骤. </p>'
.'<p>当您收到批准后将会寄给您密码, 您就可以登录了.</p>');
DEFINE('_UE_NAME_STYLE','姓名格式');
DEFINE('_UE_NAME_STYLE_DESC','此姓名格式说明您如何从 Joomla/Mambo 中的姓名字段撷取.');
DEFINE('_UE_USER_CONFIRMED_NEEDAPPR','感谢您确认您的 E-Mail 地址. 您的帐号需要版主批准. 您将收到 E-Mail 得知申请的结果.');
DEFINE('_UE_YOUR_FNAME','名');
DEFINE('_UE_YOUR_MNAME','中间名');
DEFINE('_UE_YOUR_LNAME','姓');

//RC 1 Build
DEFINE('_UE_NOSELFEMAIL','不允许您发送 E-Mail 给自己!');
DEFINE('_UE_PROFILETAB','个人资料');
DEFINE('_UE_AUTHORTAB','文章');
DEFINE('_UE_FORUMTAB','论坛');
DEFINE('_UE_BLOGTAB','Blog');
DEFINE('_UE_ARTICLEDATE','日期');
DEFINE('_UE_ARTICLETITLE','标题');
DEFINE('_UE_ARTICLERATING','评分');
DEFINE('_UE_ARTICLEHITS','点击');
DEFINE('_UE_NESTTABS','嵌套表格');
DEFINE('_UE_NESTTABS_DESC','所有的表格资料都置入同一个个人资料面板中, 当有大量的表格时这将很有用.');
DEFINE('_UE_MENUFORMATBAR','功能表列');
DEFINE('_UE_MENUFORMATLIST','菜单列表');
DEFINE('_UE_MENUFORMAT','菜单表示');
DEFINE('_UE_MENUFORMAT_DESC','选择贯穿整个 Community Builder 的表示菜单的方式.');
DEFINE('_UE_TEMPLATEDIR','Community Builder 模版');
DEFINE('_UE_TEMPLATEDIR_DESC','选择一种模版套用在Community Builder 中的表格, 工具图标, 面板以及菜单.'
.'您可以使用 Community Builder 外挂管理来增加您的或其他人的模板.');
DEFINE('_UE_MINHITSINTV','最小点击间隔 (分)');
DEFINE('_UE_MINHITSINTV_DESC','对用户及其个人资料设定最小的时间间隔来统计查看以及点击的次数. 预设为60分钟 (一小时).');
DEFINE('_UE_XHTMLCOMPLY','W3C XHTML 1.0 Trans. 规范');
DEFINE('_UE_XHTMLCOMPLY_DESC','在某些 Joomla/Mambo 的模板中并不包含必要的声明( &lt;?php mosShowHead(); ?&gt; ),'
.'这个设定是非必需的. 您可以检查您模板中的 index.php 文件或是迳自开启看看是否会在个人资料表格中显示.'
.'在目前释出的版本, 我们相容于 W3C XHTML 的规范, 但是只有几个页面能够完全符合.'
.'当然,您必须使用符合于 Joomla/Mambo 的模块规范才能够有效的相容');
DEFINE('_UE_MAMBLOGNOTINSTALLED','Mamblog blogger 组件尚未安装.  请联系您的网站管理员.');
DEFINE('_UE_BLOGDATE','日期');
DEFINE('_UE_BLOGTITLE','标题');
DEFINE('_UE_BLOGHITS','点击');
DEFINE('_UE_NOBLOGS','此用户没有已发布的博客文章.');
DEFINE('_UE_NOARTICLES','此用户没有已发布的文章.');
DEFINE('_UE_IMPATH','ImageMagick 路径');
DEFINE('_UE_IMPATH_DESC','ImageMagick 路径');
DEFINE('_UE_NETPBMPATH','NetPBM 路径');
DEFINE('_UE_NETPBMPATH_DESC','NetPBM 路径');
DEFINE('_UE_AUTODET','自动侦测');
DEFINE('_UE_ERROR_NOTINSTALLED','尚未安装');
DEFINE('_UE_CONVERSIONTYPE','图片软体');
DEFINE('_UE_NEWPASS_FAILED','密码重设失败!');
DEFINE('_UE_USER_SUBSCRIPTIONS','您的订阅');
DEFINE('_UE_THREAD_UNSUBSCRIBE',':: 取消订阅 ::');
DEFINE('_UE_USER_NOSUBSCRIPTIONS','没有找到您的订阅');
DEFINE('_UE_GEN_BY','由');
DEFINE('_UE_USER_UNSUBSCRIBE_ALL','取消所有订阅');
DEFINE('_UE_USERREPORTMODERATED_SUCCESSFUL','用户举报管理成功!');
DEFINE('_UE_USERIMAGEMODERATED_SUCCESSFUL','用户图片管理成功!');
DEFINE('_UE_NOREPORTSTOPROCESS','没有需处理的用户举报');
DEFINE('_UE_NOUSERSPENDING','没有用户等待批准');
DEFINE('_UE_BLANK','');
DEFINE('_UE_REG_FIRST_VISIT_URL_MSG','初次登录所浏览的网址');
DEFINE('_UE_REG_FIRST_VISIT_URL_DESC','输入注册之后初次登录所显示的页面的网址. 这个页面可以显示你网站的欢迎新用户的信息
以及/或特别的注意事项, 或是重新导向用户前往完成他的个人资料填写,
留下空白则代表第一次登录与平时登录相同. 显示用户个人资料的页面网址是
index.php?option=com_comprofiler&Itemid=1 (请将 Itemid=1 中的 ID 号替换你网站的真实菜单 ID).
');
DEFINE('_UE_NOSUCHPROFILE','此个人资料不存在或是已经无法使用');

//RC 2
DEFINE('_UE_REG_INTRO_MSG','注册时的介绍文字');
DEFINE('_UE_REG_INTRO_DESC','输入 文字/html 显示在注册页面的最上方'
.'或所属的语系像是在 _UE_WELCOME_DESC 的文字设定. '
.'这个字段的用途可以包含鼓励新会员注册以及所要注意的事项或是特殊的规定'
.'空白时将不会显示任何内容.');
DEFINE('_UE_REG_CONCLUSION_MSG','注册时结尾说明文字');
DEFINE('_UE_REG_CONCLUSION_DESC','输入 文字/html 显示于注册页面底下 '
.'或所属的语言文件是在 _UE_WELCOME_DESC 的文字设定. '
.'这个字段可以包含一个感谢或是特别的简介. '
.'空白时将不会显示任何内容.');
DEFINE('_UE_USER_NOT_APPROVED','这个用户尚未由版主批准!');
DEFINE('_UE_USER_NOT_CONFIRMED','这个用户尚未确认他的 E-Mail 地址和帐号!');
//Connections
DEFINE('_UE_ADDCONNECTION','新增连线');
DEFINE('_UE_REMOVECONNECTION','移除连线');
DEFINE('_UE_CONNECTION','连线');
DEFINE('_UE_CONNECTIONACCEPTSUCCESSFULL','接受连线成功!');
DEFINE('_UE_CONNECTIONREMOVESUCCESSFULL','移除连线成功!');
DEFINE('_UE_CONNECTIONADDSUCCESSFULL','新增连线成功!');
DEFINE('_UE_CONNECTIONPENDINGACCEPTANCE','连线等待接收中!');
DEFINE('_UE_DIRECTCONNECTIONPENDINGACCEPTANCE','与 %s 的直接连线等待接受中!');
DEFINE('_UE_NOCONNECTIONS','此用户目前尚无连线.');
DEFINE('_UE_NODIRECTCONNECTION','没有直接连线.');
DEFINE('_UE_ACCEPTCONNECTION','接受连线');
DEFINE('_UE_CONNECTIONPENDING','连线等待中');
DEFINE('_UE_CONNECTEDSINCE','已连线自从');
DEFINE('_UE_CONNECTEDCOMMENT','注解');
DEFINE('_UE_CONNECTEDDETAIL','连线细节');
DEFINE('_UE_CONNECTIONREQUESTDETAIL','连线请求细节');
DEFINE('_UE_CONNECTIONREQUIREDON','要求连线于');
DEFINE('_UE_DECLINECONNECTION','拒绝连线');
DEFINE('_UE_FIELDDESCRIPTION','字段叙述: 当鼠标滑过图标');
DEFINE('_UE_WEBURL','网站网址');
DEFINE('_UE_WEBTEXT','网站名称');
DEFINE('_UE_CONNECTIONTYPE','类型');
DEFINE('_UE_CONNECTIONCOMMENT','注解');
DEFINE('_UE_CONNECTIONSUPDATEDSUCCESSFULL','您的连线已成功更新!');
DEFINE('_UE_MANAGECONNECTIONS','管理连线');
DEFINE('_UE_MANAGEACTIONS','管理运作');
DEFINE('_UE_CONNECTIONACTIONSSUCCESSFULL','连线运作成功!');
DEFINE('_UE_ALLOWCONNECTIONS','启用连线');
DEFINE('_UE_ALLOWCONNECTIONS_DESC','启用这个功能将允许您的用户跟其他人连线. 就类似是建立好友名单系统.');
DEFINE('_UE_USEMUTUALCONNECTIONACCEPTANCE','互相同意');
DEFINE('_UE_USEMUTUALCONNECTIONACCEPTANCE_DESC','启用这个功能将使两照双方同意连线之后才能建立正式连线.');
DEFINE('_UE_CONNECTOINNOTIFYTYPE','告知 &amp; 告知方法');
DEFINE('_UE_CONNECTOINNOTIFYTYPE_DESC','选择您在连线工作流程的连线告知跟用户接收告知的方式.');
DEFINE('_UE_AUTOADDCONNECTIONS','交互连线');
DEFINE('_UE_AUTOADDCONNECTIONS_DESC','启用这个功能将可以直接建立双方的连线而不是只有请求的一方.');
DEFINE('_UE_CONNECTIONCATEGORIES','连线类型');
DEFINE('_UE_CONNECTIONCATEGORIES_DESC','输入一个类型列表让您的用户之后可以分类他们的连线. 每个类型之后请按 enter.');
DEFINE('_UE_CONNECTIONMADESUB','%s 已与您连线!');
DEFINE('_UE_CONNECTIONMADEMSG','%s 已跟您建立一个连线.');
DEFINE('_UE_CONNECTIONMSGPREFIX',"  %s 包含以下的个人资料:\n\n%s");
DEFINE('_UE_CONNECTIONMESSAGE',"包含个人资料");
DEFINE('_UE_CONNECTIONPENDSUB','您有一个从 %s 来的等待连线!');
DEFINE('_UE_CONNECTIONPENDMSG','%s 要求跟您连线并且等待您的同意. 请选择接受或拒绝连线要求.');
DEFINE('_UE_CONNECTTO','连线至 %s');
DEFINE('_UE_CONNECTEDWITH','管理我的连线');
DEFINE('_UE_NOCONNECTEDWITH','目前没有用户与您连线.');
DEFINE('_UE_CONNECTIONDENIED_SUB','请求连线被拒绝');
DEFINE('_UE_CONNECTIONDENIED_MSG','您请求与 %s 连线遭到拒绝!');
DEFINE('_UE_CONNECTIONREMOVED_SUB','连线已被移除!');
DEFINE('_UE_CONNECTIONREMOVED_MSG','%s 已经移除了您的连线!');
DEFINE('_UE_CONNECTIONACCEPTED_SUB','请求连线已接受!');
DEFINE('_UE_CONNECTIONACCEPTED_MSG','您请求与 %s 连线已被接受!');
DEFINE('_UE_CONNECTIONDENYSUCCESSFULL','连线成功驳回!');
DEFINE('_UE_TOC_LINK','同意 %s 服务条款及声明 %s');	// to link only the "Terms and Conditions", first %s will be replaced by <a.. and second %s by </a>.
// RC2 Newsletters Support
DEFINE('_UE_NEWSLETTER_HEADER','电子报');
DEFINE('_UE_NEWSLETTER','电子报订阅');
DEFINE('_UE_NEWSLETTER_USER_EDIT_TITLE','编辑您的电子报订阅');
DEFINE('_UE_NEWSLETTER_USER_EDIT_DESC','在查看列表中可以查看您可以订阅的所有电子报. '
.'每种电子报前面的核取方块可以让您知道您是否订阅了该电子报. '
.'您可以更改并按下更新来修改订阅的电子报. ');
DEFINE('_UE_NEWSLETTER_USER_EDIT_DESC_EMAIL','如果您增加了订阅, 您必须再次确认 '
.'来确认您可以收到电子报. 请检查您的 E-Mail 取得更进一步的细节.');
DEFINE('_UE_NEWSLETTER_INTRODCUTION',"<div class='delimiterCell'>"._UE_NEWSLETTER_USER_EDIT_TITLE."</div>\n"
."<div class='fieldCell'>"._UE_NEWSLETTER_USER_EDIT_DESC." "._UE_NEWSLETTER_USER_EDIT_DESC_EMAIL."</div>\n");	// nothing to translate here!
DEFINE('_UE_NEWSLETTER_NAME','电子报');
DEFINE('_UE_NEWSLETTER_DESCRIPTION','描述');
DEFINE('_UE_NEWSLETTER_NAME_REG','电子报');
DEFINE('_UE_NEWSLETTER_DESCRIPTION_REG','描述');
DEFINE('_UE_NEWSLETTER_FORMAT_TITLE','选择电子报格式');
DEFINE('_UE_NEWSLETTER_FORMAT_FIELD','收电子报:');
DEFINE('_UE_NEWSLETTER_HTML','HTML 格式电子邮件');
DEFINE('_UE_NEWSLETTER_TEXT','纯文字电子邮件');
DEFINE('_UE_NEWSLETTER_DESC','设为"否" 如果您没有安装电子报组件. 否则选择一个您希望整合的版本.');
DEFINE('_UE_NEWSLETTER_DESC2','目前, 只有 YaNC 1.4 可以支援用户注册的页面的下方显示提供订阅电子报.');
DEFINE('_UE_NEWSLETTERSREGLIST','电子报选择列表');
DEFINE('_UE_NEWSLETTERSREGLIST_DESC','列表将显示在注册页面中(如果启用电子报整合). 若是电子报整合被选取但没有选取电子报, 所有公开的电子报将于列表中提供订阅. 使用 CTRL (Mac: COMMAND) 来复选, 或是点选已选取的来取消.');
DEFINE('_UE_NEWSLETTERSREGLIST_DESC2','复选利用 CTRL(PC)或 Command (MAC)来 增加/移除 电子报.');
DEFINE('_UE_NEWSLETTER_SUBSCRIBE','订阅至:');
DEFINE('_UE_NEWSLETTERNOTINSTALLED','电子报组件没有安装. 请连系您的网站管理员.');
DEFINE('_UE_NONEWSLETTERS','没有订阅电子报.');
DEFINE('_UE_PUBLIC','公开');
DEFINE('_UE_PRIVATE','私人');
DEFINE('_UE_CONNECTIONDISPLAY','显示类型');
DEFINE('_UE_CONNECTIONDISPLAY_DESC','选择要让每位用户的连线公开显示还是私人的');
DEFINE('_UE_CONNECTIONPATH','显示连线路径');
DEFINE('_UE_CONNECTIONPATH_DESC','选择是否显示一位用户的连线路径和他/她造访的个人资料');
DEFINE('_UE_DIRECTCONNECTION','您直接连线到 ');
DEFINE('_UE_NOESTABLISHEDCONNECTION','没有建立连线在你跟');
DEFINE('_UE_CONNECTIONPATH1','您的连线路径到 ');
DEFINE('_UE_CONNECTIONPATH2',' 程度 ):<br />');
DEFINE('_UE_DETAILSABOUT','细节关于 ');
DEFINE('_UE_CONNECTIONINVITATIONMSG','加入信息到您的连线来个人化您的连线邀请.');
DEFINE('_UE_MESSAGE','信息:');
DEFINE('_UE_SENDCONNECTIONREQUEST','提交');
DEFINE('_UE_CANCELCONNECTIONREQUEST','取消');
DEFINE('_UE_CONFIRMREMOVECONNECTION','您确定您要移除这个连线?');
DEFINE('_UE_CONNECTIONREQUIREACTION','连线要求');
DEFINE('_UE_NOZOOMIMGS','这位用户没有图片!');
DEFINE('_UE_ZOOMNOTINSTALLED','Zoom image 组件没有安装,请向联系您的网站管理员.');
DEFINE('_UE_ZOOMGALLERY','观看艺廊');
DEFINE('_UE_ZOOMTABTITLE','图片艺廊');
DEFINE('_UE_FORUM_FORUMRANKING','论坛评分');
DEFINE('_UE_FORUM_TOTALPOSTS','帖子总数');
DEFINE('_UE_FORUM_KARMA','声望');
DEFINE('_UE_NEWSLETTER_NOT_CONFIRMED','未确认');
DEFINE('_UE_NOTIFICATIONSAT','通知在');
DEFINE('_UE_YOUR_VERSION','您的版本');
DEFINE('_UE_LATEST_VERSION','最新的版本');
DEFINE('_UE_ACTIONSMENU','操作菜单');
DEFINE('_UE_CONNECT_ACTIONREQUIRED','以下您可以见到想跟您连线的用户. 您可以选择批准或是拒绝他们的请求.'
.'选择绿色的核取字段接受他们的申请或是红色的拒绝申请, 然后点选更新按钮. '
.'移动您的鼠标游标于图片及图标上可看见细节的简介以及所代表的意义.');
DEFINE('_UE_CONNECT_MANAGECONNECTIONS','以下您可以看到您所直接连线的用户. '
.'您可以加入个人的注解并且从列表选择多个类型的连线透过 CTRL (PC) 或是 CMD (Mac)来点选项目. '
.'然后点击更新按钮. '
.'移动您的鼠标游标于图标上可看见它们代表意义的简介以及动作, 移到图片上则可以看到连线的细节.');

// PMS:
//Administrator Integration Tab
DEFINE('_UE_PMSTAB','快速信息');
DEFINE('_UE_PMS_NOTINSTALLED','所选择的 PMS 系统没有安装.');
// PMS integration definitions
DEFINE('_UE_PM_SENTSUCCESS','您的站内信已经传送成功!');
DEFINE('_UE_PM_NOTSENT','您的站内信无法传送!');
DEFINE('_UE_PMS_TYPE_UNSUPPORTED','选择的 PMS 系统不支援这种站内信类型!');
DEFINE('_UE_PM_EMPTYMESSAGE','清空信息.');
DEFINE('_UE_SESSIONTIMEOUT','期间逾时.');
DEFINE('_UE_TRYAGAIN','请重试一次.');
DEFINE('_UE_PM_SENDMESSAGE','发送信息');
DEFINE('_UE_PM_PROFILEMSG','从您的个人资料查看信息');
DEFINE('_UE_PM_MESSAGES_HAVE'	, '您有');
DEFINE('_UE_PM_NEW_MESSAGE'		, '新的站内信');
DEFINE('_UE_PM_NEW_MESSAGES'	, '新的站内信');
DEFINE('_UE_PM_NO_MESSAGES'		, '您没有新的站内信');
// PMS Menus:
DEFINE('_UE_PM','站内信');
DEFINE('_UE_PM_USER','传送站内信');
DEFINE('_UE_MENU_PM_USER_DESC','传送站内信给这位用户');
DEFINE('_UE_PM_INBOX','显示私人收件箱');
DEFINE('_UE_MENU_PM_INBOX_DESC','显示收到的站内信');
DEFINE('_UE_PM_OUTBOX','显示私人发信箱');
DEFINE('_UE_MENU_PM_OUTBOX_DESC','显示 寄出/等待寄出 的站内信');
DEFINE('_UE_PM_TRASHBOX','显示私人垃圾箱');
DEFINE('_UE_MENU_PM_TRASHBOX_DESC','显示删除的站内信');
DEFINE('_UE_PM_OPTIONS','编辑 PMS 选项');
DEFINE('_UE_MENU_PM_OPTIONS_DESC','编辑站内信系统选项');

// Menus
DEFINE('_UE_MENU', '菜单');
DEFINE('_UE_USER_STATUS', '用户状态');
DEFINE('_UE_MENU_CB', '社区');
DEFINE('_UE_MENU_ABOUT_CB', '关于 Community Builder...');
DEFINE('_UE_SITE_POWEREDBY', '这个网站的社区功能是由 Joomla Community Builder 提供的');
DEFINE('_UE_MENU_EDIT', '编辑');
DEFINE('_UE_MENU_VIEW', '查看');
DEFINE('_UE_MENU_MESSAGES', '信息');
DEFINE('_UE_MENU_CONNECTIONS', '连线');
//DEFINE('_UE_MENU_UPDATEPROFILE', '更新您的个人资料');
DEFINE('_UE_MENU_UPDATEPROFILE_DESC', '更改您的个人资料设定');
//DEFINE('_UE_MENU_UPDATEAVATAR', '改变您的照片');
DEFINE('_UE_MENU_UPDATEAVATAR_DESC', '选择您的个人资料图片');
//DEFINE('_UE_MENU_DELETE_AVATAR', '移除图片');
DEFINE('_UE_MENU_DELETE_AVATAR_DESC', '从您的个人资料中移除图片');
DEFINE('_UE_MENU_VIEWMYPROFILE', '查看您的个人资料');
DEFINE('_UE_MENU_VIEWMYPROFILE_DESC', '查看您个人的资料');

DEFINE('_UE_MENU_SENDUSEREMAIL','发送 e-mail 给用户');
DEFINE('_UE_MENU_SENDUSEREMAIL_DESC','发送 e-mail 给这位用户');
DEFINE('_UE_MENU_USEREMAIL_DESC','此用户的 E-Mail 地址');
DEFINE('_UE_ADDCONNECTION_DESC','增加连线到这位用户');
DEFINE('_UE_ADDCONNECTIONREQUEST','连线请求');
DEFINE('_UE_ADDCONNECTIONREQUEST_DESC','请求与这名用户连线');
DEFINE('_UE_REMOVECONNECTION_DESC','移除与这名用户连线');
DEFINE('_UE_REVOKECONNECTIONREQUEST','撤销连线请求');
DEFINE('_UE_REVOKECONNECTIONREQUEST_DESC','取消与这名用户的连线要求');
DEFINE('_UE_MENU_MANAGEMYCONNECTIONS','管理您的连线');
DEFINE('_UE_MENU_MANAGEMYCONNECTIONS_DESC','管理您现有的连线及等待连线动作');

DEFINE('_UE_MENU_MODERATE', '群组管理');
//DEFINE('_UE_MENU_REQUESTUNBANPROFILE','提出取消禁用请求');
DEFINE('_UE_MENU_REQUESTUNBANPROFILE_DESC', '提交请求给网站版主取消禁用个人资料');
//DEFINE('_UE_MENU_BANPROFILE','禁用个人资料');
DEFINE('_UE_MENU_BANPROFILE_DESC', '网站版主: 禁用这个个人资料, 让其他用户无法看到');
//DEFINE('_UE_MENU_UNBANPROFILE','取消禁用个人会员');
DEFINE('_UE_MENU_UNBANPROFILE_DESC', '网站版主: 取消禁用这个个人资料, 让其他用户可以看到');
//DEFINE('_UE_MENU_REPORTUSER','举报会员');
DEFINE('_UE_MENU_REPORTUSER_DESC', '举报此名用户让网站版主来作出适当的处里');
//DEFINE('_UE_MENU_VIEWUSERREPORTS','查看用户举报');
DEFINE('_UE_MENU_VIEWUSERREPORTS_DESC','网站版主: 查看关于此名用户的举报');
DEFINE('_UE_UNBAN_MODERATE_DESC','点击遭禁用的用户名来查看此名用户个人资料. '
.'然后从用户个人资料菜单选择 管理/取消禁用 如果您要取消禁用此名用户.');
DEFINE('_UE_MENU_APPROVE_IMAGE_DESC', '网站版主: 批准此名用户所提交的个人资料图片,让它可以给所有用户看见');
DEFINE('_UE_MENU_REJECT_IMAGE_DESC', '网站版主: 驳回此名用户的个人资料图片');
DEFINE('_UE_HITS_DESC','此用户个人资料的查看次数');
DEFINE('_UE_ONLINESTATUS_DESC','此用户目前的在线状态');
DEFINE('_UE_MEMBERSINCE_DESC','这名用户注册于');
DEFINE('_UE_LASTONLINE_DESC','这名用户最近在线时间在');
DEFINE('_UE_LASTUPDATEDON_DESC','这明用户最近更新了他的个人资料在');

DEFINE('_UE_LENGTH_ERROR','已经到达这个字段的最大长度');
DEFINE('_UE_CHARACTERS','字元');
DEFINE('_UE_NEVER','绝不');
DEFINE('_UE_NOFORUMPOSTSFOUND','没有找到相符的论坛帖子.');

DEFINE('_UE_PORTRAIT','头像');
DEFINE('_UE_CONNECTIONPATHS','连线路径');

DEFINE('_UE_PROFILE_PAGE_TITLE','用户个人资料页标题');
DEFINE('_UE_PROFILE_TITLE_TEXT','%s 的个人资料页');

DEFINE('_UE_SEARCH_INPUT','搜索&hellip;');	// &hellip; = "..."
DEFINE('_UE_POS_CB_MAIN','主要区域 (下方 置左/置中/置右)');
DEFINE('_UE_POS_CB_HEAD','标头 (上方 置左/置中/置右)');
DEFINE('_UE_POS_CB_MIDDLE','中间区域');
DEFINE('_UE_POS_CB_LEFT','左边 (中间区域的)');
DEFINE('_UE_POS_CB_RIGHT','右边 (中间区域的)');
DEFINE('_UE_POS_CB_BOTTOM','下方区域 (主要区域下方)');

DEFINE('_UE_DISPLAY_TAB','标签的区块');
DEFINE('_UE_DISPLAY_DIV','以标题标示');
DEFINE('_UE_DISPLAY_HTML','原始显示没有标题');
DEFINE('_UE_DISPLAY_OVERLIB','跟鼠标重叠移动');
DEFINE('_UE_DISPLAY_OVERLIBFIX','固定重叠鼠标移出关闭');
DEFINE('_UE_DISPLAY_OVERLIBSTICKY','黏附重叠按钮');
DEFINE('_UE_CLOSE_OVERLIB','关闭');

//SB Integration Support
DEFINE('_UE_SB_TABTITLE','论坛设定');
DEFINE('_UE_SB_TABDESC','这是您的论坛设定');
DEFINE('_UE_SB_VIEWTYPE_TITLE','偏好的查看类型');
DEFINE('_UE_SB_VIEWTYPE_FLAT','平铺');
DEFINE('_UE_SB_VIEWTYPE_THREADED','树形');
DEFINE('_UE_SB_ORDERING_TITLE','偏好的信息排序');
DEFINE('_UE_SB_ORDERING_OLDEST','最旧的排最前');
DEFINE('_UE_SB_ORDERING_LATEST','最新的排最前');
DEFINE('_UE_SB_SIGNATURE','签名');
//added for SB 1.5 during 1.0 RC 1
DEFINE('_UE_SB_POSTSPERPAGE','文章每一页');
DEFINE('_UE_SB_USERTIMEOFFSET','本地时间与服务器时间之间的时差');
DEFINE('_UE_SB_CONFIRMUNSUBSCRIBEALL','您确定您要取消订阅您所有论坛的订阅 ?');
DEFINE('_UE_FORUMDATE','日期');
DEFINE('_UE_FORUMCATEGORY','分类');
DEFINE('_UE_FORUMSUBJECT','主题');
DEFINE('_UE_FORUMHITS','点击');
DEFINE('_UE_FORUM_POSTS','论坛文章');
DEFINE('_UE_FORUM_LASTPOSTS','最新 %s 论坛文章');
DEFINE('_UE_FORUM_FOUNDPOSTS','找到 %s 论坛文章');
DEFINE('_UE_FORUM_STATS','论坛统计');
if (!defined('_RANK_MODERATOR')) DEFINE('_RANK_MODERATOR','Moderator');
if (!defined('_RANK_ADMINISTRATOR')) DEFINE('_RANK_ADMINISTRATOR','Administrator');
DEFINE('_UE_SBNOTINSTALLED','Simpleboard 论坛组件没有安装. 请连系您的网站管理员.');
DEFINE('_UE_NOFORUMPOSTS','这个会员没有发表过文章.');
DEFINE("_UE_USERPARAMS","用户选项");
//Mamblog search:
DEFINE('_UE_BLOG_LASTENTRIES','最新的 %d 个博客项目');
DEFINE('_UE_BLOG_FOUNDENTRIES','找到 %d 个博客项目');
DEFINE('_UE_BLOG_ENTRIES','博客项目');

// 1.0 stable:
DEFINE('_UE_NO_USERS_IN_LIST','此列表没有用户');
DEFINE('_UE_LIST_DOES_NOT_EXIST','此列表不存在');
DEFINE('_UE_VISIBLE_ONLY_MODERATOR','此项目只限版主观看');
DEFINE('_UE_AUTOMATIC','自动地');
DEFINE('_UE_MANUAL','手动');
DEFINE('_UE_NOVERSIONCHECK','组态的版本检查');
DEFINE('_UE_NOVERSIONCHECK_DESC','选取当您想要每次进入 Community Builder 一般组态时自动检查版本 (强烈建议, 这样您可以立即看到关键安全性释出版本的信息) 如果手动, 当您点击链接才检查 (不建议). 您已经安装的 Community Builder 不会在版本检查时透露任何资料 (除了目前的安装版本以及标准的 http 参数). 也没有自动更新的服务.');
// 1.0 stable cblogin module:
DEFINE('_UE_SHOW_POFILE_OF','显示个人资料 ');

//Not yet used within application but are needed to translate default images for profile.
DEFINE('_UE_IMG_NOIMG','没有图片');
DEFINE('_UE_IMG_PENDIMG','等待批准');

// CB 1.0.2 optional string:
DEFINE('_UE_MAXEMAILSLIMIT','你发送了%d封email仅仅在%d小时内.请休息一段时间后再试.');
DEFINE('_UE_INPUT_VALUE_NOT_ALLOWED','此输入值非法.');

//Needed for Joomla 1.5 and Mambo 4.6 language independance: Translators: please take strings from joomla 1.0.11's language file
/** registration.php */
if (!defined('_ERROR_PASS'))		DEFINE('_ERROR_PASS','很抱歉,此用户不存在');
if (!defined('_NEWPASS_SENT'))		DEFINE('_NEWPASS_SENT','密码已重置并发送至邮箱t!');
if (!defined('_REGWARN_NAME'))		DEFINE('_REGWARN_NAME','请输入你的姓名.');
if (!defined('_REGWARN_UNAME'))		DEFINE('_REGWARN_UNAME','请输入用户名.');
if (!defined('_REGWARN_MAIL'))		DEFINE('_REGWARN_MAIL','请输入一个有效的Email地址.');
if (!defined('_REGWARN_VPASS2'))	DEFINE('_REGWARN_VPASS2','两次密码输入不一致,请重试.');
if (!defined('_REGWARN_INUSE'))		DEFINE('_REGWARN_INUSE','此用户名已存在，请尝试其它的用户名.');
if (!defined('_REGWARN_EMAIL_INUSE')) DEFINE('_REGWARN_EMAIL_INUSE', '此e-mail已被其它用户用于注册.如果你忘记了密码，请点击“忘记了密码？" 重置你的密码.');
if (!defined('_VALID_AZ09'))		DEFINE('_VALID_AZ09',"请输入一个有效的%s.不包含空格,字符数不少于%d,仅包含 0-9,a-z,A-Z");
/** classes/html/registration.php */
if (!defined('_PROMPT_PASSWORD'))	DEFINE('_PROMPT_PASSWORD','忘记了密码');
if (!defined('_NEW_PASS_DESC'))		DEFINE('_NEW_PASS_DESC','请输入你的用户名和注册邮箱，然后点击密码重置按钮.<br />'
.'你将会很快收到新密码. 请使用新密码登录本站.');
if (!defined('_PROMPT_UNAME'))		DEFINE('_PROMPT_UNAME','用户名:');
if (!defined('_PROMPT_EMAIL'))		DEFINE('_PROMPT_EMAIL','E-mail地址 :');
if (!defined('_BUTTON_SEND_PASS'))	DEFINE('_BUTTON_SEND_PASS','重置密码');
if (!defined('_REGISTER_TITLE'))	DEFINE('_REGISTER_TITLE','注册');
if (!defined('_REGISTER_NAME'))		DEFINE('_REGISTER_NAME','姓名:');
if (!defined('_REGISTER_UNAME'))	DEFINE('_REGISTER_UNAME','用户名:');
if (!defined('_REGISTER_EMAIL'))	DEFINE('_REGISTER_EMAIL','E-mail:');
if (!defined('_REGISTER_PASS'))		DEFINE('_REGISTER_PASS','密码:');
if (!defined('_REGISTER_VPASS'))	DEFINE('_REGISTER_VPASS','再次确认密码:');
if (!defined('_BUTTON_SEND_REG'))	DEFINE('_BUTTON_SEND_REG','注册');
if (!defined('_SENDING_PASSWORD'))	DEFINE('_SENDING_PASSWORD','你的密码已被发送至上述邮箱.<br />在您收到新密码之后，'
.' 就可以通过新密码登录网站并修改密码。');
if (!defined('_LOGIN_SUCCESS'))		DEFINE('_LOGIN_SUCCESS','登录成功');
if (!defined('_LOGOUT_SUCCESS'))	DEFINE('_LOGOUT_SUCCESS','注销成功');
if (!defined('_LOGIN_BLOCKED'))		DEFINE('_LOGIN_BLOCKED','您的帐户已被锁定.请联系管理员.');
if (!defined('_CMN_YES'))			DEFINE('_CMN_YES','是');
if (!defined('_CMN_NO'))			DEFINE('_CMN_NO','否');
if (!defined('_CMN_SHOW'))			DEFINE('_CMN_SHOW','显示');
if (!defined('_CMN_HIDE'))			DEFINE('_CMN_HIDE','隐藏');
if (!defined('_LOGIN_INCOMPLETE'))	DEFINE('_LOGIN_INCOMPLETE','用户名及密码栏不能为空.');
if (!defined('_LOGIN_INCORRECT'))	DEFINE('_LOGIN_INCORRECT','用户名或密码错误，请再试一次.');
if (!defined('_USER_DETAILS_SAVE'))	DEFINE('_USER_DETAILS_SAVE','设置已保存.');

// 1.1:
DEFINE('_UE_MENU_STATUS', '状态');
DEFINE('_UE_YOURCONNECTIONS','你的连线');
DEFINE('_UE_USERSNCONNECTIONS','%s\'的连线');
DEFINE('_UE_SEEALLNCONNECTIONS','察看所有关于%s的连线s');
DEFINE('_UE_SEEALLOFUSERSNCONNECTIONS','察看%s的所有连线');
DEFINE('_UE_YOU_ARE_ALREADY_REGISTERED','You are already registered with this username and password.');
DEFINE('_UE_SESSION_EXPIRED','线程超时或者Cookies被禁用.');
DEFINE('_UE_PLEASE_REFRESH','请在填写前刷新或者重新载入此页面.');
DEFINE('_UE_REGISTERFORPROFILEVIEW','查看此页面需要登录或注册成本站会员.');
DEFINE('_UE_INFORMATION_FOR_FIELD',' %s的个人资料 : %s');
DEFINE('_UE_ALLOWMODERATORSUSEREDIT_DESC','允许版主修改用户资料，增加、修改或删除用户头像.版主无法修改同级或者更高级别管理人员资料.');
DEFINE('_UE_ALLOWMODERATORSUSEREDIT','允许版主修改用户资料');
DEFINE('_UE_USERPROFILEBLOCKED','此用户资料目前不可用.');
DEFINE('_UE_EDIT_OTHER_USER_TITLE','编辑 %s的详细资料');
DEFINE('_UE_MOD_MENU_UPDATEPROFILE', '更新此用户个人资料');
DEFINE('_UE_MOD_MENU_UPDATEPROFILE_DESC', '保存此用户资料修改');
DEFINE('_UE_MOD_MENU_UPDATEAVATAR', '上传用户图片');
DEFINE('_UE_MOD_MENU_UPDATEAVATAR_DESC', '从用户资料选择图片');
DEFINE('_UE_MOD_MENU_DELETE_AVATAR', '删除用户图片');
DEFINE('_UE_MOD_MENU_DELETE_AVATAR_DESC', '将此用户资料中的图片删除e');
DEFINE('_UE_MOD_MENU_VIEWOLDUSERREPORTS','察看此用户的处理历史纪录');
DEFINE('_UE_MOD_MENU_VIEWOLDUSERREPORTS_DESC','允许站点版主看此用户的处理历史纪录');
DEFINE('_UE_REPORTSTATUS','报告状态');
DEFINE('_UE_REPORTSTATUS_OPEN','开启');
DEFINE('_UE_REPORTSTATUS_PROCESSED','处理');
DEFINE('_UE_UNBANUSER','用户资料封禁解除');
DEFINE('_UE_UNBANNEDON','封禁日期');
DEFINE('_UE_UNBANNEDBY','封禁操作人');
DEFINE('_UE_MENU_BANPROFILE_HISTORY','察看封禁历史纪录');
DEFINE('_UE_MENU_BANPROFILE_HISTORY_DESC', '允许版主察看此用户资料被封禁历史纪录');
DEFINE('_UE_BANSTATUS','封禁状态');
DEFINE('_UE_BANSTATUS_BANNED','被封禁');
DEFINE('_UE_BANSTATUS_UNBAN_REQUEST_PENDING','等待处理解除封禁请求');
DEFINE('_UE_BANSTATUS_PROCESSED','已处理');
DEFINE('_UE_UNNAMED_USER','未命名用户');
DEFINE('_UE_REG_CB_ALLOW','开启用户注册');
DEFINE('_UE_REG_CB_ALLOW_DESC','采用 全局设定 或者 CB设定 皆可。<br />推荐设定: 仅通过 CB设定 : 在此设定里设置 `是` 并在全局设定里设置为 `否`.');
DEFINE('_UE_REG_PROFILE_2COLS','2栏式版面 - 宽度:');
DEFINE('_UE_REG_PROFILE_2COLS_RIGHT_REST','右边距!');
DEFINE('_UE_REG_PROFILE_2COLS_DESC','2栏式版面 %边距 ');
DEFINE('_UE_REG_PROFILE_3COLS','3 栏式版 - 宽度:');
DEFINE('_UE_REG_PROFILE_3COLS_RIGHT_REST','右边距!');
DEFINE('_UE_REG_PROFILE_3COLS_DESC','3栏式版面. 中间列宽度!');
DEFINE('_UE_REG_FILTER_ALLOWED_TAGS','下列代码标签将不被过滤:');
DEFINE('_UE_REG_FILTER_ALLOWED_TAGS_DESC','此列表内的代码标签将不被过滤,例如: `applet body bgsound embed`.<br />注意:此功能包含一定风险,用户可能会插入恶意代码.默认代码过滤器会防止此情况发生。下述代码标签被默认设置过滤，将其加入此列表后过滤将被解除:');
DEFINE('_UE_REG_FURTHER_SETTINGS','高级设置:');
DEFINE('_UE_REG_FURTHER_SETTINGS_MORE','察看 plugins and tabs 参数.');
DEFINE('_UE_REG_FURTHER_SETTINGS_DESC','更多参数设置参见 菜单: 组件 / Community Builder / Plugin Management and / Tab Management. 每个plugin和tab都可以单独设置参数，设置前请先启用该Plugins和Tabs .');
// 1.1: backend global config:
DEFINE('_UE_REG_CONFIGURATION_MANAGER','设置');
DEFINE('_UE_REG_ALLOWREG_SAME_AS_GLOBAL','按照全局设定`允许注册` ');
DEFINE('_UE_REG_ALLOWREG_YES','独立于全局设定');
DEFINE('_UE_NONE','无');
DEFINE('_UE_REG_NAMEFORMAT_NAME_ONLY','仅姓名');
DEFINE('_UE_REG_NAMEFORMAT_NAME_USERNAME','姓名(用户名)');
DEFINE('_UE_REG_NAMEFORMAT_USERNAME_ONLY','仅用户名');
DEFINE('_UE_REG_NAMEFORMAT_USERNAME_NAME','用户名 (姓名)');
DEFINE('_UE_REG_NAMEFORMAT_SINGLE_FIELD','单一姓名字段');
DEFINE('_UE_REG_NAMEFORMAT_TWO_FIELDS','姓、名分别输入的字段');
DEFINE('_UE_REG_NAMEFORMAT_THREE_FIELDS','名、中间名、姓分别输入的字段');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_ONLY','仅显示Email');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_W_MAILTO','显示Email及 w/ MailTo超连接');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_W_FORM','显示发送Email表单连接');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_NO','不显示Email');
DEFINE('_UE_GROUPS_EVERYBODY','所有人');
DEFINE('_UE_GROUPS_ALL_REG_USERS','所有注册用户');
DEFINE('_UE_WARNING','警告');
DEFINE('_UE_YOUR_CONFIG_FILE','设置文件');
DEFINE('_UE_IS_NOT_WRITABLE','无法写入');
DEFINE('_UE_NEED_TO_CHMOD_CONFIG','请修改文件权限为766，然后保存设置');
DEFINE('_UE_FILE_UNWRITABLE','');
DEFINE('_UE_LEFT','左对齐');
DEFINE('_UE_RIGHT','右对齐');
DEFINE('_UE_CENTER','举重');
DEFINE('_UE_UP','上对齐');
DEFINE('_UE_DOWN','下对齐');
DEFINE('_UE_TOP','顶对齐');
DEFINE('_UE_BOTTOM','底对齐');
DEFINE('_UE_MODERATORS_AND_ABOVE','CB 版主及其以上');
DEFINE('_UE_SUPERADMINS_ONLY','仅限超级管理员');
DEFINE('_UE_ADMINS_AND_SUPERADMINS_ONLY','仅限管理员和超级管理员');
DEFINE('_UE_NO_PARAMS','此条目无参数设置');
DEFINE('_UE_CALENDAR_TYPE','日历显示样式');
DEFINE('_UE_CALENDAR_TYPE_DESC','选择日历的显示方式.');
DEFINE('_UE_CALENDAR_TYPE_DROPDOWN_POPUP','下拉(+弹出) 日历');
DEFINE('_UE_CALENDAR_TYPE_POPUP','弹出日历窗口 (old)');
DEFINE('_UE_REG_USERNAMECHECKER','Ajax 用户名检测');
DEFINE('_UE_REG_USERNAMECHECKER_DESC','在注册过程中检查用户名是否已被使用.注：此功能可能被用于猜测用户名进而推测用户密码，请谨慎使用.此功能尚属测试阶段，尚未为大型站点优化。请在使用前进行测试 !');
// 1.1: frontend:
DEFINE('_UE_BUTTON_LOGIN','登录');
DEFINE('_UE_BUTTON_LOGOUT','注销');
DEFINE('_UE_DO_LOGIN','请先登录.');
DEFINE('_UE_DO_LOGOUT','请先注销.');
define('_UE_CHECK_USERNAME_AVAILABILITY',"检查次用户名是否可用");
define('_UE_USERNAME_ALREADY_EXISTS',"此用户名 '%s' 已被注册:请选择一个其它的用户名.");
define('_UE_USERNAME_DOESNT_EXISTS',"此用户名'%s'可用:请继续注册步骤.");
define('_UE_CHECKING',"检查中...");
define('_UE_SORRY_CANT_CHECK',"很抱歉,暂时无法检查.");
DEFINE('_UE_PLEAE_CHECK_PROFILE','请察看你的个人资料');
DEFINE('_UE_BANNED_CHANGE_PROFILE','你的个人资料暂时被封禁.仅限你个人和管理员和以察看.<br />请根据管理员的要求修改你的个人资料,然后向管理员申请解除封禁.');
DEFINE('_UE_WARNING_EDIT_OTHER_USER_PROFILE','警告:这不是你的个人资料.你正在使用管理权限修改%s的个人资料.');
DEFINE('_UE_BACK_TO_YOUR_PROFILE','返回个人资料页面');
// CB captcha plugin strings in core cb 1.1:
DEFINE('_UE_CAPTCHA_Label','验证码');
DEFINE('_UE_CAPTCHA_Enter_Label','请输入验证码:');
DEFINE('_UE_CAPTCHA_Desc','输入图片上所显示的验证码');
DEFINE('_UE_CAPTCHA_NOT_VALID','验证码输入有误');
DEFINE('_UE_CAPTCHA_ALT_IMAGE','显示验证码的图片');
DEFINE('_UE_CAPTCHA_AUDIO','点击这里收听验证码朗读');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_TITLE','再次收听CB 验证码');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_DESCRIPTION','重新听取验证码朗读');
DEFINE('_UE_CAPTCHA_AUDIO_DOWNLOAD','点击使用播放器播放或者下载音频文件');
DEFINE('_UE_CAPTCHA_AUDIO_CLICK2DOWNLOAD','(右键单击或者按住control键后单击)');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_CLOSEWINDOW','关闭此窗口');

// 1.2 Frontend:
DEFINE('_UE_ERROR_USER_NOT_SYNCHRONIZED','此用户不存在或未同步至CB数据库内');
DEFINE('_LOGIN_TITLE','登录');
DEFINE('_LOGIN_REGISTER_TITLE','欢迎您的访问, 请首先登录或者注册:');
DEFINE('_UE_UPLOAD_DIMENSIONS_AVATAR','如果您上传的图片超过尺寸限制，将自动被调整至宽度最大 %s 像素 x 高度最大 %s 像素, 同时文件大小需小于 %s KB.');
DEFINE('_UE_LOGIN_BLOCKED','此用户被禁止登录.');
DEFINE('_UE_REMEMBER_ME', '记住我');
DEFINE('_UE_PASSWORD_REMINDER','密码提示');
DEFINE('_UE_USERNAME_PASSWORD_REMINDER','用户名、密码提示');
DEFINE('_UE_REMINDER_NEEDED_FOR','密码提示');
DEFINE('_UE_LOST__USERNAME','忘记用户名');
DEFINE('_UE_LOST__PASSWORD','忘记密码');
DEFINE('_UE_LOST_PASSWORD','忘记了密码?');
DEFINE('_UE_USERNAMEREMINDER_SUB','为 %s 设置用户名提示');
DEFINE('_UE_USERNAMEREMINDER_MSG','欢迎回来,\n'
.'用户%s的用户名提示功能设置成功.\n\n'
.'您的用户名是: %s\n\n'
.'点击下面的链接登录你的帐户:\n'
.'%s\n\n'
.'.\n');
DEFINE('_UE_NEWPASS_SUB','用户 %s 的新密码');
DEFINE('_UE_NEWPASS_MSG','用户 %s 使用了 email 找回密码的功能.\n'
.'应来自 %s 的用户找回密码的请求，本网站特发送此邮件.\n\n'
.'您的新密码是: %s\n\n'
.'如果您没有申请找回密码,请不要担心.'
.' 包含有新密码的邮件仅仅发送给您，其他人不会收到此封邮件.请尽快使用新密码登录我们的网站，'
.' 并修改密码为你常用的字段.');
DEFINE('_UE_ALREADY_LOGGED_IN','你已经登录');
DEFINE('_UE_EMAIL_COULD_NOT_CHECK','请检查此邮件地址: 请重复检查:仔细确认.');
DEFINE('_UE_EMAIL_COULD_NOT_CHECK_NEEDED','请检查此邮件地址: 请重复检查.');
DEFINE('_UE_EMAIL_INCORRECT_CHECK','此邮件地址未收到确认email:请检查.');
DEFINE('_UE_EMAIL_INCORRECT_CHECK_NEEDED','此邮件地址未收到确认email:请确认.');
DEFINE('_UE_EMAIL_VERIFIED','此邮件地址有误.');
DEFINE('_UE_EMAIL_NOVALID','此邮件地址无效.');
DEFINE('_UE_EMAIL_ALREADY_REGISTERED','此邮件地址已被使用.');
DEFINE('_UE_FIELDONPROFILE_SHORT','在用户资料内可见');
DEFINE('_UE_FIELDNOPROFILE_SHORT','在用户资料内<strong>不</strong>可见');
DEFINE('_UE_FIELDREQUIRED_SHORT','必填字段');
DEFINE('_UE_FIELDDESCRIPTION_SHORT','信息:将鼠标指向图标');
DEFINE('_UE_AVATAR_UPLOAD_DISCLAIMER','点击 "上传"按钮前, 请确认你有权限使用该图片，任何侵犯他人权利的图片会直接导致账户被封禁.');
DEFINE('_UE_AVATAR_UPLOAD_DISCLAIMER_TERMS','点击 "上传"按钮前, 请确认你有权限使用该图片,并确认该图片未违反任何%s，任何不良图片会直接导致账户被封禁 .');
DEFINE('_UE_AVATAR_TOC_LINK','规范及要求');
DEFINE('_UE_USER_EMAIL_CONFIRMED','Email地址已确认');
DEFINE('_UE_LOST_USERNAME_PASSWORD','忘记了用户名/密码?');
DEFINE('_UE_LOST_USERNAME_OR_PASSWORD','忘记了用户名/密码 ?');
DEFINE('_UE_LOST_USERNAME_DESC','如果你 <strong>忘记了用户名</strong>, 请输入你注册时使用的 E-mail 地址,用户名处留空，然后点击发送用户名按钮,你的用户名将会被发送至注册邮箱.');
DEFINE('_UE_LOST_USERNAME_ONLY_DESC','如果您 <strong>忘记了用户名</strong>, 请输入您的 E-mail 地址, 然后点击“发送用户名”按钮，系统就会将您的用户名发送至您的信箱。');
DEFINE('_UE_LOST_PASSWORD_DESC','如果你 <strong>忘记了密码</strong>但是你知道用户名,请输入你的用户名和注册时使用的E-mail地址, 点击发送密码按钮,你将很快收到一封包含新密码的邮件.请尽快使用该密码登录本站并及时修改为常用密码.');
DEFINE('_UE_LOST_USERNAME_PASSWORD_DESC','如果 <strong>你同时忘记了用户名和密码</strong>, 请首先找回用户名，然后找回密码. 找回用户名时,请输入你注册时使用的 E-mail 地址,用户名处留空，然后点击发送用户名按钮，你的用户名将会被发送至注册邮箱.然后输入找回的用户名和注册时使用的E-mail地址, 点击发送密码按钮,你将很快收到一封包含新密码的邮件.');
DEFINE('_UE_BUTTON_SEND','发送');
DEFINE('_UE_BUTTON_SEND_USERNAME','发送用户名');
DEFINE('_UE_BUTTON_SEND_PASS','发送密码');
DEFINE('_UE_BUTTON_SEND_USERNAME_PASS','发送用户名/密码');
define('_UE_USERNAME_EXISTS_ON_SITE',"此用户名'%s' 已被使用.");
define('_UE_USERNAME_DOES_NOT_EXISTS_ON_SITE',"用户名 '%s' 可以使用.");
define('_UE_USERNAME_FREE_OK_TO_PROCEED',"用户名 '%s' 暂时未被使用: 你可以继续注册.");
define('_UE_THIS_IS_YOUR_USERNAME',"这是你在本站使用的用户名.");
define('_UE_THIS_IS_USERS_USERNAME',"这是此用户在本站使用的用户名.");
define('_UE_EMAIL_EXISTS_ON_SITE',"此Email '%s' 已被使用.");
define('_UE_EMAIL_DOES_NOT_EXISTS_ON_SITE',"本站无使用'%s'的用户.");
define('_UE_SEARCH_ERROR','搜索出错');
define('_UE_EMAIL_SENDING_ERROR','发送Email失败');
DEFINE('_UE_USERNAME_REMINDER_SENT','用户名找回程序已向发送一份邮件至%s. 请检查你的邮箱 (收件箱没有的话，请记得检查垃圾邮件文件夹！)!');
DEFINE('_UE_NEWPASS_SENT','新的用户密码已生成并发送至%s.请检查你的邮箱 (收件箱没有的话，请记得检查垃圾邮件文件夹！)！');
DEFINE('_UE_VALID_UNAME','请输入有效的用户名。请勿使用空格,至少3个字符并且仅限0-9,a-z,A-Z');
DEFINE('_UE_VALID_UNAME_CHARS','请输入有效的 %s.  请勿使用空格,至少%s个字符并且仅限0-9,a-z,A-Z');
DEFINE('_UE_VALID_PASS','请输入有效的密码。请勿使用空格,至少6个字符并且仅限字母、数字以及-和_，字母区分大小写');
DEFINE('_UE_VALID_PASS_CHARS','请输入有效的 %s.请勿使用空格,至少%s个字符并且仅限字母、数字以及-和_，字母区分大小写');
DEFINE('_UE_VALID_MIN_LENGTH','请输入有效的 %s: 至少%s个字符: 你输入了 %s 个字符.');
DEFINE('_UE_VALID_MAX_LENGTH','请输入有效的 %s: 最多%s个字符: 你输入了 %s 个字符.');
DEFINE('_UE_REGWARN_NAME','请输入你的真实全名.');
DEFINE('_UE_REGWARN_FNAME','请输入你的真实姓氏.');
DEFINE('_UE_REGWARN_MNAME','请输入你的真实名字.');
DEFINE('_UE_REGWARN_LNAME','请输入你的真实名字.');
DEFINE('_UE_REGWARN_MAIL','请输入一个真实有效的Email地址.本站将会发送一封确认邮件用以激活你的帐户.');
DEFINE('_UE_REGWARN_VPASS2','两次输入的密码不一致，请检查后重试.');
DEFINE('_UE_VERIFY_SOMETHING','检查 %s');
DEFINE('_UE_NO_PREFERENCE','无偏好');
DEFINE('_UE_NO_INDICATION','无指向');
DEFINE('_UE_SEARCH_CRITERIA','简单搜索');
DEFINE('_UE_SEARCH_RESULTS','在结果中搜索');
DEFINE ('_UE_SEARCH_USERS','搜索用户');
DEFINE ('_UE_FIND_USERS','查找用户');
DEFINE ('_UE_SEARCH_FROM','在中间');
DEFINE ('_UE_SEARCH_TO','和');
DEFINE ('_UE_MATCH_IS','是');
DEFINE ('_UE_MATCH_IS_NOT','不是');
DEFINE ('_UE_MATCH_IS_EXACTLY','是确切的');
DEFINE ('_UE_MATCH_IS_EXACTLY_NOT','是不确切的');
DEFINE ('_UE_MATCH_ARE_EXACTLY','是准确的');
DEFINE ('_UE_MATCH_ARE_EXACTLY_NOT','是不准确的');
DEFINE ('_UE_MATCH_IS_ONE_OF','是一名');
DEFINE ('_UE_MATCH_IS_NOT_ONE_OF','不是一名');
DEFINE ('_UE_MATCH_PHRASE','包含关键词');
DEFINE ('_UE_MATCH_PHRASE_NOT','不包含关键词');
DEFINE ('_UE_MATCH_ALL','包含所有');
DEFINE ('_UE_MATCH_ALL_NOT','不包含任何');
DEFINE ('_UE_MATCH_ANY','任何地方包含');
DEFINE ('_UE_MATCH_ANY_NOT','不会包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ALL_OF','包含所有的');
DEFINE ('_UE_MATCH_INCLUDE_ALL_OF_NOT','不包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ANY_OF','包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ANY_OF_NOT','不包含任何');
DEFINE ('_UE_MATCH_EXCLUSIONS','排除');
DEFINE ('_UE_AVATAR_NONE','暂无头像');
DEFINE ('_UE_AVATAR_NO_CHANGE','不更换头像');
DEFINE ('_UE_AVATAR_UPLOAD','上传头像');
DEFINE ('_UE_AVATAR_UPLOAD_NEW','上传新头像');
DEFINE ('_UE_AVATAR_SELECT','从你的相册中选择一张图片');
DEFINE ('_UE_HAS_PROFILE_IMAGE','已上传头像');
DEFINE ('_UE_HAS_NO_PROFILE_IMAGE','暂无头像');
DEFINE ('_UE_AGE_YEARS','%s 年');
DEFINE ('_UE_YEARS','年');
DEFINE ('_UE_HI_NAME','你好, %s');

// 1.2 Backend:
DEFINE('_UE_TOP_AND_BOTTOM','顶部和底部');
DEFINE('_UE_REG_SHOW_ICONS_EXPLAIN','显示图标说明文字');
DEFINE('_UE_REG_SHOW_ICONS_EXPLAIN_DESC','在注册页面顶部和底部图标是否显示说明文字(默认在顶部和底部)');
DEFINE('_UE_ICONS_DISPLAY','在空白处显示图标');
DEFINE('_UE_ICONS_DISPLAY_DESC','图标和图标说明文字是否在注册和用户编辑时显示.当说明文字存在是，信息图标将始终显示.');
DEFINE('_UE_REG_SHOW_LOGIN_ON_PAGE','在注册页面显示登录模块');
DEFINE('_UE_REG_SHOW_LOGIN_ON_PAGE_DESC','是否在注册页面旁显示登录模块. 注意: CB login 模块必须在设置此功能前安装.');
DEFINE('_UE_REQUIRED_ONLY','仅显示必须的图标');
DEFINE('_UE_PROFILE_ONLY','仅显示个人资料/ 无个人资料图标');
DEFINE('_UE_REQUIRED_AND_PROFILE_ONLY','仅显示必需的和个人资料图标');
DEFINE('_UE_INFO_ONLY','仅显示信息图标说明');
DEFINE('_UE_REQUIRED_AND_INFO_ONLY','必需的和信息说明图标');
DEFINE('_UE_PROFILE_AND_INFO_ONLY','个人资料图标和信息说明图标');
DEFINE('_UE_REQUIRED_PROFILE_AND_INFO','所有图标:必需的,个人资料图标');
DEFINE('_UE_ALWAYSRESAMPLEUPLOADS','重新生成上传的头像图片文件');
DEFINE('_UE_ALWAYSRESAMPLEUPLOADS_DESC','重新生成上传的头像图片文件可以增强安全性,但只有 ImageMagic 可以保持 GIFs动画图片原貌.');
DEFINE('_UE_FRONTENDUSERPARAMS','允许用户编辑个人前台CMS参数');
DEFINE('_UE_FRONTENDUSERPARAMS_DESC','显示用户参数并允许用户在个人资料页面进行修改.');
DEFINE('_UE_REG_CB_EMAILPASS','自动生成随机注册密码');
DEFINE('_UE_REG_CB_EMAILPASS_DESC','是否自动生成密码并通过emailed发送给用户(开启此功能时) 或者在注册页面询问用户 (关闭此功能时,默认设置,推荐设置).');
DEFINE('_UE_REG_EMAILCHECKER','Ajax Email 检查器');
DEFINE('_UE_REG_EMAILCHECKER_WARNING','注意: 如果你的PHP系统未安装或未启用"getmxrr()" . 如果未启用此PHP功能的话，Email DNS和SMTP 检查功能将不可用.');
DEFINE('_UE_REG_EMAILCHECKER_DESC','允许检查注册过程中的email地址是否真实有效,检查email格式、已存在的MX DNS 记录, 以及相应的Email服务器通过SMTP使用此Email地址接受邮件的信息.同样可以检查Email地址是否被真实的注册过.注意:此附加功能可能会导致"侵犯隐私权"，请遵守所在国相关法律.当注册时，任何人都可以使用此功能来检测所写email是否被注册! 请在仔细研究你所在国家的法律和空间上的规定后，启用此功能. 使用SMTP检查功能需要你的服务器拥有一个固定IP地址, 站点所填写的email地址必须有效,且此服务器需在Email服务器的认证服务器里表(SPF记录)内. 需要注意的是虽然此功能已经设置保护但在一些特殊情况下此功能可能被滥用. 此功能尚处在测试过程中,且未对大型站点做任何优化:请使用前详细测试 !');
DEFINE('_UE_REG_EMAILCHECKER_VALID_EMAIL_ONLY','是, 仅检查Email服务器接收邮件功能');
DEFINE('_UE_REG_EMAILCHECKER_NOT_REGISTERED_AND_VALID_EMAIL','是,检查Email是否真实注册和服务器信息 (!!!注意请勿侵犯隐私权)');
DEFINE('_UE_REG_UNIQUEEMAIL','检查E-mail唯一性');
DEFINE('_UE_REG_UNIQUEEMAIL_DESC','开启此功能时仅允许同一 Email 注册一个用户. 这是CMS全局设定参数,CB将根据此设定自动修改参数.');

// 1.2 FIREBOARD support - these strings are actually used in a CB tab and fields that are added by FB backend
DEFINE('_UE_FB_TABTITLE', '论坛设定' );
DEFINE('_UE_FB_ORDERING_OLDEST', '较早的在前' );
DEFINE('_UE_FB_ORDERING_LATEST', '较新的在前' );
DEFINE('_UE_FB_ORDERING_TITLE', '消息排序' );
DEFINE('_UE_FB_SIGNATURE', '你的论坛签名' );
DEFINE('_UE_FB_VIEWTYPE_FLAT', '查看所有' );
DEFINE('_UE_FB_VIEWTYPE_THREADED', '查看发帖' );
DEFINE('_UE_FB_VIEWTYPE_TITLE', '浏览模式偏好' );
DEFINE('_UE_FB_TABDESC', '普通资料选项' );
// 1.2 Extended forum strings for FIREBOARD favorites support in CB plugin (this is why they have _FB_ instead of _FORUM)
DEFINE('_UE_FB_FAVORITES','收藏夹');
DEFINE('_UE_FB_REMOVE_FAVORITE_THREAD','::删除收藏链接 ::');
DEFINE('_UE_FB_NO_FAVORITES_FOUND','收藏夹内无任何内容');
DEFINE('_UE_FB_REMOVE_FAVORITES_ALL','删除收藏夹内所有内容');
DEFINE('_UE_FB_CONFIRMUNFAVORITEALL','情确认删除收藏夹内所有内容 ?');

// 1.2 CB Team extensions
DEFINE('_UE_PROFILE_GALLERY','个人资料图库');
DEFINE('_UE_PROFILE_GALLERY_DESC','此标签页展示一个基本的图片库');
DEFINE('_UE_PROFILE_GALLERY_MODERATION','待审核图片');
DEFINE('_UE_PROFILE_GALLERY_MODERATION_DESC','此标签页内包含所有未经过认证的图片');
DEFINE('_UE_PROFILE_BOOK','个人资料薄');
DEFINE('_UE_PROFILE_BOOK_DESC','个人资料薄描述信息');

// 1.2 CB beta 8+9+10:
DEFINE('_UE_AVATAR_DISCLAIMER','点击 "%s"前,请确认你有权限使用该图片，任何侵犯他人权利的图片会直接导致账户被封禁.');
DEFINE('_UE_AVATAR_DISCLAIMER_TERMS','点击 "%s"钱, 请确认你有权限使用该图片,并确认该图片未违反%s.');
DEFINE('_UE_AGE','Age');
DEFINE('_UE_CLOAKED','此Email被反垃圾邮件程序所保护，查看前请开启浏览器的JavaScript功能');
DEFINE ('_UE_YEAR','年');
DEFINE ('_UE_MONTHS','月');
DEFINE ('_UE_MONTH','月');
DEFINE ('_UE_DAYS','日');
DEFINE ('_UE_DAY','日');
DEFINE ('_UE_HOURS','小时');
DEFINE ('_UE_HOUR','小时');
DEFINE ('_UE_MINUTES','分钟');
DEFINE ('_UE_MINUTE','分钟');
DEFINE ('_UE_SECONDS','秒');
DEFINE ('_UE_SECOND','秒');
DEFINE ('_UE_ANYTHING_AGO','%s 之前');
DEFINE ('_UE_NOW','现在');
DEFINE ('_UE_YEAR_NOT_IN_RANGE','年份 %s 请在 %s ～ %s范围内');
DEFINE ('_UE_ADD_IMAGE','添加图片');
DEFINE ('_UE_LINE','线');
DEFINE ('_UE_COLUMN','列');
DEFINE ('_UE_MONTHS_1','一月');
DEFINE ('_UE_MONTHS_2','二月');
DEFINE ('_UE_MONTHS_3','三月');
DEFINE ('_UE_MONTHS_4','四月');
DEFINE ('_UE_MONTHS_5','五月');
DEFINE ('_UE_MONTHS_6','六月');
DEFINE ('_UE_MONTHS_7','七月');
DEFINE ('_UE_MONTHS_8','八月');
DEFINE ('_UE_MONTHS_9','九月');
DEFINE ('_UE_MONTHS_10','十月');
DEFINE ('_UE_MONTHS_11','十一月');
DEFINE ('_UE_MONTHS_12','十二月');
DEFINE ('_UE_NO_ANSWER','无答案');
DEFINE ('_UE_ANY','任何');
DEFINE ('_UE_TODAY','今天');
// 1.2 CB beta 8+9+10 backend:
DEFINE ('_UE_SHOWEMPTYTABS','显示空白标签');
DEFINE ('_UE_SHOWEMPTYTABS_DESC','显示所有标签(无论是否包含文字), 或仅显示有文字的标签');
DEFINE ('_UE_SHOWEMPTYFIELDS','显示空白区域');
DEFINE ('_UE_SHOWEMPTYFIELDS_DESC','显示所有空白区域（无论是否有任何内容），或仅显示有内容的部分');
DEFINE ('_UE_EMPTYFIELDSTEXT','显示在空白区域的文字信息');
DEFINE ('_UE_EMPTYFIELDSTEXT_DESC','显示在空白区域的文字信息. 多语言字段和区域替换功能同时起效. 字段 _UE_NO_ANSWER 将显示 "无答案".');
// 1.2 CB RC 2 beta 2:
DEFINE('_UE_USERNAME_OR_EMAIL','用户名或E-maile地址');
// 1.2 CB RC 2 beta 2 backend:
DEFINE('_UE_SAVE','保存');
DEFINE('_UE_LOGIN_TYPE','登录框内容设置');
DEFINE('_UE_LOGIN_TYPE_DESC','可选择下列四种模式中的任何一种设置登录框输入内容: 用户名+E-mail地址,用户名+密码,用户名+E-mail地址+密码, E-mail地址+密码. CB login 模块将根据此处的选择自动调整输入内容字符框..');
DEFINE('_UE_INCORRECT_EMAIL_OR_PASSWORD','E-Mail地址信息或密码错误.请仔细检查后重试.');
// 1.2 CB RC 4 frontend:
DEFINE('_UE_ERROR_IN_QUERY_TURN_SITE_DEBUG_ON_TO_VIEW','数据库查询有错误。网站管理员可以开启除错模式来查看并修复错误。');
// 1.2 CB RC 4 backend:
DEFINE('_UE_USERNAME_OR_AUTH','用户名, email 或启用的其它认证插件');
// 1.2 Stable:same as RC4
// 1.2.1 Stable:
DEFINE('_UE_MALE','男');
DEFINE('_UE_FEMALE','女');
// 1.2.2 backend:
DEFINE('_UE_DISPLAY_ROUNDED_DIV','带标题的圆角 div');
DEFINE('_UE_WRONG_CONFIRMATION_CODE','确认码错误。请对照您的 Email（或许邮件被误判为“垃圾邮件”了），填写正确的确认码。');
// 1.2.3:
DEFINE('_UE_LOST_YOUR_PASSWORD','忘记密码了？');
DEFINE('_UE_LOST_PASSWORD_EMAIL_ONLY_DESC','如果您 <strong>忘记了密码</strong>，请输入您的 E-mail 地址，然后点击“取回密码”按钮，您将很快收到新密码。然后您就可以使用这个新密码登录我们网站了。');
// 1.4 Stable:
DEFINE('_UE_ENABLESPOOFCHECK','启用反欺诈 sessions 检查');
DEFINE('_UE_ENABLESPOOFCHECK_DESC','你是否希望开启针对会话（session）的欺诈检查？ （强烈推荐使用，除非你启用之后发生了 session 过期或者 cookie 错误问题，那么请禁用）。默认是禁用状态，以便获得最佳的稳定性和可用性。');

// IMPORTANT WARNING: The closing tag, "?" and ">" has been intentionally omitted - CB works fine without it.
// This was done to avoid errors caused by custom strings being added after the closing tag. ]
// With such tags, always watchout to NOT add any line or space or anything after the "?" and the ">".


// added for plug-in cbprofilebook
DEFINE('_pb_ProfileBook','私人留言本');
DEFINE('_pb_EnableProfileBook','启用私人留言本');
DEFINE('_pb_AutoPublish','留言自动发布');
DEFINE('_pb_NotifyMe','接收留言通知');

// added for plug-in Geocoding
DEFINE('Geocoding','地理标签');
DEFINE('Manually Enter Lat/Lng','手动输入纬度/经度');
DEFINE('Latitude','纬度（Latitude）');
DEFINE('Longitude','经度（Longitude）');

// added by baijianpeng for CB Confirm Email plugin
if (!defined('_UE_CONFIRMEMAIL_Label')) DEFINE('_UE_CONFIRMEMAIL_Label','再次输入 Email');
if (!defined('_UE_CONFIRMEMAIL_Enter_Label')) DEFINE('_UE_CONFIRMEMAIL_Enter_Label','再次输入 Email');
if (!defined('_UE_CONFIRMEMAIL_NOT_VALID')) DEFINE('_UE_CONFIRMEMAIL_NOT_VALID','两次输入的 Email 地址不一致');
if (!defined('_UE_CONFIRMEMAIL_Desc')) DEFINE('_UE_CONFIRMEMAIL_Desc','请再次输入一次您的 email 地址以避免输错');
