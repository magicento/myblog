<?php
/*************************************************************
* Joomla Community Builder
* @version $Id: simplified_chinese.php 315 2008-04-01 18:00:00Z baijianpeng&Eric Cheng $
* @package Community Builder
* @subpackage simplified chinese Language file (JianTi ZhongWen)
* @author http://www.joomlagate.com http://www.webtmp.cn
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
*************************************************************/



// ensure this file is being included by a parent file:
if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

//Field Labels
DEFINE('_UE_HITS','點閱');
DEFINE('_UE_USERNAME','用戶名稱');
DEFINE('_UE_Address','地址');
DEFINE('_UE_City','縣/市');
DEFINE('_UE_State','省/州');
DEFINE('_UE_PHONE','電話 #');
DEFINE('_UE_FAX','傳真 #');
DEFINE('_UE_ZipCode','郵遞區號');
DEFINE('_UE_Country','國家');
DEFINE('_UE_Occupation','職業');
DEFINE('_UE_Company','公司');
DEFINE('_UE_Interests','興趣');
DEFINE('_UE_Birthday','生日');
DEFINE('_UE_AVATAR','圖片');
DEFINE('_UE_Website','網站');
DEFINE('_UE_Location','地區');
DEFINE('_UE_EDIT_TITLE','編輯您的個人檔案');
DEFINE('_UE_YOUR_NAME','姓名');
DEFINE('_UE_EMAIL','E-Mail');
DEFINE('_UE_UNAME','用戶名稱');
DEFINE('_UE_PASS','密碼');
DEFINE('_UE_VPASS','驗證密碼');
DEFINE('_UE_SUBMIT_SUCCESS','提交成功!');
DEFINE('_UE_SUBMIT_SUCCESS_DESC','您的項目已經成功的提交給網站管理員, 將會在審核后發布于網站上.');
DEFINE('_UE_WELCOME','歡迎!');
DEFINE('_UE_WELCOME_DESC','歡迎來到我們網站的用戶專區');
DEFINE('_UE_CONF_CHECKED_IN','檢查項目目前都已經回存');
DEFINE('_UE_CHECK_TABLE','檢查表格');
DEFINE('_UE_CHECKED_IN','回存');
DEFINE('_UE_CHECKED_IN_ITEMS',' 項目');
DEFINE('_UE_PASS_MATCH','密碼不相符');
DEFINE('_UE_USERNAME_DESC','設為&quot;是&quot;將允許用戶帳號被修改. 如果設為&quot;否&quot;,用戶帳號註冊后將無法被修改.');
DEFINE('_UE_ALLOW_EMAIL_USERCONTR','用戶隱藏 E-mail');
DEFINE('_UE_ALLOW_EMAIL_USERCONTR_DESC','&quot;是&quot;.將允許用戶能夠于公開的資訊中隱藏個人的E-Mail. 注: 這個設定只能夠于這個元件之中控制顯示 E-Mail!');
DEFINE('_UE_USERAPPROVAL_SUCCESSFUL','用戶將成功地被允許!');

//Front End Profile Lables
DEFINE('_UE_MEMBERSINCE','註冊日期');
DEFINE('_UE_LASTONLINE','最后登入日期');
DEFINE('_UE_ONLINESTATUS','在線狀態');
DEFINE('_UE_ISONLINE','在線');
DEFINE('_UE_ISOFFLINE','離線');
DEFINE('_UE_PROFILE_TITLE',' 個人檔案頁');
DEFINE('_UE_UPDATEPROFILE','更新您的個人檔案');
DEFINE('_UE_UPDATEAVATAR','更新您的照片');
DEFINE('_UE_CONTACT_INFO_HEADER','聯絡資訊');
DEFINE('_UE_ADDITIONAL_INFO_HEADER','額外資訊');
DEFINE('_UE_REQUIRED_ERROR','必填欄位!');
DEFINE('_UE_FIELD_REQUIRED',' 必填!');
DEFINE('_UE_DELETE_AVATAR','刪除圖片');

//Administrator Tab Names
DEFINE('_UE_USERPROFILE','用戶資訊');
DEFINE('_UE_USERLIST','用戶列表');
DEFINE('_UE_AVATARS','圖片');
DEFINE('_UE_REGISTRATION','註冊');
DEFINE('_UE_SUBSCRIPTION','訂閱');
DEFINE('_UE_INTEGRATION','整合');

//Administrator Labels
DEFINE('_UE_FIELD_NAME','欄位名稱');
DEFINE('_UE_EXPLANATION','說明');
DEFINE('_UE_FIELD_EXPLAINATION','決定若是您要這個欄位設定為必填欄位或者是否顯示于會員資訊中.');
DEFINE('_UE_CONFIG','設定');
DEFINE('_UE_CONFIG_DESC','修改設定');
DEFINE('_UE_VERSION','您所使用的版本是 ');
DEFINE('_UE_BY','CB 是針對 Joomla 1.0 及 1.5，Mambo 4.5.2 平臺的自訂元件，開發者：');
DEFINE('_UE_CURRENT_SETTINGS','目前的設定');
DEFINE('_UE_A_EXPLANATION','說明');
DEFINE('_UE_DISPLAY','顯示?');
DEFINE('_UE_REQUIRED','必填?');
DEFINE('_UE_YES','是');
DEFINE('_UE_NO','否');

//Admin Avatar Tab Labels
DEFINE('_UE_AVATAR_DESC','設為&quot;是&quot;, 如果您要讓已註冊用戶可以使用個人圖片功能 (透過個人檔案管理)');
DEFINE('_UE_AVHEIGHT','最大圖片高度');
DEFINE('_UE_AVWIDTH','最大圖片寬度');
DEFINE('_UE_AVSIZE','最大圖片大小<br/><b>單位: Kb</b>');
DEFINE('_UE_AVATARUPLOAD','允許圖片上傳');
DEFINE('_UE_AVATARUPLOAD_DESC','設為 &quot;是&quot; 如果您要讓已註冊用戶可以自行上傳個人圖片.');
DEFINE('_UE_AVATARGALLERY','使用圖片畫廊');
DEFINE('_UE_AVATARGALLERY_DESC','設為 &quot;是&quot; 如果您要讓已註冊用戶可以由圖片畫廊中選擇圖像.');
DEFINE('_UE_TNWIDTH','最大縮圖寬度');
DEFINE('_UE_TNHEIGHT','最大縮圖高度');

//Admin User List Tab Labels
DEFINE('_UE_USERLIST_TITLE','用戶清單標題');
DEFINE('_UE_USERLIST_TITLE_DESC','用戶清單標題');
DEFINE('_UE_LISTVIEW','清單');
DEFINE('_UE_PICTLIST','圖片清單');
DEFINE('_UE_PICTDETAIL','圖片細節');
DEFINE('_UE_NUM_PER_PAGE','用戶每頁');
DEFINE('_UE_NUM_PER_PAGE_DESC','每頁顯示用戶數量');
DEFINE('_UE_VIEW_TYPE','顯示類型');
DEFINE('_UE_VIEW_TYPE_DESC','顯示類型');
DEFINE('_UE_ALLOW_EMAIL','E-Mail 連結');
DEFINE('_UE_ALLOW_EMAIL_DESC','允許 E-Mail 連結. 注: 這個設定只會應用于自訂的 E-Mail 欄位中');
DEFINE('_UE_ALLOW_WEBSITE','網站連結');
DEFINE('_UE_ALLOW_WEBSITE_DESC','允許網站連結');
DEFINE('_UE_ALLOW_IM','即時資訊連結');
DEFINE('_UE_ALLOW_IM_DESC','允許即時資訊連結');
DEFINE('_UE_ALLOW_ONLINESTATUS','在線狀態');
DEFINE('_UE_ALLOW_ONLINESTATUS_DESC','顯示在線狀態');
DEFINE('_UE_ALLOW_EMAIL_DISPLAY_DESC','注: 這個設定只會應用在用戶主要的 E-Mail 地址.');
DEFINE('_UE_ALLOW_EMAIL_REPLYTO','Emails 寄出 "從:"');
DEFINE('_UE_ALLOW_EMAIL_REPLYTO_DESC','寄給用戶 Email 的范本設定: 寄出者格式: 選擇從:<ol>'
		.'<li>"從:" 用戶 Email 地址 (沒有 "Reply-To:" 欄位:<br/>用戶收到所有的回信以及錯誤舉報, 獲得較好的隱私權)</li>'
		.'<li>"從:" 管理員 Email 地址, 以及 "Reply-To:" 用戶 Email 地址:<br/>這是 SPF spam-checking compliant, 但是管理員可能會收到錯誤的回信</li></ol>');
DEFINE('_UE_A_FROM_USER', '用戶地址');
DEFINE('_UE_A_FROM_ADMIN', '管理員, "Reply-To": 用戶');

//Admin Moderate Tab labels
DEFINE('_UE_MODERATE','群組管理');
DEFINE('_UE_AVATARUPLOADAPPROVALGROUP','版主群組');
DEFINE('_UE_AVATARUPLOADAPPROVALGROUP_DESC','所選擇的群組中的所有用戶及其以上都將成為版主.');
DEFINE('_UE_ALLOWUSERREPORTS','允許用戶舉報');
DEFINE ('_UE_ALLOWUSERREPORTS_DESC','允許用戶舉報有不當行為的用戶給版主.');
DEFINE ('_UE_AVATARUPLOADAPPROVAL','需要上傳圖片審核');
DEFINE ('_UE_AVATARUPLOADAPPROVAL_DESC','所有經由用戶上傳的圖片皆必須審核通過后才會被顯示.');
DEFINE ('_UE_ALLOWUSERPROFILEBANNING_DESC','讓板主去預防用戶個人檔案被公開顯示.');
DEFINE ('_UE_ALLOWUSERPROFILEBANNING','允許個人檔案停用');

//Admin Registration tab labels
DEFINE('_UE_NAME_FORMAT','姓名格式');
DEFINE('_UE_DATE_FORMAT','日期格式');
DEFINE('_UE_NAME_FORMAT_DESC','選擇您想要顯示的 姓名/用戶名稱 欄位格式.');
DEFINE('_UE_DATE_FORMAT_DESC','選擇您想要顯示的 日期 欄位格式.');
DEFINE ('_UE_REG_CONFIRMATION_DESC','設為 &quot;是&quot; 系統將在用戶註冊完成以后寄送內附確認連結的 E-Mail 給會員.');
DEFINE ('_UE_REG_CONFIRMATION','需要 E-Mail 確認');
DEFINE ('_UE_REG_ADMIN_APPROVAL','需要管理員批準');
DEFINE ('_UE_REG_ADMIN_APPROVAL_DESC','所有的用戶註冊都須經由管理員批準');
DEFINE ('_UE_REG_EMAIL_NAME','註冊 E-Mail 名稱');
DEFINE ('_UE_REG_EMAIL_NAME_DESC','請輸入您在寄送 Email 時所要顯示的名稱');
DEFINE ('_UE_REG_EMAIL_FROM','註冊 E-Mail 地址');
DEFINE ('_UE_REG_EMAIL_FROM_DESC','當寄信給註冊者時您想要顯示的 E-Mail 地址');
DEFINE ('_UE_REG_EMAIL_REPLYTO','註冊回信的 E-Mail');
DEFINE ('_UE_REG_EMAIL_REPLYTO_DESC','您所要使用的回信 E-Mail 地址');
DEFINE ('_UE_REG_PEND_APPR_MSG','等候批準的 Email');
DEFINE ('_UE_REG_WELCOME_MSG','歡迎加入的 Email');
DEFINE ('_UE_REG_REJECT_MSG','駁回的 E-Mail');
DEFINE ('_UE_REG_PEND_APPR_SUB','等待批準的主題');
DEFINE ('_UE_REG_WELCOME_SUB','歡迎的主題');
DEFINE ('_UE_REG_PEND_APPR_SUB_DESC','等待批準的主題');
DEFINE ('_UE_REG_WELCOME_SUB_DESC','歡迎的主題');
DEFINE ('_UE_REG_REJECT_SUB_DESC','駁回的主題');
DEFINE ('_UE_REG_SIGNATURE','E-Mail 簽名');
DEFINE ('_UE_REG_ADMIN_PA_SUB','動作要求! 新的註冊用戶正等待批準');
DEFINE ('_UE_REG_ADMIN_PA_MSG','一位新的用戶已經在 [SITEURL] 註冊并且等待批準.\n'
.'這封郵件包含了他們的詳細資料\n\n'
.'姓名 - [NAME]\n'
.'E-Mail - [EMAILADDRESS]\n'
.'用戶名稱 - [USERNAME]\n\n\n'
.'請不要回覆這份由系統自動產生出來的資訊，因為這只是一份舉報用的郵件而已\n');
DEFINE ('_UE_REG_ADMIN_SUB','新用戶註冊');
DEFINE ('_UE_REG_ADMIN_MSG','一位新用戶已經在 [SITEURL] 註冊.\n'
.'這封郵件包含了他們的詳細資料\n\n'
.'會員名稱 - [NAME]\n'
.'E-Mail - [EMAILADDRESS]\n'
.'用戶名稱 - [USERNAME]\n\n\n'
.'請不要回覆這份由系統自動產生出來的資訊，因為這只是一份舉報用的郵件而已\n');
DEFINE('_UE_REG_EMAIL_TAGS','[NAME] - <b>用戶姓名</b><br />'
.'[USERNAME] - 用戶名稱<br />'
.'[DETAILS] - 帳號詳細資訊譬如 E-Mail 地址、用戶名稱<br />'
.'[PASSWORD] - 用戶所選的密碼 (只在按下"註冊"所寄出的第一封 email)<br />'
.'[CONFIRM] - 如果確認功能已經啟動將會加入確認連結<br />'
.'[FIELDNAME] - 這將會把跟此用戶相關的值加到要寄出的 Email 地址. 只要在 [ ] 之間加入您想要的資料庫欄位名稱.<br />'
);

//Registration form
DEFINE('_UE_REG_COMPLETE_NOPASS','<div class="componentheading">註冊完成!</div>'
.'您的密碼已經寄送到您所輸入的E-Mail當中了.<br />&nbsp;&nbsp;'
.'當您收到密碼后就可以登入了');
DEFINE('_UE_REG_COMPLETE','<div class="componentheading">註冊完成!</div><br />&nbsp;&nbsp;'
.'您現在可以登入了.<br />&nbsp;&nbsp;');
DEFINE('_UE_REG_COMPLETE_NOPASS_NOAPPR','<div class="componentheading">註冊完成!</div><br />&nbsp;&nbsp;'
.'您的註冊資料需要批準. 一旦批準后您的密碼將傳送到您所輸入的 E-Mail 地址.<br />&nbsp;&nbsp;'
.'當您收到批準以及密碼后就可以登入了');
DEFINE('_UE_REG_COMPLETE_NOAPPR','<div class="componentheading">註冊完成!</div><br />&nbsp;&nbsp;'
.'您的註冊資料需要批準. 一旦批準后您將會收到一份已接受的通知信到您所輸入的 Email 地址.<br />&nbsp;&nbsp;'
.'當您收到批準后就可以登入了.');
DEFINE('_UE_REG_COMPLETE_CONF','<div class="componentheading">註冊完成!</div><br />'
.'<p>一封告知您如何完成您註冊手續的郵件已經寄送到您提供的電子郵件地址. 請檢查您的電子郵件來完成您的註冊.</p>'
.'<p>請檢查您的信箱(包括“垃圾郵件”目錄) 來完成註冊過程.</p>'
.'<p>如果想讓系統再次寄送激活郵件，只需嘗試用你的用戶名和密碼登入一下即可。</p>');
DEFINE('_UE_REG_COMPLETE_NOPASS_CONF','<div class="componentheading">註冊完成!</div><br />&nbsp;&nbsp;'
.'您的密碼已經傳送到您所輸入的 E-Mail 中.<br />&nbsp;&nbsp;'
.'當您收到您的密碼和遵照註冊確認指示就可以進行登入.');

// User List Labels
DEFINE ('_UE_HAS','已擁有');
DEFINE ('_UE_USERS','個註冊用戶');
DEFINE ('_UE_SEARCH_ALERT','請輸入一個值來搜尋!');
DEFINE ('_UE_SEARCH','尋找用戶');
DEFINE ('_UE_ENTER_EMAIL','輸入用戶 E-Mail, 姓名或用戶名稱');
DEFINE ('_UE_SEARCH_BUTTON','搜尋');
DEFINE ('_UE_SHOW_ALL','顯示所有用戶');
DEFINE ('_UE_NAME','姓名');
DEFINE ('_UE_UL_USERNAME','用戶名稱');
DEFINE ('_UE_USERTYPE','用戶類型');
DEFINE ('_UE_VIEWPROFILE','檢視個人檔案');
DEFINE ('_UE_LIST_ALL','列出所有');
DEFINE ('_UE_PAGE','頁');
DEFINE ('_UE_RESULTS','結果');
DEFINE ('_UE_OF_TOTAL','共計');
DEFINE ('_UE_NO_RESULTS','沒有結果');
DEFINE ('_UE_FIRST_PAGE','最前頁');
DEFINE ('_UE_PREV_PAGE','上一頁');
DEFINE ('_UE_NEXT_PAGE','下一頁');
DEFINE ('_UE_END_PAGE','最后頁');
DEFINE('_UE_CONTACT','連絡');
DEFINE('_UE_INSTANT_MESSAGE','即時訊息');
DEFINE('_UE_IMAGEAVAILABLE','照片');
DEFINE('_UE_INFO','資訊');
DEFINE('_UE_PROFILE','個人檔案');
DEFINE('_UE_PRIVATE_MESSAGE','站內信');
DEFINE('_UE_ADDITIONAL','額外資訊');
DEFINE('_UE_NO_DATA','沒有提供');
DEFINE('_UE_CLICKTOVIEW','點擊前往');
DEFINE('_UE_CLICKTOSORTBY','點擊使用 %s 為排序');		// %s replaced by sorting name
DEFINE('_UE_UL_USERNAME_NAME','用戶名稱(姓名)');

//mod_userextraslogin
DEFINE('_UE_NO_ACCOUNT','尚無帳號?');
DEFINE('_UE_CREATE_ACCOUNT','創建一個');
DEFINE('_UE_REGISTER','註冊');
DEFINE('_UE_FORGOT_PASSWORD','忘記密碼?');
DEFINE('_LOGIN_NOT_CONFIRMED','您的註冊程序尚未完成! 請檢查您的 E-Mail 觀看剛剛重寄的更進一步的指示. 如您未發現信件, 請檢查您的垃圾郵件目錄. 并請確定您的電子信箱帳號不會馬上刪除垃圾信. 如果已經發生了, 就重新再嘗試登入以獲得另一封新的指示信件');
DEFINE('_LOGIN_NOT_APPROVED','您的帳號尚未被批準!');
DEFINE('_UE_USER_CONFIRMED','您的帳號目前已經啟用, 您可以進行登入!');
DEFINE('_UE_USER_NOTCONFIRMED','您的帳號目前尚未啟動, 請檢查您的 E-Mail 并遵循指示來完成您的註冊程序.');


//Avatar
DEFINE('_UE_UPLOAD_UPLOAD','上傳');
DEFINE('_UE_UPLOAD_SUBMIT','提交一張新照片來上傳');
DEFINE('_UE_UPLOAD_SELECT_FILE','選擇檔案');
DEFINE('_UE_UPLOAD_ERROR_TYPE','請只使用 jpeg, jpg 或者 png 格式圖片');
DEFINE('_UE_UPLOAD_ERROR_EMPTY','上傳前請先選擇一個檔案');
DEFINE('_UE_UPLOAD_ERROR_NAME','圖片檔名僅能包含英文字母或數字且不能有空格.');
DEFINE('_UE_UPLOAD_ERROR_SIZE','圖檔大小超出了管理員所設定的最大值.');
DEFINE('_UE_UPLOAD_ERROR_WIDTHHEIGHT','圖片的高度或寬度超出了管理員所設定的最大值.');
DEFINE('_UE_UPLOAD_ERROR_WIDTH','圖檔的寬度超出了管理員所設定的最大值.');
DEFINE('_UE_UPLOAD_ERROR_HEIGHT','圖檔的高度超出了管理員所設定的最大值.');
DEFINE('_UE_UPLOAD_ERROR_CHOOSE','您尚未由藝廊中選擇一個圖片...');
DEFINE('_UE_UPLOAD_UPLOADED','您的照片已經上傳.');
DEFINE('_UE_UPLOAD_GALLERY','由圖片庫中選擇一個');
DEFINE('_UE_UPLOAD_CHOOSE','確認選擇');
DEFINE('_UE_UPLOAD_UPDATED','您的照片已被設定.');
DEFINE('_UE_USER_PROFILE_NOT','您的個人檔案無法被更新.');
DEFINE('_UE_USER_PROFILE_UPDATED','您的個人檔案已經更新.');
DEFINE('_UE_USER_RETURN_A','如果您在幾秒內未被帶回個人檔案頁面');
DEFINE('_UE_USER_RETURN_B','點擊這里');
//DEFINE('_UPDATE','更新');

//Moderator
DEFINE('_UE_USERPROFILEBANNED','這個個人檔案已經遭到版主停用.');
DEFINE('_UE_REQUESTUNBANPROFILE','請求取消停用');
DEFINE('_UE_REPORTUSER','舉報用戶');
DEFINE('_UE_BANPROFILE','停用個人檔案');
DEFINE('_UE_UNBANPROFILE','取消停用個人檔案');
DEFINE('_UE_REPORTUSER_TITLE','舉報用戶');
DEFINE('_UE_USERREASON','舉報用戶的原因');
DEFINE('_UE_BANREASON','停用的原因');
DEFINE('_UE_SUBMITFORM','提交');
DEFINE('_UE_NOUNBANREQUESTS','沒有取消停用的請求需要處理');
DEFINE('_UE_IMAGE_MODERATE','管理圖片');
DEFINE('_UE_APPROVE_IMAGE','批準圖片');
DEFINE('_UE_REJECT_IMAGE','駁回圖片');
DEFINE('_UE_MODERATE_TITLE','版主');
DEFINE('_UE_NOIMAGESTOAPPROVE','沒有圖片需要處理');
DEFINE('_UE_USERREPORT_MODERATE','管理用戶舉報');
DEFINE('_UE_REPORT','舉報');
DEFINE('_UE_REPORTEDONDATE','舉報日期');
DEFINE('_UE_REPORTEDUSER','舉報用戶');
DEFINE('_UE_REPORTEDBY','舉報由');
DEFINE('_UE_PROCESSUSERREPORT','處理');
DEFINE('_UE_NONEWUSERREPORTS','沒有新的用戶舉報');
DEFINE('_UE_USERUNBAN_SUCCESSFUL','成功地取消被停用的用戶個人檔案.');
DEFINE('_UE_REPORTUSERSACTIVITY','描述用戶活動');
DEFINE('_UE_USERREPORT_SUCCESSFUL','用戶舉報成功地提交了.');
DEFINE('_UE_USERBAN_SUCCESSFUL','用戶個人檔案成功地被停用.');
DEFINE('_UE_FUNCTIONALITY_DISABLED','此項功能目前停用中.');
DEFINE('_UE_UPLOAD_PEND_APPROVAL','您的照片目前等待版主批準中.');
DEFINE('_UE_UPLOAD_SUCCESSFUL','您的照片已成功上傳.');
DEFINE('_UE_UNBANREQUEST','取消停用個人檔案請求');
DEFINE('_UE_USERUNBANREQUEST_SUCCESSFUL','您取消停用的要求已經成功地提交.');
DEFINE('_UE_USERREPORT','用戶舉報');
DEFINE('_UE_VIEWUSERREPORTS','檢視用戶舉報');
DEFINE('_UE_USERREQUESTRESPONSE','檢視用戶舉報');
DEFINE('_UE_MODERATORREQUESTRESPONSE','檢視用戶舉報');
DEFINE('_UE_REPORTBAN_TITLE','停用報告');
DEFINE('_UE_REPORTUNBAN_TITLE','停用報告');

DEFINE('_UE_UNBANREQUIREACTION',' 取消停用請求');
DEFINE('_UE_USERREPORTSREQUIREACTION','用戶舉報');
DEFINE('_UE_IMAGESREQUIREACTION','圖片');
DEFINE('_UE_NOACTIONREQUIRED','沒有等待處理中的事件');

DEFINE('_UE_UNBAN_MODERATE','取消停用個人檔案請求');
DEFINE('_UE_BANNEDUSER','遭停用用戶');
DEFINE('_UE_BANNEDREASON','停用原因');
DEFINE('_UE_BANNEDON','停用日期');
DEFINE('_UE_BANNEDBY','停用由');

DEFINE('_UE_MODERATORBANRESPONSE','版主回應');
DEFINE('_UE_USERBANRESPONSE','用戶回應');

DEFINE('_UE_IMAGE_ADMIN_SUB','圖片等待批準中');
DEFINE('_UE_IMAGE_ADMIN_MSG','一位用戶已提交圖片等待批準. 請登入進行適當的處理.');
DEFINE('_UE_USERREPORT_SUB','用戶舉報等待檢閱中');
DEFINE('_UE_USERREPORT_MSG','有一位用戶提交了關于另一位用戶的舉報且需要您的檢閱. 請登入進行適當的處里.');
DEFINE('_UE_IMAGEAPPROVED_SUB','圖片已批準');
DEFINE('_UE_IMAGEAPPROVED_MSG','您的照片已經被版主批準了');
DEFINE('_UE_IMAGEREJECTED_SUB','圖片駁回');
DEFINE('_UE_IMAGEREJECTED_MSG','您的照片已經被版主給駁回了. 請登入并提交一個新的圖片.');
DEFINE('_UE_BANUSER_SUB','用戶個人檔案已停用.');
DEFINE('_UE_BANUSER_MSG','您的用戶個人檔案已遭到管理員停用,請登入并檢閱遭停用的原因.');
DEFINE('_UE_UNBANUSER_SUB','用戶個人檔案已取消停用');
DEFINE('_UE_UNBANUSER_MSG','您的用戶個人檔案已被管理員取消停用了. 您的個人檔案目前可以再給所有用戶觀看.');
DEFINE('_UE_UNBANUSERREQUEST_SUB','取消停用請求等待檢閱中');
DEFINE('_UE_UNBANUSERREQUEST_MSG','一位用戶提出取消停用個人檔案的申請. 請登入進行適當的處里.');


//Alpha 3 Build
DEFINE('_UE_IMAGE','縮圖');
DEFINE('_UE_FORMATNAME','名稱格式');

//Alpha 4 Build
DEFINE('_UE_ADMINREQUIREDFIELDS','管理員必須的欄位');
DEFINE('_UE_ADMINREQUIREDFIELDS_DESC','設為是可以讓管理員遵守用戶管理欄位的必要設定.設為否將在管理員的用戶管理忽略必須的狀態.');
DEFINE('_UE_CANCEL','取消');
DEFINE('_UE_NA','N/A');
DEFINE('_UE_MODERATOREMAIL','寄送 E-Mail 給版主');
DEFINE('_UE_MODERATOREMAIL_DESC','設為是則當發生需要版主注意時版主將收到email.');

//Beta 1 Build
DEFINE('_UE_UPDATE','更新');

//Beta 2 Build
DEFINE('_UE_FIELDONPROFILE','此欄位在個人檔案可見');
DEFINE('_UE_FIELDNOPROFILE','此欄位在個人檔案不可見');
DEFINE('_UE_FIELDREQUIRED','此欄位必填');
DEFINE('_UE_NOT_AUTHORIZED','您沒有權限觀看此頁面的內容!');
DEFINE('_UE_ALLOW_LISTVIEWBY','允許存取到:');
DEFINE('_UE_ALLOW_LISTVIEWBY_DESC','選擇一個您想要觀看清單的群組. 此等級的所有用戶或等級更高的都可以存取.');
DEFINE('_UE_ALLOW_PROFILEVIEWBY','允許群取到:');
DEFINE('_UE_ALLOW_PROFILEVIEWBY_DESC','選擇一個您想要看個人檔案的群組. 此等級的所有用戶或等級更高的都可以存取.');

//Beta 3 Build
DEFINE('_UE_NOLISTFOUND','沒有已發布的用戶清單!');
DEFINE('_UE_ALLOW_PROFILELINK','允許連結至用戶資料');
DEFINE('_UE_ALLOW_PROFILELINK_DESC','設為是可允許清單中用戶資料連結至該用戶個人檔案頁面,設為否, 則可防止連結到個人檔案.');
DEFINE('_UE_REGISTERFORPROFILE','請登入或註冊來檢視或修改您的個人檔案.');
DEFINE('_UE_UPLOAD_ERROR_GDNOTINSTALLED','GD2 Image Library 并非安裝或是架構在 PHP 系統之中!  請連絡您的系統管理員來關閉自動轉存圖片尺寸的功能.');
DEFINE('_UE_UPLOAD_ERROR_UPLOADFAILED','上傳/處理圖片時發生錯誤!');
DEFINE('_UE_TOC','同意服務條款與聲明');
DEFINE('_UE_TOC_REQUIRED','您進行註冊前必須同意服務條款與聲明!');
DEFINE('_UE_REG_TOC_MSG','啟用註冊服務條款與聲明');
DEFINE('_UE_REG_TOC_DESC','設為是則用戶必須同意服務條款與聲明后才能夠進行註冊!');
DEFINE('_UE_REG_TOC_URL_MSG','服務條款與聲明連結網址');
DEFINE('_UE_REG_TOC_URL_DESC','輸入服務條款與聲明的網址.');
DEFINE('_UE_LASTUPDATEDON','最后更新');

//Beta 4 Build
DEFINE('_UE_EMAILFORMWARNING','重要:<ol>'
		.'<li>您個人檔案的 email 地址是: <strong>%s</strong>.</li>'
		.'<li>請確認地址無誤還有您的阻擋垃圾信設定, 因為收信人將使用該地址來回信.</li>'
		.'<li>請注意信件可能無法寄達因為收信者的 email 還有阻擋垃圾信設定.</li>'
		.'</ol>');
DEFINE('_UE_EMAILFORMSUBJECT','主題:');
DEFINE('_UE_EMAILFORMMESSAGE','資訊:');
DEFINE('_UE_EMAILFORMTITLE','透過 email 寄送資訊至 %s');
DEFINE('_UE_GENERAL','一般');
DEFINE('_UE_SENDEMAILNOTICE',"------注意: ------\r\n\r\n此資訊是由 %s 在 %s ( %s )寄送給您. \r\n\r\n該用戶無法得知您的E-Mail. 直接回信收信者將知道您的 E-Mail 地址.");
DEFINE('_UE_SENDEMAILNOTICE_REPLYTO',"\r\n\r\n回信時, 請小心確認 %s 的 email 地址是 %s.");
DEFINE('_UE_SENDEMAILNOTICE_DISCLAIMER',"\r\n\r\n%s 所有者對于 email 的內容以及用戶的 email 地址無法負責.");
DEFINE('_UE_SENDEMAILNOTICE_MESSAGEHEADER',"\r\n\r\n\r\n------ 資訊從 %s 給您: ------\r\n\r\n");
DEFINE('_UE_SENDPMSNOTICE','注: 此資訊是由連線系統自動產生. 里面有要連接的用戶的地址, 如果您要可以讓您更方便的回信.');
DEFINE('_UE_SENDEMAIL','寄送 E-Mail');
DEFINE('_UE_SENTEMAILSUCCESS','您的 E-Mail已成功寄送!');
DEFINE('_UE_SENTEMAILFAILED','寄送您的 E-Mail失敗! 請再試一次.');
DEFINE('_UE_ALLOW_EMAIL_DISPLAY','E-Mail 處理中');
DEFINE('_UE_REGISTERDATE','註冊日期');
DEFINE('_UE_ACTION','執行');
DEFINE('_UE_USER','用戶');
DEFINE('_UE_USERAPPROVAL_MODERATE','用戶 批準/駁回');
DEFINE('_UE_USERPENDAPPRACTION','用戶');
DEFINE('_UE_APPROVEUSER','處理用戶');
DEFINE('_UE_REG_REJECT_SUB','您的註冊申請已經被駁回!');
DEFINE('_UE_USERREJECT_MSG',"您的註冊申請在 %s 已經被駁回, 以下為原因: \n%s");
DEFINE('_UE_COMMENT','拒絕注解');
DEFINE('_UE_APPROVE','批準');
DEFINE('_UE_REJECT','拒絕');
DEFINE('_UE_USERREJECT_SUCCESSFUL','用戶已成功被拒絕!');
DEFINE('_UE_USERAPPROVE_SUCCESSFUL','用戶已成功被批準!');
DEFINE('_LOGIN_REJECTED','您的註冊要求已經被拒絕!');
DEFINE('_UE_EMAILFOOTER','注: 這是來自于 %s (%s) 自動地產生的資訊.');
DEFINE('_UE_MODERATORUSERAPPOVAL','版主批準用戶');
DEFINE('_UE_MODERATORUSERAPPOVAL_DESC','此設定允許版主于網站前臺批準等待中的用戶.');
DEFINE('_UE_REG_COMPLETE_NOAPPR_CONF','<span class="componentheading">註冊完成!</span><br />&nbsp;&nbsp;'
.'您的註冊申請需要批準以及 E-Mail 確認. 請依照寄送給您的 E-Mail 中的確認步驟.一旦批準您將從您所輸入的 e-mail 地址收到接受通知.<br />&nbsp;&nbsp;'
.'當您收到批準后您就可以登入.');
DEFINE('_UE_REG_COMPLETE_NOPASS_NOAPPR_CONF','<span class="componentheading">註冊完成!</span><br />&nbsp;&nbsp;'
.'您的註冊申請需要批準以及 E-Mail 確認. 請依照寄送給您的 E-Mail 中的確認步驟. <br />&nbsp;&nbsp;'
.'當您收到批準后將會寄給您密碼, 您就可以登入了.');
DEFINE('_UE_NAME_STYLE','姓名格式');
DEFINE('_UE_NAME_STYLE_DESC','此姓名格式說明您如何從 Joomla/Mambo 中的姓名欄位擷取.');
DEFINE('_UE_USER_CONFIRMED_NEEDAPPR','感謝您確認您的 E-Mail 地址. 您的帳號需要版主批準. 您將收到 E-Mail 得知申請的結果.');
DEFINE('_UE_YOUR_FNAME','名');
DEFINE('_UE_YOUR_MNAME','中間名');
DEFINE('_UE_YOUR_LNAME','姓');

//RC 1 Build
DEFINE('_UE_NOSELFEMAIL','不允許您寄送 E-Mail 給自己!');
DEFINE('_UE_PROFILETAB','個人檔案');
DEFINE('_UE_AUTHORTAB','文章');
DEFINE('_UE_FORUMTAB','論壇');
DEFINE('_UE_BLOGTAB','Blog');
DEFINE('_UE_ARTICLEDATE','日期');
DEFINE('_UE_ARTICLETITLE','標題');
DEFINE('_UE_ARTICLERATING','評分');
DEFINE('_UE_ARTICLEHITS','點閱');
DEFINE('_UE_NESTTABS','巢狀表格');
DEFINE('_UE_NESTTABS_DESC','所有的表格資料都置入同一個個人檔案面板中, 當有大量的表格時這將很有用.');
DEFINE('_UE_MENUFORMATBAR','功能表列');
DEFINE('_UE_MENUFORMATLIST','菜單清單');
DEFINE('_UE_MENUFORMAT','菜單表示');
DEFINE('_UE_MENUFORMAT_DESC','選擇貫穿整個 Community Builder 的表示菜單的方式.');
DEFINE('_UE_TEMPLATEDIR','Community Builder 模版');
DEFINE('_UE_TEMPLATEDIR_DESC','選擇一種模版套用在Community Builder 中的表格, 工具圖示, 面板以及菜單.'
.'您可以使用 Community Builder 外掛管理來增加您的或其他人的模板.');
DEFINE('_UE_MINHITSINTV','最小點閱間隔 (分)');
DEFINE('_UE_MINHITSINTV_DESC','對用戶及其個人檔案設定最小的時間間隔來統計檢視以及點擊的次數. 預設為60分鐘 (一小時).');
DEFINE('_UE_XHTMLCOMPLY','W3C XHTML 1.0 Trans. 規范');
DEFINE('_UE_XHTMLCOMPLY_DESC','在某些 Joomla/Mambo 的模板中并不包含必要的聲明( &lt;?php mosShowHead(); ?&gt; ),'
.'這個設定是非必需的. 您可以檢查您模板中的 Index.php 檔案或是逕自開啟看看是否會在個人檔案表格中顯示.'
.'在目前釋出的版本, 我們相容于 W3C XHTML 的規范, 但是只有幾個頁面能夠完全符合.'
.'當然,您必須使用符合于 Joomla/Mambo 的模組規范才能夠有效的相容');
DEFINE('_UE_MAMBLOGNOTINSTALLED','Mamblog blogger 元件尚未安裝.  請連絡您的網站管理員.');
DEFINE('_UE_BLOGDATE','日期');
DEFINE('_UE_BLOGTITLE','標題');
DEFINE('_UE_BLOGHITS','點閱');
DEFINE('_UE_NOBLOGS','此用戶沒有已發布的Blog項目.');
DEFINE('_UE_NOARTICLES','此用戶沒有已發布的文章.');
DEFINE('_UE_IMPATH','ImageMagick 路徑');
DEFINE('_UE_IMPATH_DESC','ImageMagick 路徑');
DEFINE('_UE_NETPBMPATH','NetPBM 路徑');
DEFINE('_UE_NETPBMPATH_DESC','NetPBM 路徑');
DEFINE('_UE_AUTODET','自動偵測');
DEFINE('_UE_ERROR_NOTINSTALLED','尚未安裝');
DEFINE('_UE_CONVERSIONTYPE','圖片軟體');
DEFINE('_UE_NEWPASS_FAILED','密碼重設失敗!');
DEFINE('_UE_USER_SUBSCRIPTIONS','您的訂閱');
DEFINE('_UE_THREAD_UNSUBSCRIBE',':: 取消訂閱 ::');
DEFINE('_UE_USER_NOSUBSCRIPTIONS','沒有找到您的訂閱');
DEFINE('_UE_GEN_BY','由');
DEFINE('_UE_USER_UNSUBSCRIBE_ALL','取消所有訂閱');
DEFINE('_UE_USERREPORTMODERATED_SUCCESSFUL','用戶舉報管理成功!');
DEFINE('_UE_USERIMAGEMODERATED_SUCCESSFUL','用戶圖片管理成功!');
DEFINE('_UE_NOREPORTSTOPROCESS','沒有需處理的用戶舉報');
DEFINE('_UE_NOUSERSPENDING','沒有用戶等待批準');
DEFINE('_UE_BLANK','');
DEFINE('_UE_REG_FIRST_VISIT_URL_MSG','初次登入所瀏覽的網址');
DEFINE('_UE_REG_FIRST_VISIT_URL_DESC','輸入註冊之后初次登入所顯示的網址.這個頁面可以顯示你網站歡迎新用戶的資訊以及/或特別的注意事項,
或是重新導向用戶前往完成他的個人檔案填寫,
留下空白則代表第一次登入與平時登入相同.顯示用戶個人資料的頁面網址是
index.php?option=com_comprofiler&Itemid=1 (請將 Itemid=1 中的 ID 號替換你網站的真實菜單 ID).
');
DEFINE('_UE_NOSUCHPROFILE','此個人檔案不存在或是已經無法使用');

//RC 2
DEFINE('_UE_REG_INTRO_MSG','註冊時的介紹文字');
DEFINE('_UE_REG_INTRO_DESC','輸入 文字/html 顯示在註冊頁面的最上方'
.'或所屬的語系像是在 _UE_WELCOME_DESC 的文字設定. '
.'這個欄位的用途可以包含鼓勵新會員註冊以及所要注意的事項或是特殊的規定'
.'空白時將不會顯示任何內容.');
DEFINE('_UE_REG_CONCLUSION_MSG','註冊時結尾說明文字');
DEFINE('_UE_REG_CONCLUSION_DESC','輸入 文字/html 顯示于註冊頁面底下 '
.'或所屬的語言檔像是在 _UE_WELCOME_DESC 的文字設定. '
.'這個欄位可以包含一個感謝或是特別的簡介. '
.'空白時將不會顯示任何內容.');
DEFINE('_UE_USER_NOT_APPROVED','這個用戶尚未由版主批準!');
DEFINE('_UE_USER_NOT_CONFIRMED','這個用戶尚未確認他的 E-Mail 地址和帳號!');
//Connections
DEFINE('_UE_ADDCONNECTION','新增連線');
DEFINE('_UE_REMOVECONNECTION','移除連線');
DEFINE('_UE_CONNECTION','連線');
DEFINE('_UE_CONNECTIONACCEPTSUCCESSFULL','接受連線成功!');
DEFINE('_UE_CONNECTIONREMOVESUCCESSFULL','移除連線成功!');
DEFINE('_UE_CONNECTIONADDSUCCESSFULL','新增連線成功!');
DEFINE('_UE_CONNECTIONPENDINGACCEPTANCE','連線等待接收中!');
DEFINE('_UE_DIRECTCONNECTIONPENDINGACCEPTANCE','與 %s 的直接連線等待接受中!');
DEFINE('_UE_NOCONNECTIONS','此用戶目前尚無連線.');
DEFINE('_UE_NODIRECTCONNECTION','沒有直接連線.');
DEFINE('_UE_ACCEPTCONNECTION','接受連線');
DEFINE('_UE_CONNECTIONPENDING','連線等待中');
DEFINE('_UE_CONNECTEDSINCE','已連線自從');
DEFINE('_UE_CONNECTEDCOMMENT','注解');
DEFINE('_UE_CONNECTEDDETAIL','連線細節');
DEFINE('_UE_CONNECTIONREQUESTDETAIL','連線請求細節');
DEFINE('_UE_CONNECTIONREQUIREDON','要求連線于');
DEFINE('_UE_DECLINECONNECTION','拒絕連線');
DEFINE('_UE_FIELDDESCRIPTION','欄位敘述: 當滑鼠滑過圖示');
DEFINE('_UE_WEBURL','網站網址');
DEFINE('_UE_WEBTEXT','網站名稱');
DEFINE('_UE_CONNECTIONTYPE','類型');
DEFINE('_UE_CONNECTIONCOMMENT','注解');
DEFINE('_UE_CONNECTIONSUPDATEDSUCCESSFULL','您的連線已成功更新!');
DEFINE('_UE_MANAGECONNECTIONS','管理連線');
DEFINE('_UE_MANAGEACTIONS','管理運作');
DEFINE('_UE_CONNECTIONACTIONSSUCCESSFULL','連線運作成功!');
DEFINE('_UE_ALLOWCONNECTIONS','啟用連線');
DEFINE('_UE_ALLOWCONNECTIONS_DESC','啟用這個功能將允許您的用戶跟其他人連線. 就類似是建立好友名單系統.');
DEFINE('_UE_USEMUTUALCONNECTIONACCEPTANCE','互相同意');
DEFINE('_UE_USEMUTUALCONNECTIONACCEPTANCE_DESC','啟用這個功能將使兩照雙方同意連線之后才能建立正式連線.');
DEFINE('_UE_CONNECTOINNOTIFYTYPE','告知 &amp; 告知方法');
DEFINE('_UE_CONNECTOINNOTIFYTYPE_DESC','選擇您在連線工作流程的連線告知跟用戶接收告知的方式.');
DEFINE('_UE_AUTOADDCONNECTIONS','交互連線');
DEFINE('_UE_AUTOADDCONNECTIONS_DESC','啟用這個功能將可以直接建立雙方的連線而不是只有請求的一方.');
DEFINE('_UE_CONNECTIONCATEGORIES','連線類型');
DEFINE('_UE_CONNECTIONCATEGORIES_DESC','輸入一個類型清單讓您的用戶之后可以分類他們的連線. 每個類型之后請按 enter.');
DEFINE('_UE_CONNECTIONMADESUB','%s 已與您連線!');
DEFINE('_UE_CONNECTIONMADEMSG','%s 已跟您建立一個連線.');
DEFINE('_UE_CONNECTIONMSGPREFIX',"  %s 包含以下的個人檔案:\n\n%s");
DEFINE('_UE_CONNECTIONMESSAGE',"包含個人檔案");
DEFINE('_UE_CONNECTIONPENDSUB','您有一個從 %s 來的等待連線!');
DEFINE('_UE_CONNECTIONPENDMSG','%s 要求跟您連線并且等待您的同意. 請選擇接受或拒絕連線要求.');
DEFINE('_UE_CONNECTTO','連線至 %s');
DEFINE('_UE_CONNECTEDWITH','管理我的連線');
DEFINE('_UE_NOCONNECTEDWITH','目前沒有用戶與您連線.');
DEFINE('_UE_CONNECTIONDENIED_SUB','請求連線被拒絕');
DEFINE('_UE_CONNECTIONDENIED_MSG','您請求與 %s 連線遭到拒絕!');
DEFINE('_UE_CONNECTIONREMOVED_SUB','連線已被移除!');
DEFINE('_UE_CONNECTIONREMOVED_MSG','%s 已經移除了您的連線!');
DEFINE('_UE_CONNECTIONACCEPTED_SUB','請求連線已接受!');
DEFINE('_UE_CONNECTIONACCEPTED_MSG','您請求與 %s 連線已被接受!');
DEFINE('_UE_CONNECTIONDENYSUCCESSFULL','連線成功駁回!');
DEFINE('_UE_TOC_LINK','同意 %s 服務條款及聲明 %s');	// to link only the "Terms and Conditions", first %s will be replaced by <a.. and second %s by </a>.
// RC2 Newsletters Support
DEFINE('_UE_NEWSLETTER_HEADER','電子報');
DEFINE('_UE_NEWSLETTER','電子報訂閱');
DEFINE('_UE_NEWSLETTER_USER_EDIT_TITLE','編輯您的電子報訂閱');
DEFINE('_UE_NEWSLETTER_USER_EDIT_DESC','在檢視清單中可以檢視您可以訂閱的所有電子報. '
.'每種電子報前面的核取方塊可以讓您知道您是否訂閱了該電子報. '
.'您可以更改并按下更新來修改訂閱的電子報. ');
DEFINE('_UE_NEWSLETTER_USER_EDIT_DESC_EMAIL','如果您增加了訂閱, 您必須再次確認 '
.'來確認您可以收到電子報. 請檢查您的 E-Mail 取得更進一步的細節.');
DEFINE('_UE_NEWSLETTER_INTRODCUTION',"<div class='delimiterCell'>"._UE_NEWSLETTER_USER_EDIT_TITLE."</div>\n"
."<div class='fieldCell'>"._UE_NEWSLETTER_USER_EDIT_DESC." "._UE_NEWSLETTER_USER_EDIT_DESC_EMAIL."</div>\n");	// nothing to translate here!
DEFINE('_UE_NEWSLETTER_NAME','電子報');
DEFINE('_UE_NEWSLETTER_DESCRIPTION','描述');
DEFINE('_UE_NEWSLETTER_NAME_REG','電子報');
DEFINE('_UE_NEWSLETTER_DESCRIPTION_REG','描述');
DEFINE('_UE_NEWSLETTER_FORMAT_TITLE','選擇電子報格式');
DEFINE('_UE_NEWSLETTER_FORMAT_FIELD','收電子報:');
DEFINE('_UE_NEWSLETTER_HTML','HTML 格式電子郵件');
DEFINE('_UE_NEWSLETTER_TEXT','純文字電子郵件');
DEFINE('_UE_NEWSLETTER_DESC','設為"否" 如果您沒有安裝電子報元件. 否則選擇一個您希望整合的版本.');
DEFINE('_UE_NEWSLETTER_DESC2','目前, 只有 YaNC 1.4 可以支援用戶註冊的頁面的下方顯示提供訂閱電子報.');
DEFINE('_UE_NEWSLETTERSREGLIST','電子報選擇清單');
DEFINE('_UE_NEWSLETTERSREGLIST_DESC','清單將顯示在註冊頁面中(如果啟用電子報整合). 若是電子報整合被選取但沒有選取電子報, 所有公開的電子報將于清單中提供訂閱. 使用 CTRL (Mac: COMMAND) 來復選, 或是點選已選取的來取消.');
DEFINE('_UE_NEWSLETTERSREGLIST_DESC2','復選利用 CTRL(PC)或 Command (MAC)來 增加/移除 電子報.');
DEFINE('_UE_NEWSLETTER_SUBSCRIBE','訂閱至:');
DEFINE('_UE_NEWSLETTERNOTINSTALLED','電子報元件沒有安裝. 請連系您的網站管理員.');
DEFINE('_UE_NONEWSLETTERS','沒有訂閱電子報.');
DEFINE('_UE_PUBLIC','公開');
DEFINE('_UE_PRIVATE','私人');
DEFINE('_UE_CONNECTIONDISPLAY','顯示類型');
DEFINE('_UE_CONNECTIONDISPLAY_DESC','選擇要讓每位用戶的連線公開顯示還是私人的');
DEFINE('_UE_CONNECTIONPATH','顯示連線路徑');
DEFINE('_UE_CONNECTIONPATH_DESC','選擇是否顯示一位用戶的連線路徑和他/她造訪的個人檔案');
DEFINE('_UE_DIRECTCONNECTION','您直接連線到 ');
DEFINE('_UE_NOESTABLISHEDCONNECTION','沒有建立連線在你跟');
DEFINE('_UE_CONNECTIONPATH1','您的連線路徑到 ');
DEFINE('_UE_CONNECTIONPATH2',' 程度 ):<br />');
DEFINE('_UE_DETAILSABOUT','細節關于 ');
DEFINE('_UE_CONNECTIONINVITATIONMSG','加入資訊到您的連線來個人化您的連線邀請.');
DEFINE('_UE_MESSAGE','資訊:');
DEFINE('_UE_SENDCONNECTIONREQUEST','提交');
DEFINE('_UE_CANCELCONNECTIONREQUEST','取消');
DEFINE('_UE_CONFIRMREMOVECONNECTION','您確定您要移除這個連線?');
DEFINE('_UE_CONNECTIONREQUIREACTION','連線要求');
DEFINE('_UE_NOZOOMIMGS','這位用戶沒有圖片!');
DEFINE('_UE_ZOOMNOTINSTALLED','Zoom image 元件沒有安裝,請向連絡您的網站管理員.');
DEFINE('_UE_ZOOMGALLERY','觀看藝廊');
DEFINE('_UE_ZOOMTABTITLE','圖片藝廊');
DEFINE('_UE_FORUM_FORUMRANKING','論壇評分');
DEFINE('_UE_FORUM_TOTALPOSTS','總發表數');
DEFINE('_UE_FORUM_KARMA','因果');
DEFINE('_UE_NEWSLETTER_NOT_CONFIRMED','未確認');
DEFINE('_UE_NOTIFICATIONSAT','通知在');
DEFINE('_UE_YOUR_VERSION','您的版本');
DEFINE('_UE_LATEST_VERSION','最新的版本');
DEFINE('_UE_ACTIONSMENU','操作菜單');
DEFINE('_UE_CONNECT_ACTIONREQUIRED','以下您可以見到想跟您連線的用戶. 您可以選擇批準或是拒絕他們的請求.'
.'選擇綠色的核取欄位接受他們的申請或是紅色的拒絕申請, 然后點選更新按鈕. '
.'移動您的滑鼠游標于圖片及圖示上可看見細節的簡介以及所代表的意義.');
DEFINE('_UE_CONNECT_MANAGECONNECTIONS','以下您可以看到您所直接連線的用戶. '
.'您可以加入個人的注解并且從清單選擇多個類型的連線透過 CTRL (PC) 或是 CMD (Mac)來點選項目. '.'然后點擊更新按鈕. '
.'移動您的滑鼠游標于圖示上可看見它們代表意義的簡介以及動作, 移到圖片上則可以看到連線的細節.');

// PMS:
//Administrator Integration Tab
DEFINE('_UE_PMSTAB','快速資訊');
DEFINE('_UE_PMS_NOTINSTALLED','所選擇的 PMS 系統沒有安裝.');
// PMS integration definitions
DEFINE('_UE_PM_SENTSUCCESS','您的站內信已經傳送成功!');
DEFINE('_UE_PM_NOTSENT','您的站內信無法傳送!');
DEFINE('_UE_PMS_TYPE_UNSUPPORTED','選擇的 PMS 系統不支援這種站內信類型!');
DEFINE('_UE_PM_EMPTYMESSAGE','清空資訊.');
DEFINE('_UE_SESSIONTIMEOUT','期間逾時.');
DEFINE('_UE_TRYAGAIN','請重試一次.');
DEFINE('_UE_PM_SENDMESSAGE','寄送資訊');
DEFINE('_UE_PM_PROFILEMSG','從您的個人檔案檢視資訊');
DEFINE('_UE_PM_MESSAGES_HAVE'	, '您有');
DEFINE('_UE_PM_NEW_MESSAGE'		, '新的站內信');
DEFINE('_UE_PM_NEW_MESSAGES'	, '新的站內信');
DEFINE('_UE_PM_NO_MESSAGES'		, '您沒有新的站內信');
// PMS Menus:
DEFINE('_UE_PM','站內信');
DEFINE('_UE_PM_USER','傳送站內信');
DEFINE('_UE_MENU_PM_USER_DESC','傳送站內信給這位用戶');
DEFINE('_UE_PM_INBOX','顯示私人收件箱');
DEFINE('_UE_MENU_PM_INBOX_DESC','顯示收到的站內信');
DEFINE('_UE_PM_OUTBOX','顯示私人發信箱');
DEFINE('_UE_MENU_PM_OUTBOX_DESC','顯示 寄出/等待寄出 的站內信');
DEFINE('_UE_PM_TRASHBOX','顯示私人垃圾箱');
DEFINE('_UE_MENU_PM_TRASHBOX_DESC','顯示刪除的站內信');
DEFINE('_UE_PM_OPTIONS','編輯 PMS 選項');
DEFINE('_UE_MENU_PM_OPTIONS_DESC','編輯站內信系統選項');

// Menus
DEFINE('_UE_MENU', '菜單');
DEFINE('_UE_USER_STATUS', '用戶狀態');
DEFINE('_UE_MENU_CB', '社區');
DEFINE('_UE_MENU_ABOUT_CB', '關于 Community Builder...');
DEFINE('_UE_SITE_POWEREDBY', '這個網站的社區功能是由 Joomla Community Builder 所制作');
DEFINE('_UE_MENU_EDIT', '編輯');
DEFINE('_UE_MENU_VIEW', '檢視');
DEFINE('_UE_MENU_MESSAGES', '資訊');
DEFINE('_UE_MENU_CONNECTIONS', '連線');
//DEFINE('_UE_MENU_UPDATEPROFILE', '更新您的個人檔案');
DEFINE('_UE_MENU_UPDATEPROFILE_DESC', '更改您的個人檔案設定');
//DEFINE('_UE_MENU_UPDATEAVATAR', '改變您的照片');
DEFINE('_UE_MENU_UPDATEAVATAR_DESC', '選擇您的個人檔案圖片');
//DEFINE('_UE_MENU_DELETE_AVATAR', '移除圖片');
DEFINE('_UE_MENU_DELETE_AVATAR_DESC', '從您的個人檔案中移除圖片');
DEFINE('_UE_MENU_VIEWMYPROFILE', '檢視您的個人檔案');
DEFINE('_UE_MENU_VIEWMYPROFILE_DESC', '檢視您個人的資料');

DEFINE('_UE_MENU_SENDUSEREMAIL','寄送 e-mail 給用戶');
DEFINE('_UE_MENU_SENDUSEREMAIL_DESC','寄送 e-mail 給這位用戶');
DEFINE('_UE_MENU_USEREMAIL_DESC','此用戶的 E-Mail 地址');
DEFINE('_UE_ADDCONNECTION_DESC','增加連線到這位用戶');
DEFINE('_UE_ADDCONNECTIONREQUEST','連線請求');
DEFINE('_UE_ADDCONNECTIONREQUEST_DESC','請求與這名用戶連線');
DEFINE('_UE_REMOVECONNECTION_DESC','移除與這名用戶連線');
DEFINE('_UE_REVOKECONNECTIONREQUEST','撤銷連線請求');
DEFINE('_UE_REVOKECONNECTIONREQUEST_DESC','取消與這名用戶的連線要求');
DEFINE('_UE_MENU_MANAGEMYCONNECTIONS','管理您的連線');
DEFINE('_UE_MENU_MANAGEMYCONNECTIONS_DESC','管理您現有的連線及等待連線動作');

DEFINE('_UE_MENU_MODERATE', '群組管理');
//DEFINE('_UE_MENU_REQUESTUNBANPROFILE','提出取消停用請求');
DEFINE('_UE_MENU_REQUESTUNBANPROFILE_DESC', '提交請求給網站版主取消停用個人檔案');
//DEFINE('_UE_MENU_BANPROFILE','停用個人檔案');
DEFINE('_UE_MENU_BANPROFILE_DESC', '網站版主: 停用這個個人檔案, 讓其他用戶無法看到');
//DEFINE('_UE_MENU_UNBANPROFILE','取消停用個人會員');
DEFINE('_UE_MENU_UNBANPROFILE_DESC', '網站版主: 取消停用這個個人檔案, 讓其他用戶可以看到');
//DEFINE('_UE_MENU_REPORTUSER','舉報會員');
DEFINE('_UE_MENU_REPORTUSER_DESC', '舉報此名用戶讓網站版主來作出適當的處里');
//DEFINE('_UE_MENU_VIEWUSERREPORTS','檢視用戶舉報');
DEFINE('_UE_MENU_VIEWUSERREPORTS_DESC','網站版主: 檢視關于此名用戶的舉報');
DEFINE('_UE_UNBAN_MODERATE_DESC','點擊遭停用的用戶名稱來檢視此名用戶個人檔案. '
.'然后從用戶個人檔案菜單選擇 管理/取消停用 如果您要取消停用此名用戶.');
DEFINE('_UE_MENU_APPROVE_IMAGE_DESC', '網站版主: 批準此名用戶所提交的個人檔案圖片,讓它可以給所有用戶看見');
DEFINE('_UE_MENU_REJECT_IMAGE_DESC', '網站版主: 駁回此名用戶的個人檔案圖片');
DEFINE('_UE_HITS_DESC','此用戶個人檔案的檢視次數');
DEFINE('_UE_ONLINESTATUS_DESC','此用戶目前的在線狀態');
DEFINE('_UE_MEMBERSINCE_DESC','這名用戶註冊于');
DEFINE('_UE_LASTONLINE_DESC','這名用戶最近在線時間在');
DEFINE('_UE_LASTUPDATEDON_DESC','這明用戶最近更新了他的個人檔案在');

DEFINE('_UE_LENGTH_ERROR','已經到達這個欄位的最大長度');
DEFINE('_UE_CHARACTERS','字元');
DEFINE('_UE_NEVER','絕不');
DEFINE('_UE_NOFORUMPOSTSFOUND','沒有找到相符的論壇文章.');

DEFINE('_UE_PORTRAIT','肖像');
DEFINE('_UE_CONNECTIONPATHS','連線路徑');

DEFINE('_UE_PROFILE_PAGE_TITLE','用戶個人檔案頁標題');
DEFINE('_UE_PROFILE_TITLE_TEXT','%s 的個人檔案頁');

DEFINE('_UE_SEARCH_INPUT','搜尋&hellip;');	// &hellip; = "..."
DEFINE('_UE_POS_CB_MAIN','主要區域 (下方 置左/置中/置右)');
DEFINE('_UE_POS_CB_HEAD','標頭 (上方 置左/置中/置右)');
DEFINE('_UE_POS_CB_MIDDLE','中間區域');
DEFINE('_UE_POS_CB_LEFT','左邊 (中間區域的)');
DEFINE('_UE_POS_CB_RIGHT','右邊 (中間區域的)');
DEFINE('_UE_POS_CB_BOTTOM','下方區域 (主要區域下方)');

DEFINE('_UE_DISPLAY_TAB','標簽的區塊');
DEFINE('_UE_DISPLAY_DIV','以標題標示');
DEFINE('_UE_DISPLAY_HTML','原始顯示沒有標題');
DEFINE('_UE_DISPLAY_OVERLIB','跟滑鼠重疊移動');
DEFINE('_UE_DISPLAY_OVERLIBFIX','固定重疊滑鼠移出關閉');
DEFINE('_UE_DISPLAY_OVERLIBSTICKY','黏附重疊按鈕');
DEFINE('_UE_CLOSE_OVERLIB','關閉');

//SB Integration Support
DEFINE('_UE_SB_TABTITLE','論壇設定');
DEFINE('_UE_SB_TABDESC','這是您的論壇設定');
DEFINE('_UE_SB_VIEWTYPE_TITLE','偏好的檢視類型');
DEFINE('_UE_SB_VIEWTYPE_FLAT','平鋪');
DEFINE('_UE_SB_VIEWTYPE_THREADED','樹形');
DEFINE('_UE_SB_ORDERING_TITLE','偏好的資訊排序');
DEFINE('_UE_SB_ORDERING_OLDEST','最舊的排最前');
DEFINE('_UE_SB_ORDERING_LATEST','最新的排最前');
DEFINE('_UE_SB_SIGNATURE','簽名');
//added for SB 1.5 during 1.0 RC 1
DEFINE('_UE_SB_POSTSPERPAGE','文章每一頁');
DEFINE('_UE_SB_USERTIMEOFFSET','本地時間與伺服器時間之間的時差');
DEFINE('_UE_SB_CONFIRMUNSUBSCRIBEALL','您確定您要取消訂閱您所有論壇的訂閱 ?');
DEFINE('_UE_FORUMDATE','日期');
DEFINE('_UE_FORUMCATEGORY','分類');
DEFINE('_UE_FORUMSUBJECT','主題');
DEFINE('_UE_FORUMHITS','點閱');
DEFINE('_UE_FORUM_POSTS','論壇文章');
DEFINE('_UE_FORUM_LASTPOSTS','最新 %s 論壇文章');
DEFINE('_UE_FORUM_FOUNDPOSTS','找到 %s 論壇文章');
DEFINE('_UE_FORUM_STATS','論壇統計');
if (!defined('_RANK_MODERATOR')) DEFINE('_RANK_MODERATOR','Moderator');
if (!defined('_RANK_ADMINISTRATOR')) DEFINE('_RANK_ADMINISTRATOR','Administrator');
DEFINE('_UE_SBNOTINSTALLED','Simpleboard 論壇元件沒有安裝. 請連系您的網站管理員.');
DEFINE('_UE_NOFORUMPOSTS','這個會員沒有發表過文章.');
DEFINE("_UE_USERPARAMS","用戶選項");
//Mamblog search:
DEFINE('_UE_BLOG_LASTENTRIES','最新的 %d 個Blog項目');
DEFINE('_UE_BLOG_FOUNDENTRIES','找到 %d 個Blog項目');
DEFINE('_UE_BLOG_ENTRIES','Blog項目');

// 1.0 stable:
DEFINE('_UE_NO_USERS_IN_LIST','此清單沒有用戶');
DEFINE('_UE_LIST_DOES_NOT_EXIST','此清單不存在');
DEFINE('_UE_VISIBLE_ONLY_MODERATOR','此項目只限版主觀看');
DEFINE('_UE_AUTOMATIC','自動地');
DEFINE('_UE_MANUAL','手動');
DEFINE('_UE_NOVERSIONCHECK','組態的版本檢查');
DEFINE('_UE_NOVERSIONCHECK_DESC','選取當您想要每次進入 Community Builder 一般組態時自動檢查版本 (強烈建議, 這樣您可以立即看到關鍵安全性釋出版本的資訊) 如果手動, 當您點擊連結才檢查 (不建議). 您已經安裝的 Community Builder 不會在版本檢查時透露任何資料 (除了目前的安裝版本以及標準的 http 參數). 也沒有自動更新的服務.');
// 1.0 stable cblogin module:
DEFINE('_UE_SHOW_POFILE_OF','顯示個人檔案 ');

//Not yet used within application but are needed to translate default images for profile.
DEFINE('_UE_IMG_NOIMG','沒有圖片');
DEFINE('_UE_IMG_PENDIMG','等待批準');

// CB 1.0.2 optional string:
DEFINE('_UE_MAXEMAILSLIMIT','你寄送了%d封email僅僅在%d小時內.請休息一段時間后再試.');
DEFINE('_UE_INPUT_VALUE_NOT_ALLOWED','此輸入值非法.');

//Needed for Joomla 1.5 and Mambo 4.6 language independance: Translators: please take strings from joomla 1.0.11's language file
/** registration.php */
if (!defined('_ERROR_PASS'))		DEFINE('_ERROR_PASS','很抱歉,此用戶不存在');
if (!defined('_NEWPASS_SENT'))		DEFINE('_NEWPASS_SENT','密碼已重置并寄送至郵箱t!');
if (!defined('_REGWARN_NAME'))		DEFINE('_REGWARN_NAME','請輸入你的姓名.');
if (!defined('_REGWARN_UNAME'))		DEFINE('_REGWARN_UNAME','請輸入用戶名.');
if (!defined('_REGWARN_MAIL'))		DEFINE('_REGWARN_MAIL','請輸入一個有效的Email地址.');
if (!defined('_REGWARN_VPASS2'))	DEFINE('_REGWARN_VPASS2','兩次密碼輸入不一致,請重試.');
if (!defined('_REGWARN_INUSE'))		DEFINE('_REGWARN_INUSE','此用戶名已存在，請嘗試其它的用戶名.');
if (!defined('_REGWARN_EMAIL_INUSE')) DEFINE('_REGWARN_EMAIL_INUSE', '此e-mail已被其它用戶用于註冊.如果你忘記了密碼，請點擊“忘記了密碼？" 重置你的密碼.');
if (!defined('_VALID_AZ09'))		DEFINE('_VALID_AZ09',"P請輸入一個有效的%s.不包含空格,字符數不少于%d,僅包含 0-9,a-z,A-Z");
/** classes/html/registration.php */
if (!defined('_PROMPT_PASSWORD'))	DEFINE('_PROMPT_PASSWORD','忘記了密碼');
if (!defined('_NEW_PASS_DESC'))		DEFINE('_NEW_PASS_DESC','請輸入你的用戶名和註冊郵箱，然后點擊密碼重置按鈕.<br />'
.'你將會很快收到一封密碼重置email.請使用新密碼登入本站.');
if (!defined('_PROMPT_UNAME'))		DEFINE('_PROMPT_UNAME','用戶名:');
if (!defined('_PROMPT_EMAIL'))		DEFINE('_PROMPT_EMAIL','E-mail地址 :');
if (!defined('_BUTTON_SEND_PASS'))	DEFINE('_BUTTON_SEND_PASS','重置密碼');
if (!defined('_REGISTER_TITLE'))	DEFINE('_REGISTER_TITLE','註冊');
if (!defined('_REGISTER_NAME'))		DEFINE('_REGISTER_NAME','姓名:');
if (!defined('_REGISTER_UNAME'))	DEFINE('_REGISTER_UNAME','用戶名:');
if (!defined('_REGISTER_EMAIL'))	DEFINE('_REGISTER_EMAIL','E-mail:');
if (!defined('_REGISTER_PASS'))		DEFINE('_REGISTER_PASS','密碼:');
if (!defined('_REGISTER_VPASS'))	DEFINE('_REGISTER_VPASS','再次確認密碼:');
if (!defined('_BUTTON_SEND_REG'))	DEFINE('_BUTTON_SEND_REG','註冊');
if (!defined('_SENDING_PASSWORD'))	DEFINE('_SENDING_PASSWORD','你的密碼已被寄送至上述郵箱.<br />在您收到新密碼之后，'
.' 就可以通過新密碼登錄網站并修改密碼。');
if (!defined('_LOGIN_SUCCESS'))		DEFINE('_LOGIN_SUCCESS','登入成功');
if (!defined('_LOGOUT_SUCCESS'))	DEFINE('_LOGOUT_SUCCESS','登出成功');
if (!defined('_LOGIN_BLOCKED'))		DEFINE('_LOGIN_BLOCKED','您的帳戶已被鎖定.請聯系管理員.');
if (!defined('_CMN_YES'))			DEFINE('_CMN_YES','是');
if (!defined('_CMN_NO'))			DEFINE('_CMN_NO','否');
if (!defined('_CMN_SHOW'))			DEFINE('_CMN_SHOW','顯示');
if (!defined('_CMN_HIDE'))			DEFINE('_CMN_HIDE','隱藏');
if (!defined('_LOGIN_INCOMPLETE'))	DEFINE('_LOGIN_INCOMPLETE','用戶名及密碼欄不能為空.');
if (!defined('_LOGIN_INCORRECT'))	DEFINE('_LOGIN_INCORRECT','用戶名或密碼錯誤，請再試一次.');
if (!defined('_USER_DETAILS_SAVE'))	DEFINE('_USER_DETAILS_SAVE','設定已儲存.');

// 1.1:
DEFINE('_UE_MENU_STATUS', '狀態');
DEFINE('_UE_YOURCONNECTIONS','你的連線');
DEFINE('_UE_USERSNCONNECTIONS','%s\'的連線');
DEFINE('_UE_SEEALLNCONNECTIONS','察看所有關于%s的連線s');
DEFINE('_UE_SEEALLOFUSERSNCONNECTIONS','察看%s的所有連線');
DEFINE('_UE_YOU_ARE_ALREADY_REGISTERED','You are already registered with this username and password.');
DEFINE('_UE_SESSION_EXPIRED','線程超時或者Cookies被停用.');
DEFINE('_UE_PLEASE_REFRESH','請在填寫前刷新或者重新載入此頁面.');
DEFINE('_UE_REGISTERFORPROFILEVIEW','察看此頁面需要請登入或註冊成本站會員.');
DEFINE('_UE_INFORMATION_FOR_FIELD',' %s的個人檔案 : %s');
DEFINE('_UE_ALLOWMODERATORSUSEREDIT_DESC','允許版主修改用戶資料，增加、修改或刪除用戶頭像.版主無法修改同級或者更高級別管理人員資料.');
DEFINE('_UE_ALLOWMODERATORSUSEREDIT','允許版主修改用戶資料');
DEFINE('_UE_USERPROFILEBLOCKED','此用戶資料目前不可用.');
DEFINE('_UE_EDIT_OTHER_USER_TITLE','編輯 %s的詳細資料');
DEFINE('_UE_MOD_MENU_UPDATEPROFILE', '更新此用戶個人檔案');
DEFINE('_UE_MOD_MENU_UPDATEPROFILE_DESC', '儲存此用戶資料修改');
DEFINE('_UE_MOD_MENU_UPDATEAVATAR', '上傳用戶圖片');
DEFINE('_UE_MOD_MENU_UPDATEAVATAR_DESC', '從用戶資料選擇圖片');
DEFINE('_UE_MOD_MENU_DELETE_AVATAR', '刪除用戶圖片');
DEFINE('_UE_MOD_MENU_DELETE_AVATAR_DESC', '將此用戶資料中的圖片刪除e');
DEFINE('_UE_MOD_MENU_VIEWOLDUSERREPORTS','察看此用戶的處理歷史紀錄');
DEFINE('_UE_MOD_MENU_VIEWOLDUSERREPORTS_DESC','允許站點版主看此用戶的處理歷史紀錄');
DEFINE('_UE_REPORTSTATUS','報告狀態');
DEFINE('_UE_REPORTSTATUS_OPEN','開啟');
DEFINE('_UE_REPORTSTATUS_PROCESSED','處理');
DEFINE('_UE_UNBANUSER','用戶資料封禁解除');
DEFINE('_UE_UNBANNEDON','封禁日期');
DEFINE('_UE_UNBANNEDBY','封禁操作人');
DEFINE('_UE_MENU_BANPROFILE_HISTORY','察看封禁歷史紀錄');
DEFINE('_UE_MENU_BANPROFILE_HISTORY_DESC', '允許版主察看此用戶資料被封禁歷史紀錄');
DEFINE('_UE_BANSTATUS','封禁狀態');
DEFINE('_UE_BANSTATUS_BANNED','被封禁');
DEFINE('_UE_BANSTATUS_UNBAN_REQUEST_PENDING','等待處理解除封禁請求');
DEFINE('_UE_BANSTATUS_PROCESSED','已處理');
DEFINE('_UE_UNNAMED_USER','未命名用戶');
DEFINE('_UE_REG_CB_ALLOW','開啟用戶註冊');
DEFINE('_UE_REG_CB_ALLOW_DESC','采用 全局設定 或者 CB設定 皆可。<br />推薦設定: 僅通過 CB設定 : 在此設定里設定 `是` 并在全局設定里設定為 `否`.');
DEFINE('_UE_REG_PROFILE_2COLS','2欄式版面 - 寬度:');
DEFINE('_UE_REG_PROFILE_2COLS_RIGHT_REST','右邊距!');
DEFINE('_UE_REG_PROFILE_2COLS_DESC','2欄式版面 %邊距 ');
DEFINE('_UE_REG_PROFILE_3COLS','3 欄式版 - 寬度:');
DEFINE('_UE_REG_PROFILE_3COLS_RIGHT_REST','右邊距!');
DEFINE('_UE_REG_PROFILE_3COLS_DESC','3欄式版面. 中間列寬度!');
DEFINE('_UE_REG_FILTER_ALLOWED_TAGS','下列代碼標簽將不被過濾:');
DEFINE('_UE_REG_FILTER_ALLOWED_TAGS_DESC','此列表內的代碼標簽將不被過濾,例如: `applet body bgsound embed`.<br />注意:此功能包含一定風險,用戶可能會插入惡意代碼.默認代碼過濾器會防止此情況發生。下述代碼標簽被默認設定過濾，將其加入此列表后過濾將被解除:');
DEFINE('_UE_REG_FURTHER_SETTINGS','高級設定:');
DEFINE('_UE_REG_FURTHER_SETTINGS_MORE','察看 plugins and tabs 參數.');
DEFINE('_UE_REG_FURTHER_SETTINGS_DESC','更多參數設定參見 菜單: 組件 / Community Builder / Plugin Management and / Tab Management. 每個plugin和tab都可以單獨設定參數，設定前請先啟用該Plugins和Tabs .');
// 1.1: backend global config:
DEFINE('_UE_REG_CONFIGURATION_MANAGER','設定');
DEFINE('_UE_REG_ALLOWREG_SAME_AS_GLOBAL','按照全局設定`允許註冊` ');
DEFINE('_UE_REG_ALLOWREG_YES','獨立于全局設定');
DEFINE('_UE_NONE','無');
DEFINE('_UE_REG_NAMEFORMAT_NAME_ONLY','僅姓名');
DEFINE('_UE_REG_NAMEFORMAT_NAME_USERNAME','姓名(用戶名)');
DEFINE('_UE_REG_NAMEFORMAT_USERNAME_ONLY','僅用戶名');
DEFINE('_UE_REG_NAMEFORMAT_USERNAME_NAME','用戶名 (姓名)');
DEFINE('_UE_REG_NAMEFORMAT_SINGLE_FIELD','Single Name Field');
DEFINE('_UE_REG_NAMEFORMAT_TWO_FIELDS','First and Last Name Field');
DEFINE('_UE_REG_NAMEFORMAT_THREE_FIELDS','First, Middle, and Last Name Field');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_ONLY','僅顯示Email');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_W_MAILTO','顯示Email及 w/ MailTo超連接');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_W_FORM','顯示寄送Email表單連接');
DEFINE('_UE_REG_EMAILDISPLAY_EMAIL_NO','不顯示Email');
DEFINE('_UE_GROUPS_EVERYBODY','所有人');
DEFINE('_UE_GROUPS_ALL_REG_USERS','所有註冊用戶');
DEFINE('_UE_WARNING','警告');
DEFINE('_UE_YOUR_CONFIG_FILE','設定檔案');
DEFINE('_UE_IS_NOT_WRITABLE','無法寫入');
DEFINE('_UE_NEED_TO_CHMOD_CONFIG','請修改檔案權限為766，然后儲存設定');
DEFINE('_UE_FILE_UNWRITABLE','');
DEFINE('_UE_LEFT','左對齊');
DEFINE('_UE_RIGHT','右對齊');
DEFINE('_UE_CENTER','舉重');
DEFINE('_UE_UP','上對齊');
DEFINE('_UE_DOWN','下對齊');
DEFINE('_UE_TOP','頂對齊');
DEFINE('_UE_BOTTOM','底對齊');
DEFINE('_UE_MODERATORS_AND_ABOVE','CB 版主及其以上');
DEFINE('_UE_SUPERADMINS_ONLY','僅限超級管理員');
DEFINE('_UE_ADMINS_AND_SUPERADMINS_ONLY','僅限管理員和超級管理員');
DEFINE('_UE_NO_PARAMS','此條目無參數設定');
DEFINE('_UE_CALENDAR_TYPE','日歷顯示樣式');
DEFINE('_UE_CALENDAR_TYPE_DESC','選擇日歷的顯示方式.');
DEFINE('_UE_CALENDAR_TYPE_DROPDOWN_POPUP','下拉(+彈出) 日歷');
DEFINE('_UE_CALENDAR_TYPE_POPUP','彈出日歷窗口 (old)');
DEFINE('_UE_REG_USERNAMECHECKER','Ajax 用戶名檢測');
DEFINE('_UE_REG_USERNAMECHECKER_DESC','在註冊過程中檢查用戶名是否已被使用.注：此功能可能被用于猜測用戶名進而推測用戶密碼，請謹慎使用.此功能尚屬測試階段，尚未為大型站點優化。請在使用前進行測試 !');
// 1.1: frontend:
DEFINE('_UE_BUTTON_LOGIN','登入');
DEFINE('_UE_BUTTON_LOGOUT','登出');
DEFINE('_UE_DO_LOGIN','請先登入.');
DEFINE('_UE_DO_LOGOUT','請先登出.');
define('_UE_CHECK_USERNAME_AVAILABILITY',"檢查次用戶名是否可用");
define('_UE_USERNAME_ALREADY_EXISTS',"此用戶名 '%s' 已被註冊:請選擇一個其它的用戶名.");
define('_UE_USERNAME_DOESNT_EXISTS',"此用戶名'%s'可用:請繼續註冊步驟.");
define('_UE_CHECKING',"檢查中...");
define('_UE_SORRY_CANT_CHECK',"很抱歉,暫時無法檢查.");
DEFINE('_UE_PLEAE_CHECK_PROFILE','請察看你的個人檔案');
DEFINE('_UE_BANNED_CHANGE_PROFILE','你的個人檔案暫時被封禁.僅限你個人和管理員和以察看.<br />請根據管理員的要求修改你的個人檔案,然后向管理員申請解除封禁.');
DEFINE('_UE_WARNING_EDIT_OTHER_USER_PROFILE','警告:這不是你的個人檔案.你正在使用管理權限修改%s的個人檔案.');
DEFINE('_UE_BACK_TO_YOUR_PROFILE','返回個人檔案頁面');
// CB captcha plugin strings in core cb 1.1:
DEFINE('_UE_CAPTCHA_Label','驗證碼');
DEFINE('_UE_CAPTCHA_Enter_Label','請輸入驗證碼:');
DEFINE('_UE_CAPTCHA_Desc','輸入圖片上所顯示的驗證碼');
DEFINE('_UE_CAPTCHA_NOT_VALID','驗證碼輸入有誤');
DEFINE('_UE_CAPTCHA_ALT_IMAGE','顯示驗證碼的圖片');
DEFINE('_UE_CAPTCHA_AUDIO','點擊這里收聽驗證碼朗讀');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_TITLE','再次收聽CB 驗證碼');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_DESCRIPTION','重新聽取驗證碼朗讀');
DEFINE('_UE_CAPTCHA_AUDIO_DOWNLOAD','點擊使用播放器播放或者下載音頻檔案');
DEFINE('_UE_CAPTCHA_AUDIO_CLICK2DOWNLOAD','(右鍵單擊或者按住control鍵后單擊)');
DEFINE('_UE_CAPTCHA_AUDIO_POPUP_CLOSEWINDOW','關閉此窗口');

// 1.2 Frontend:
DEFINE('_UE_ERROR_USER_NOT_SYNCHRONIZED','此用戶不存在或未同步至CB資料庫內');
DEFINE('_LOGIN_TITLE','登錄');
DEFINE('_LOGIN_REGISTER_TITLE','歡迎您的訪問, 請首先登錄或者註冊:');
DEFINE('_UE_UPLOAD_DIMENSIONS_AVATAR','如果您上傳的圖片超過尺寸限制，將自動被調整至寬度最大 %s 像素 x 高度最大 %s 像素, 同時檔案大小需小于 %s KB.');
DEFINE('_UE_LOGIN_BLOCKED','此用戶被禁止登錄.');
DEFINE('_UE_REMEMBER_ME', '記住我');
DEFINE('_UE_PASSWORD_REMINDER','密碼提示');
DEFINE('_UE_USERNAME_PASSWORD_REMINDER','用戶名、密碼提示');
DEFINE('_UE_REMINDER_NEEDED_FOR','密碼提示');
DEFINE('_UE_LOST__USERNAME','忘記用戶名');
DEFINE('_UE_LOST__PASSWORD','忘記密碼');
DEFINE('_UE_LOST_PASSWORD','忘記了密碼?');
DEFINE('_UE_USERNAMEREMINDER_SUB','為 %s 設定用戶名提示');
DEFINE('_UE_USERNAMEREMINDER_MSG','歡迎回來,\n'
.'用戶%s的用戶名提示功能設定成功.\n\n'
.'您的用戶名是: %s\n\n'
.'點擊下面的鏈接登錄你的帳戶:\n'
.'%s\n\n'
.'.\n');
DEFINE('_UE_NEWPASS_SUB','用戶 %s 的新密碼');
DEFINE('_UE_NEWPASS_MSG','用戶 %s 使用了 email 找回密碼的功能.\n'
.'應來自 %s 的用戶找回密碼的請求，本網站特寄送此郵件.\n\n'
.'您的新密碼是: %s\n\n'
.'如果您沒有申請找回密碼,請不要擔心.'
.' 包含有新密碼的郵件僅僅寄送給您，其他人不會收到此封郵件.請盡快使用新密碼登錄我們的網站，'
.' 并修改密碼為你常用的字段.');
DEFINE('_UE_ALREADY_LOGGED_IN','你已經登錄');
DEFINE('_UE_EMAIL_COULD_NOT_CHECK','請檢查此郵件地址: 請重復檢查:仔細確認.');
DEFINE('_UE_EMAIL_COULD_NOT_CHECK_NEEDED','請檢查此郵件地址: 請重復檢查.');
DEFINE('_UE_EMAIL_INCORRECT_CHECK','此郵件地址未收到確認email:請檢查.');
DEFINE('_UE_EMAIL_INCORRECT_CHECK_NEEDED','此郵件地址未收到確認email:請確認.');
DEFINE('_UE_EMAIL_VERIFIED','此郵件地址有誤.');
DEFINE('_UE_EMAIL_NOVALID','此郵件地址無效.');
DEFINE('_UE_EMAIL_ALREADY_REGISTERED','此郵件地址已被使用.');
DEFINE('_UE_FIELDONPROFILE_SHORT','在個人檔案內可見');
DEFINE('_UE_FIELDNOPROFILE_SHORT','在個人檔案內<strong>不</strong>可見');
DEFINE('_UE_FIELDREQUIRED_SHORT','必填字段');
DEFINE('_UE_FIELDDESCRIPTION_SHORT','資訊:將鼠標指向圖標');
DEFINE('_UE_AVATAR_UPLOAD_DISCLAIMER','點擊 "上傳"按鈕前, 請確認你有權限使用該圖片，任何侵犯他人權利的圖片會直接導致賬戶被封禁.');
DEFINE('_UE_AVATAR_UPLOAD_DISCLAIMER_TERMS','點擊 "上傳"按鈕前, 請確認你有權限使用該圖片,并確認該圖片未違反任何%s，任何不良圖片會直接導致賬戶被封禁 .');
DEFINE('_UE_AVATAR_TOC_LINK','規范及要求');
DEFINE('_UE_USER_EMAIL_CONFIRMED','Email地址已確認');
DEFINE('_UE_LOST_USERNAME_PASSWORD','忘記了用戶名/密碼?');
DEFINE('_UE_LOST_USERNAME_OR_PASSWORD','忘記了用戶名/密碼 ?');
DEFINE('_UE_LOST_USERNAME_DESC','如果你 <strong>忘記了用戶名</strong>, 請輸入你註冊時使用的 E-mail 地址,用戶名處留空，然后點擊寄送用戶名按鈕,你的用戶名將會被寄送至註冊郵箱.');
DEFINE('_UE_LOST_USERNAME_ONLY_DESC','如果您 <strong>忘記了用戶名</strong>, 請輸入您的 E-mail 地址, 然后點擊“寄送用戶名”按鈕，系統就會將您的用戶名寄送至您的信箱。');
DEFINE('_UE_LOST_PASSWORD_DESC','如果你 <strong>忘記了密碼</strong>但是你知道用戶名,請輸入你的用戶名和註冊時使用的E-mail地址, 點擊寄送密碼按鈕,你將很快收到一封包含新密碼的郵件.請盡快使用該密碼登錄本站并及時修改為常用密碼.');
DEFINE('_UE_LOST_USERNAME_PASSWORD_DESC','如果 <strong>你同時忘記了用戶名和密碼</strong>, 請首先找回用戶名，然后找回密碼. 找回用戶名時,請輸入你註冊時使用的 E-mail 地址,用戶名處留空，然后點擊寄送用戶名按鈕，你的用戶名將會被寄送至註冊郵箱.然后輸入找回的用戶名和註冊時使用的E-mail地址, 點擊寄送密碼按鈕,你將很快收到一封包含新密碼的郵件.');
DEFINE('_UE_BUTTON_SEND','寄送');
DEFINE('_UE_BUTTON_SEND_USERNAME','寄送用戶名');
DEFINE('_UE_BUTTON_SEND_PASS','寄送密碼');
DEFINE('_UE_BUTTON_SEND_USERNAME_PASS','寄送用戶名/密碼');
define('_UE_USERNAME_EXISTS_ON_SITE',"此用戶名'%s' 已被使用.");
define('_UE_USERNAME_DOES_NOT_EXISTS_ON_SITE',"用戶名 '%s' 可以使用.");
define('_UE_USERNAME_FREE_OK_TO_PROCEED',"用戶名 '%s' 暫時未被使用: 你可以繼續註冊.");
define('_UE_THIS_IS_YOUR_USERNAME',"這是你在本站使用的用戶名.");
define('_UE_THIS_IS_USERS_USERNAME',"這是此用戶在本站使用的用戶名.");
define('_UE_EMAIL_EXISTS_ON_SITE',"此Email '%s' 已被使用.");
define('_UE_EMAIL_DOES_NOT_EXISTS_ON_SITE',"本站無使用'%s'的用戶.");
define('_UE_SEARCH_ERROR','搜尋出錯');
define('_UE_EMAIL_SENDING_ERROR','寄送Email失敗');
DEFINE('_UE_USERNAME_REMINDER_SENT','用戶名找回程序已向寄送一份郵件至%s. 請檢查你的郵箱 (收件箱沒有的話，請記得檢查垃圾郵件資料夾！)!');
DEFINE('_UE_NEWPASS_SENT','新的用戶密碼已生成并寄送至%s.請檢查你的郵箱 (收件箱沒有的話，請記得檢查垃圾郵件資料夾！)！');
DEFINE('_UE_VALID_UNAME','請輸入有效的用戶名.  請勿使用空格,至少3個字符并且僅限0-9,a-z,A-Z');
DEFINE('_UE_VALID_UNAME_CHARS','請輸入有效的 %s.  請勿使用空格,至少%s個字符并且僅限0-9,a-z,A-Z');
DEFINE('_UE_VALID_PASS','請輸入有效的密碼.  請勿使用空格,至少6個字符并且僅限字母、數字以及-和_，字母區分大小寫');
DEFINE('_UE_VALID_PASS_CHARS','請輸入有效的 %s.請勿使用空格,至少%s個字符并且僅限字母、數字以及-和_，字母區分大小寫');
DEFINE('_UE_VALID_MIN_LENGTH','請輸入有效的 %s: 至少%s個字符: 你輸入了 %s 個字符.');
DEFINE('_UE_VALID_MAX_LENGTH','請輸入有效的 %s: 最多%s個字符: 你輸入了 %s 個字符.');
DEFINE('_UE_REGWARN_NAME','請輸入你的真實全名.');
DEFINE('_UE_REGWARN_FNAME','請輸入你的真實姓氏.');
DEFINE('_UE_REGWARN_MNAME','請輸入你的真實名字.');
DEFINE('_UE_REGWARN_LNAME','請輸入你的真實名字.');
DEFINE('_UE_REGWARN_MAIL','請輸入一個真實有效的Email地址.本站將會寄送一封確認郵件用以激活你的帳戶.');
DEFINE('_UE_REGWARN_VPASS2','兩次輸入的密碼不一致，請檢查后重試.');
DEFINE('_UE_VERIFY_SOMETHING','檢查 %s');
DEFINE('_UE_NO_PREFERENCE','無偏好');
DEFINE('_UE_NO_INDICATION','無指向');
DEFINE('_UE_SEARCH_CRITERIA','簡單搜尋');
DEFINE('_UE_SEARCH_RESULTS','在結果中搜尋');
DEFINE ('_UE_SEARCH_USERS','搜尋用戶');
DEFINE ('_UE_FIND_USERS','查詢用戶');
DEFINE ('_UE_SEARCH_FROM','在中間');
DEFINE ('_UE_SEARCH_TO','和');
DEFINE ('_UE_MATCH_IS','是');
DEFINE ('_UE_MATCH_IS_NOT','不是');
DEFINE ('_UE_MATCH_IS_EXACTLY','是確切的');
DEFINE ('_UE_MATCH_IS_EXACTLY_NOT','是不確切的');
DEFINE ('_UE_MATCH_ARE_EXACTLY','是準確的');
DEFINE ('_UE_MATCH_ARE_EXACTLY_NOT','是不準確的');
DEFINE ('_UE_MATCH_IS_ONE_OF','是一名');
DEFINE ('_UE_MATCH_IS_NOT_ONE_OF','不是一名');
DEFINE ('_UE_MATCH_PHRASE','包含關鍵詞');
DEFINE ('_UE_MATCH_PHRASE_NOT','不包含關鍵詞');
DEFINE ('_UE_MATCH_ALL','包含所有');
DEFINE ('_UE_MATCH_ALL_NOT','不包含任何');
DEFINE ('_UE_MATCH_ANY','任何地方包含');
DEFINE ('_UE_MATCH_ANY_NOT','不會包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ALL_OF','包含所有的');
DEFINE ('_UE_MATCH_INCLUDE_ALL_OF_NOT','不包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ANY_OF','包含任何');
DEFINE ('_UE_MATCH_INCLUDE_ANY_OF_NOT','不包含任何');
DEFINE ('_UE_MATCH_EXCLUSIONS','排除');
DEFINE ('_UE_AVATAR_NONE','暫無頭像');
DEFINE ('_UE_AVATAR_NO_CHANGE','No change of image');
DEFINE ('_UE_AVATAR_UPLOAD','上傳頭像');
DEFINE ('_UE_AVATAR_UPLOAD_NEW','上傳新頭像');
DEFINE ('_UE_AVATAR_SELECT','從你的相冊中選擇一張圖片');
DEFINE ('_UE_HAS_PROFILE_IMAGE','已上傳頭像');
DEFINE ('_UE_HAS_NO_PROFILE_IMAGE','暫無頭像');
DEFINE ('_UE_AGE_YEARS','%s 年');
DEFINE ('_UE_YEARS','年');
DEFINE ('_UE_HI_NAME','你好, %s');

// 1.2 Backend:
DEFINE('_UE_TOP_AND_BOTTOM','頂部和底部');
DEFINE('_UE_REG_SHOW_ICONS_EXPLAIN','顯示圖標說明文字');
DEFINE('_UE_REG_SHOW_ICONS_EXPLAIN_DESC','在註冊頁面頂部和底部圖標是否顯示說明文字(默認在頂部和底部)');
DEFINE('_UE_ICONS_DISPLAY','在空白處顯示圖標');
DEFINE('_UE_ICONS_DISPLAY_DESC','圖標和圖標說明文字是否在註冊和用戶編輯時顯示.當說明文字存在是，資訊圖標將始終顯示.');
DEFINE('_UE_REG_SHOW_LOGIN_ON_PAGE','在註冊頁面顯示登入模塊');
DEFINE('_UE_REG_SHOW_LOGIN_ON_PAGE_DESC','是否在註冊頁面旁顯示登入模塊. 注意: CB login 模塊必須在設定此功能前安裝.');
DEFINE('_UE_REQUIRED_ONLY','僅顯示必須的圖標');
DEFINE('_UE_PROFILE_ONLY','僅顯示個人檔案/ 無個人檔案圖標');
DEFINE('_UE_REQUIRED_AND_PROFILE_ONLY','僅顯示必需的和個人檔案圖標');
DEFINE('_UE_INFO_ONLY','僅顯示資訊圖標說明');
DEFINE('_UE_REQUIRED_AND_INFO_ONLY','必需的和資訊說明圖標');
DEFINE('_UE_PROFILE_AND_INFO_ONLY','個人檔案圖標和資訊說明圖標');
DEFINE('_UE_REQUIRED_PROFILE_AND_INFO','所有圖標:必需的,個人檔案圖標');
DEFINE('_UE_ALWAYSRESAMPLEUPLOADS','重新生成上傳的頭像圖片檔案');
DEFINE('_UE_ALWAYSRESAMPLEUPLOADS_DESC','重新生成上傳的頭像圖片檔案可以增強安全性,但只有 ImageMagic 可以保持 GIFs動畫圖片原貌.');
DEFINE('_UE_FRONTENDUSERPARAMS','允許用戶編輯個人前臺CMS參數');
DEFINE('_UE_FRONTENDUSERPARAMS_DESC','顯示用戶參數并允許用戶在個人檔案頁面進行修改.');
DEFINE('_UE_REG_CB_EMAILPASS','自動生成隨機註冊密碼');
DEFINE('_UE_REG_CB_EMAILPASS_DESC','是否自動生成密碼并通過 email 寄送給用戶(開啟此功能時) 或者在註冊頁面詢問用戶 (關閉此功能時,默認設定,推薦設定).');
DEFINE('_UE_REG_EMAILCHECKER','Ajax Email 檢查器');
DEFINE('_UE_REG_EMAILCHECKER_WARNING','注意: 如果你的PHP系統未安裝或未啟用"getmxrr()" . 如果未啟用此PHP功能的話，Email DNS和SMTP 檢查功能將不可用.');
DEFINE('_UE_REG_EMAILCHECKER_DESC','允許檢查註冊過程中的email地址是否真實有效,檢查email格式、已存在的MX DNS 記錄, 以及相應的Email伺服器通過SMTP使用此Email地址接受郵件的資訊.同樣可以檢查Email地址是否被真實的註冊過.注意:此附加功能可能會導致"侵犯隱私權"，請遵守所在國相關法律.當註冊時，任何人都可以使用此功能來檢測所寫email是否被註冊! 請在仔細研究你所在國家的法律和空間上的規定后，啟用此功能. 使用SMTP檢查功能需要你的伺服器擁有一個固定IP地址, 站點所填寫的email地址必須有效,且此伺服器需在Email伺服器的認證伺服器里表(SPF記錄)內. 需要注意的是雖然此功能已經設定保護但在一些特殊情況下此功能可能被濫用. 此功能尚處在測試過程中,且未對大型站點做任何優化:請使用前詳細測試 !');
DEFINE('_UE_REG_EMAILCHECKER_VALID_EMAIL_ONLY','是, 僅檢查Email伺服器接收郵件功能');
DEFINE('_UE_REG_EMAILCHECKER_NOT_REGISTERED_AND_VALID_EMAIL','是,檢查Email是否真實註冊和伺服器資訊 (!!!注意請勿侵犯隱私權)');
DEFINE('_UE_REG_UNIQUEEMAIL','檢查E-mail唯一性');
DEFINE('_UE_REG_UNIQUEEMAIL_DESC','開啟此功能時僅允許同一 Email 註冊一個用戶. 這是CMS全局設定參數,CB將根據此設定自動修改參數.');

// 1.2 FIREBOARD support - these strings are actually used in a CB tab and fields that are added by FB backend
DEFINE('_UE_FB_TABTITLE', '論壇設定' );
DEFINE('_UE_FB_ORDERING_OLDEST', '較早的在前' );
DEFINE('_UE_FB_ORDERING_LATEST', '較新的在前' );
DEFINE('_UE_FB_ORDERING_TITLE', '消息排序' );
DEFINE('_UE_FB_SIGNATURE', '你的論壇簽名' );
DEFINE('_UE_FB_VIEWTYPE_FLAT', '檢視所有' );
DEFINE('_UE_FB_VIEWTYPE_THREADED', '檢視發帖' );
DEFINE('_UE_FB_VIEWTYPE_TITLE', '瀏覽模式偏好' );
DEFINE('_UE_FB_TABDESC', '普通資料選項' );
// 1.2 Extended forum strings for FIREBOARD favorites support in CB plugin (this is why they have _FB_ instead of _FORUM)
DEFINE('_UE_FB_FAVORITES','收藏夾');
DEFINE('_UE_FB_REMOVE_FAVORITE_THREAD','::刪除收藏鏈接 ::');
DEFINE('_UE_FB_NO_FAVORITES_FOUND','收藏夾內無任何內容');
DEFINE('_UE_FB_REMOVE_FAVORITES_ALL','刪除收藏夾內所有內容');
DEFINE('_UE_FB_CONFIRMUNFAVORITEALL','情確認刪除收藏夾內所有內容 ?');

// 1.2 CB Team extensions
DEFINE('_UE_PROFILE_GALLERY','個人檔案圖庫');
DEFINE('_UE_PROFILE_GALLERY_DESC','此標簽包含一個基本的圖片庫');
DEFINE('_UE_PROFILE_GALLERY_MODERATION','待認證圖片');
DEFINE('_UE_PROFILE_GALLERY_MODERATION_DESC','此標簽內包含所有未經過認證的圖片');
DEFINE('_UE_PROFILE_BOOK','個人檔案薄');
DEFINE('_UE_PROFILE_BOOK_DESC','個人檔案薄描述資訊');

// 1.2 CB beta 8+9+10:
DEFINE('_UE_AVATAR_DISCLAIMER','點擊 "%s"前,請確認你有權限使用該圖片，任何侵犯他人權利的圖片會直接導致賬戶被封禁.');
DEFINE('_UE_AVATAR_DISCLAIMER_TERMS','點擊 "%s"錢, 請確認你有權限使用該圖片,并確認該圖片未違反%s.');
DEFINE('_UE_AGE','Age');
DEFINE('_UE_CLOAKED','此Email被反垃圾郵件程序所保護，檢視前請開啟瀏覽器的JavaScript功能');
DEFINE ('_UE_YEAR','年');
DEFINE ('_UE_MONTHS','月');
DEFINE ('_UE_MONTH','月');
DEFINE ('_UE_DAYS','日');
DEFINE ('_UE_DAY','日');
DEFINE ('_UE_HOURS','小時');
DEFINE ('_UE_HOUR','小時');
DEFINE ('_UE_MINUTES','分鐘');
DEFINE ('_UE_MINUTE','分鐘');
DEFINE ('_UE_SECONDS','秒');
DEFINE ('_UE_SECOND','秒');
DEFINE ('_UE_ANYTHING_AGO','%s 之前');
DEFINE ('_UE_NOW','現在');
DEFINE ('_UE_YEAR_NOT_IN_RANGE','年份 %s 請在 %s ～ %s范圍內');
DEFINE ('_UE_ADD_IMAGE','添加圖片');
DEFINE ('_UE_LINE','線');
DEFINE ('_UE_COLUMN','列');
DEFINE ('_UE_MONTHS_1','一月');
DEFINE ('_UE_MONTHS_2','二月');
DEFINE ('_UE_MONTHS_3','三月');
DEFINE ('_UE_MONTHS_4','四月');
DEFINE ('_UE_MONTHS_5','五月');
DEFINE ('_UE_MONTHS_6','六月');
DEFINE ('_UE_MONTHS_7','七月');
DEFINE ('_UE_MONTHS_8','八月');
DEFINE ('_UE_MONTHS_9','九月');
DEFINE ('_UE_MONTHS_10','十月');
DEFINE ('_UE_MONTHS_11','十一月');
DEFINE ('_UE_MONTHS_12','十二月');
DEFINE ('_UE_NO_ANSWER','無答案');
DEFINE ('_UE_ANY','任何');
DEFINE ('_UE_TODAY','今天');
// 1.2 CB beta 8+9+10 backend:
DEFINE ('_UE_SHOWEMPTYTABS','顯示空白標簽');
DEFINE ('_UE_SHOWEMPTYTABS_DESC','顯示所有標簽(無論是否包含文字), 或僅顯示有文字的標簽');
DEFINE ('_UE_SHOWEMPTYFIELDS','顯示空白區域');
DEFINE ('_UE_SHOWEMPTYFIELDS_DESC','顯示所有空白區域（無論是否有任何內容），或僅顯示有內容的部分');
DEFINE ('_UE_EMPTYFIELDSTEXT','顯示在空白區域的文字資訊');
DEFINE ('_UE_EMPTYFIELDSTEXT_DESC','顯示在空白區域的文字資訊. 多語言字段和區域替換功能同時起效. 字段 _UE_NO_ANSWER 將顯示 "無答案".');
// 1.2 CB RC 2 beta 2:
DEFINE('_UE_USERNAME_OR_EMAIL','用戶名或 E-mail 地址');
// 1.2 CB RC 2 beta 2 backend:
DEFINE('_UE_SAVE','儲存');
DEFINE('_UE_LOGIN_TYPE','登錄框內容設定');
DEFINE('_UE_LOGIN_TYPE_DESC','可選擇下列四種模式中的任何一種設定登錄框輸入內容: 用戶名+E-mail地址,用戶名+密碼,用戶名+E-mail地址+密碼, E-mail地址+密碼. CB login 模塊將根據此處的選擇自動調整輸入內容字符框..');
DEFINE('_UE_INCORRECT_EMAIL_OR_PASSWORD','E-Mail地址資訊或密碼錯誤.請仔細檢查后重試.');
// 1.2 CB RC 4 frontend:
DEFINE('_UE_ERROR_IN_QUERY_TURN_SITE_DEBUG_ON_TO_VIEW','資料庫查詢有錯誤。網站管理員可以開啟除錯模式來查看并修復錯誤。');
// 1.2 CB RC 4 backend:
DEFINE('_UE_USERNAME_OR_AUTH','用戶名, email 或啟用的其它認證插件');
// 1.2 Stable:same as RC4
// 1.2.1 Stable:
DEFINE('_UE_MALE','男');
DEFINE('_UE_FEMALE','女');
// 1.2.2 backend:
DEFINE('_UE_DISPLAY_ROUNDED_DIV','帶標題的圓角 div');
DEFINE('_UE_WRONG_CONFIRMATION_CODE','確認碼錯誤。請對照您的 Email（或許郵件被誤判為“垃圾郵件”了），填寫正確的確認碼。');
// 1.2.3:
DEFINE('_UE_LOST_YOUR_PASSWORD','忘記密碼了？');
DEFINE('_UE_LOST_PASSWORD_EMAIL_ONLY_DESC','如果您 <strong>忘記了密碼</strong>，請輸入您的 E-mail 地址，然后點擊“取回密碼”按鈕，您將很快收到新密碼。然后您就可以使用這個新密碼登錄我們網站了。');
// 1.4 Stable:
DEFINE('_UE_ENABLESPOOFCHECK','啟用反欺詐 sessions 檢查');
DEFINE('_UE_ENABLESPOOFCHECK_DESC','你是否希望開啟針對會話（session）的欺詐檢查？ （強烈推薦使用，除非你啟用之后發生了 session 過期或者 cookie 錯誤問題，那么請停用）。默認是停用狀態，以便獲得最佳的穩定性和可用性。');


// IMPORTANT WARNING: The closing tag, "?" and ">" has been intentionally omitted - CB works fine without it.
// This was done to avoid errors caused by custom strings being added after the closing tag. ]
// With such tags, always watchout to NOT add any line or space or anything after the "?" and the ">".

// added for plug-in cbprofilebook
DEFINE('_pb_ProfileBook','私人留言本');
DEFINE('_pb_EnableProfileBook','啟用私人留言本');
DEFINE('_pb_AutoPublish','留言自動發布');
DEFINE('_pb_NotifyMe','接收留言通知');

// added for plug-in Geocoding
DEFINE('Geocoding','地理標簽');
DEFINE('Manually Enter Lat/Lng','手動輸入緯度/經度');
DEFINE('Latitude','緯度（Latitude）');
DEFINE('Longitude','經度（Longitude）');

// added by baijianpeng for CB Confirm Email plugin
if (!defined('_UE_CONFIRMEMAIL_Label')) DEFINE('_UE_CONFIRMEMAIL_Label','再次輸入 Email');
if (!defined('_UE_CONFIRMEMAIL_Enter_Label')) DEFINE('_UE_CONFIRMEMAIL_Enter_Label','再次輸入 Email');
if (!defined('_UE_CONFIRMEMAIL_NOT_VALID')) DEFINE('_UE_CONFIRMEMAIL_NOT_VALID','兩次輸入的 Email 地址不一致');
if (!defined('_UE_CONFIRMEMAIL_Desc')) DEFINE('_UE_CONFIRMEMAIL_Desc','請再次輸入一次您的 email 地址以避免輸錯');
?>