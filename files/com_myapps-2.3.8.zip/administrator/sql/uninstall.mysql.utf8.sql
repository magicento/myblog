DROP TABLE IF EXISTS `#__myapps_tab1`;
