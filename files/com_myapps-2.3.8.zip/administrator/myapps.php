<?php
/**
 * @version     2.3.8
 * @package     com_myapps
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      zhang.jiachao <info@lamp99.com> - http://www.lamp99.com
 */


// no direct access
defined('_JEXEC') or die;

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_myapps')) {
	return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Include dependancies
jimport('joomla.application.component.controller');

$controller	= JController::getInstance('Myapps');
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();
