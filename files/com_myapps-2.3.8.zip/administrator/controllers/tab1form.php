<?php
/**
 * @version     2.3.8
 * @package     com_myapps
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      zhang.jiachao <info@lamp99.com> - http://www.lamp99.com
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Tab1form controller class.
 */
class MyappsControllerTab1form extends JControllerForm
{

    function __construct() {
        $this->view_list = 'tab1list';
        parent::__construct();
    }

}