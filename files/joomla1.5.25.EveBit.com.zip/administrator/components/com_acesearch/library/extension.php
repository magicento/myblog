<?php
/**
* @version		1.5.0
* @package		AceSearch Library
* @subpackage	Extension
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Extension class
class AcesearchExtension {
	
	protected $extension = null;
	protected $params = null;
	protected $filter_params = null;
	protected $aid = null;
	protected $db = null;
	
	// bu değişken gelişmiş aramadan geldiğini gösterir, is_advanced_search olarak değiştirilecek
	protected $search_fields = false;
	
	protected $admin = true;
	protected $site = false;
	
	function __construct($extension, $ext_params, $filter_params = null) {
		// Set variables
		$this->AcesearchConfig = AcesearchFactory::getConfig();
		$this->extension = $extension;
		$this->fields = self::getFields($extension->extension);
		$this->params = $ext_params;
		$this->filter_params = $filter_params;
		$this->aid =& JFactory::getUser()->get('aid');
		$this->db =& JFactory::getDBO();
		$this->admin = JFactory::getApplication()->isAdmin();
		$this->site = JFactory::getApplication()->isSite();		
	}
	
    function is16() {
		return AcesearchUtility::is16();
	}
	
	public function getExtraFields($params, &$fields) {
	}

	public function getCategoryList() {
		return array();
	}
	
	public function getMenuParams($id) {
		static $params = array();
		
		if (!isset($params[$id])) {
			$params[$id] = AcesearchUtility::getMenu()->getParams($id);
		}
		
		return $params[$id];
	}
	
	public function getInt($name, $default = 0) {
		$var = JRequest::getVar($name, $default, 'post', 'int');
		
		return $var;
	}
	
	public function getWord($name, $default = '') {
		$var = JRequest::getVar($name, $default, 'post', 'word');
		
		return $var;
	}
	
	public function getCmd($name, $default = '') {
		$var = JRequest::getVar($name, $default, 'post', 'cmd');
		
		return $var;
	}
	
	public function getString($name, $default = '') {
		$var = (string) JRequest::getVar($name, $default, 'post', 'string', 0);
		
		return $var;
	}
	
	public function getSecureString($name, $default = '') {
		$var = (string) JRequest::getVar($name, $default, 'post', 'string', 0);
		
		$var = self::getSecureText($var);
		
		return $var;
	}
	
	protected function getFields($component) {
		$fields = new stdClass();
		$xml_file = JPATH_ACESEARCH_ADMIN.'/extensions/'.$component.'.xml';
		
		$xml =& JFactory::getXMLParser('Simple');
		if (!$xml->loadFile($xml_file)) {
			unset($xml);
			return $fields;
		}
		
		if (is_null($xml)) {
			unset($xml);
			return $fields;
		}
		
		$manifest =& $xml->document;
		
        $fields_xml = $manifest->getElementByPath('fields');
		if (!is_a($fields_xml, 'JSimpleXMLElement') || (count($fields_xml->children()) == 0)) {
			return $fields;
		}
		
		$childrens = $fields_xml->children();
		foreach ($childrens as $children) {
			$name = $children->attributes('name');
			
			$fields->$name = new stdClass();
			$fields->$name->client = $children->attributes('client');
			$fields->$name->type = $children->attributes('type');
		}
		
		return $fields;
	}

	protected function getExtraFieldsWhere($sql, $secure = true) {
        return self::getCckFieldsWhere($sql, $secure);
    }

	

	protected function getCckFieldsWhere($sql, $prefix = '', $secure = true) {
		$ret = array();

        $fields = $this->params->get('extrafields', '');

		if (empty($fields)) {
			return $ret;
		}

		if (!is_array($fields)) {
            $fields = array($fields);
		}
		
        foreach ($fields as $field) {
            self::_getCckFieldsWhereQuery($field, $custom_fields, $sql, $prefix, $secure);
        }

		if (empty($custom_fields)) {
			return $ret;
		}

		return $custom_fields;
	}

	protected function _getCckFieldsWhereQuery($field, &$custom_fields, $sql, $prefix, $secure) {
		$qu = JRequest::getString('query', '');
		$all = JRequest::getString('all', '');
		$no = JRequest::getString('none', '');
        $query = AceSearchSearch::getQuery('post');

        if (empty($query)) {
            return;
        }

		list($field_id, $field_name) = explode('_', $field);

		$f = '1';
		if (empty($qu)) {
			$f = JRequest::getInt('ja_'.$field_id);
		}

		if ($f == '1') {
			if (empty($field_id)) {
				return;
			}

            $words = explode(' ', $query);

            $words_count = count($words);
            $prfx_sffx = 0;

            foreach($words as $word) {
                $word = JString::trim($word);

                if (empty($word)) {
                    continue;
                }

                $word = self::getSecureText($word);

                if (!isset($custom_fields[$word])) {
                    $custom_fields[$word] = array();
                }

                if ($words_count == 1 || empty($all)) {
                    $prfx_sffx = '';
                }
                else {
                    $prfx_sffx++;
                }

                $search = array('{prefix}', '{field_name}', '{field_id}', '{query}');
                $replace = array($prefix.$prfx_sffx, $field_name, $field_id, $word);

                $custom_fields[$word][] = str_replace($search, $replace, $sql);
            }

            /*if (!empty($no)) {
                $words = explode(' ', $no);

                foreach($words as $word) {
                    $word = JString::trim($word);

                    if (empty($word)) {
                        continue;
                    }

                    $word = self::getSecureText($word);

                    if (!isset($custom_fields[$word])) {
                        $custom_fields[$word] = array();
                    }

                    $search = array('{field_name}', '{field_id}', '{query}');
                    $replace = array($field_name, $field_id, $word);

                    $sql = str_replace(' LIKE ', ' NOT LIKE ', $sql);

                    $custom_fields[$word][] = str_replace($search, $replace, $sql);
                }
            }*/
		}
	}
	
	protected function getSearchFieldsWhere($src_fields, $cck_fields = null) {
		$where = $wh = array();
		
		if (empty($src_fields)) {
			return $where;
		}
		
		$query 		= self::getSearchQuery('query');   
		$exact 		= self::getSearchQuery('exact');
		$all 		= self::getSearchQuery('all');
		$any 		= self::getSearchQuery('any');
		$none 		= self::getSearchQuery('none');
		
		$ext        = "exact";
		
		if (!empty($query) && trim($query, '"') != $query) {
			$exact = JString::trim($query, '"');
			$query = "";
			$ext   = "query";
		}
		
		$fields = explode(', ', $src_fields);

		if (!empty($all)) {
			$sub_where = array();
			$this->search_fields = true;

            $words = explode(' ', $all);

            foreach ($words as $word) {
                $word = JString::trim($word);

                if (empty($word)) {
                    continue;
                }

                $sub_wh = array();

                $word = self::getSecureText($word);

                self::_getSearchFieldsWhereQuery($sub_wh, $word, $fields, 'all');

                self::_getSearchFieldsWhereQueryCck($sub_wh, $word, $cck_fields);

                if (empty($sub_wh)) {
                    continue;
                }

                $sub_where[] = implode(' OR ', $sub_wh);
            }

			if (!empty($sub_where)) {
				$where[] = '(' . implode(') AND (', $sub_where) . ')';
			}
		}
	    elseif (!empty($query) || !empty($any)) {
			$sub_where = array();
			if (!empty($any)) {
			    $this->search_fields = true;
			}
			
			$x = 'query';
			
			if (empty($query)) {
				$query = $any;
				$x = 'any';
			}

            $words = explode(' ', $query);

            foreach($words as $word) {
                $word = JString::trim($word);

                if (empty($word)) {
                    continue;
                }

                $word = self::getSecureText($word);

                self::_getSearchFieldsWhereQuery($sub_where, $word, $fields, $x);

                self::_getSearchFieldsWhereQueryCck($sub_where, $word, $cck_fields);
            }
			
			if (!empty($sub_where)) {
				$where[] = '(' . implode(' OR ', $sub_where) . ')';
			}
		}
	    elseif (!empty($exact)) {
			$sub_where = array();
			$this->search_fields = true;
			
			$exact = self::getSecureText($exact);
			
			self::_getSearchFieldsWhereQuery($sub_where, $exact, $fields, $ext);

            self::_getSearchFieldsWhereQueryCck($sub_where, $exact, $cck_fields);
		
			if (!empty($sub_where)) {
				$where[] = '(' . implode(' OR ', $sub_where) . ')';
			}
		}
		
		if (!empty($none)) {
			$sub_where = array();
			$this->search_fields = true;
			
			$none = self::getSecureText($none);
			
			self::_getSearchFieldsWhereQuery($sub_where, $none, $fields, 'none', ' NOT ');

            self::_getSearchFieldsWhereQueryCck($sub_where, $none, $cck_fields);
		
			if (!empty($sub_where)) {
				$where[] = '(' . implode(' AND ', $sub_where) . ')';
			}
		}
		
		if (!empty($this->AcesearchConfig->blacklist)) {
			$sub_where = array();
			$keywords = explode(',', $this->AcesearchConfig->blacklist);
			
			foreach($keywords as $keyword) {
				$keyword = trim($keyword);
				
				$key = self::getSecureText($keyword);
				
				self::_getSearchFieldsWhereQuery($sub_where, $key, $fields, 'blacklist', ' NOT ');
			}
		
			if (!empty($sub_where)) {
				$where[] = '(' . implode(' OR ', $sub_where) . ')';
			}
		}
		
		if (!empty($where)) {
            $wh[] = '('.implode(' AND ', $where) . ')';
		}
		
		return $wh;
	}

	protected function _getSearchFieldsWhereQuery(&$where, $query, $fields, $x, $not = '') {
		foreach ($fields as $field) {
			$field = trim($field);
			
			$pos = strpos($field, ':');
            if ($pos !== false) {
                list($field_db, $field_req) = explode(':', $field);
				
				if (empty($field_db) || empty($field_req)) {
					continue;
				}
			}
			else {
				$field_db = $field_req = $field;
			}
			
			if ($this->site && $this->fields->$field_req->client == '1') {
				continue;
			}
			
			if ($this->admin && $this->fields->$field_req->client == '0') {
				continue;
			}
			
			if ($this->params->get($field_req, '1') == '0') {
				continue;
			}
			
			if ($this->fields->$field_req->type == 'checkbox') {
				$ext = self::getCmd('ext');
				$limitstart = self::getCmd('limitstart');
				
				if ($x != 'query' && $x != 'blacklist' && !empty($ext) && empty($limitstart)) {
					$req = self::getInt($field_req);
					
					if (empty($req) && $this->params->get($field_req, '1') != '2') {
						continue;
					}
				}
			}
			else {
				$req = self::getCmd($field_req, '1');
				if (empty($req)) {
					continue;
				}
			}
			
			$where[] = "(LOWER({$field_db}) {$not}LIKE {$query})";
		}
	}

	protected function _getSearchFieldsWhereQueryCck(&$sub_wh, $word, $cck_fields) {
        if (empty($cck_fields) || !is_array($cck_fields) || !isset($cck_fields[$word])) {
            return;
        }

        $queries = $cck_fields[$word];

        foreach ($queries as $query) {
            $sub_wh[] = $query;
        }
    }
	
	public function getFilterWhere(&$where, $fields) {
		foreach ($fields as $key => $values) {
			$sub_where = array();
			$is_text = $is_secure = false;
			
			$db_fields = explode(',', $values);
			
			$types = explode(':', $key);			
			$req_field = $types[0];
			if (!empty($types[1])) {
				if ($types[1] == 'text') {
					$is_text = true;
				}
				else {
					$is_secure = true;
				}
			}
			
			if ($is_text) {
				$request = self::getString($req_field);
			}
			elseif ($is_secure) {
				$request = self::getSecureText(self::getString($req_field));
			}
			else {
				$request = self::getInt($req_field);
			}
			
			if (!empty($request)) {
				foreach ($db_fields as $db_field) {
					$db_field = trim($db_field);
					
					if ($is_secure) {
						$sub_where[] = "{$db_field} LIKE {$request}";
					}
					else {
						$sub_where[] = "{$db_field} = '{$request}'";
					}
				}
			}
			elseif ($this->site) { 
				if (empty($this->filter_params)) {
					return;
				} 
				
				$value = $this->filter_params->get($req_field);
				
				if (empty($value)) {
					continue;
				}
				
				foreach ($db_fields as $db_field) {
					$db_field = trim($db_field);
					
					if ($is_text || $is_secure) {
						$sub_where[] = "{$db_field} IN ('{$value}')";
					}
					else {
						$sub_where[] = "{$db_field} IN ({$value})";
					}
				}
			}
			
			$sub_where = (count($sub_where) ? implode(' OR ', $sub_where): '');
			if (!empty($sub_where)) {
				$where[] = '('.$sub_where.')';
			}
		}
	}
	
	protected function getUserWhere(&$where, $field_1, $field_2 = null) {
		$sub_where = array();
		
		$request = self::getSecureText(self::getString('user', null));
		
		if (!empty($request)) {
			$id = AceDatabase::loadResult("SELECT id FROM #__users WHERE LOWER(name) LIKE {$request}");  
			if (empty($id)) {
				return "";
			}
			
			if (!empty($field_1)) {
				$sub_where[] = "{$field_1} = {$id}"; 
			}
			
			if (!empty($field_2)) {
				$sub_where[] = "LOWER({$field_2}) LIKE {$request}";
			}
			
			$sub_where = (!empty($sub_where) ? implode(' OR ', $sub_where) : '');
			if (!empty($sub_where)) {				
				$where[] = '('.$sub_where.')';
			}			 
		}	
		elseif (!empty($this->filter_params)) {
			$user_filter = $this->filter_params->get('user');
			if (empty($user_filter)) {
				return;
			}
			
			$users = explode(',', $user_filter);
			
			if (!empty($field_1)) {
				$sub_where_1 = array();
				
				foreach ($users AS $user) {
					if (empty($user)) {
						continue;
					}
					
					$sub_where_1[] = "LOWER(name) LIKE '{$user}'";
				}
			
				$sub_where_1 = (!empty($sub_where_1) ? ' WHERE ' . implode(' OR ', $sub_where_1): '');
				if (empty($sub_where_1)) {
					return "";
				}
				
				$user_ids = AceDatabase::loadResultArray("SELECT id FROM #__users {$sub_where_1}");
				$ids = implode(',', $user_ids);
				
				if (empty($ids)) {
					return "";
				}
				
				$sub_where[] = "({$field_1} IN ({$ids}))"; 
			}
			
			if (!empty($field_2)) {
				$sub_where_2 = array();
			
				foreach ($users AS $user) {
					if (empty($user)) {
						continue;
					}
					
					$sub_where_2[] = "LOWER({$field_2}) LIKE '{$user}'";
				}
				
				$sub_where_2 = (!empty($sub_where_2) ? implode(' OR ', $sub_where_2): '');
				
				if (!empty($sub_where_2)) {
					$sub_where[] = $sub_where_2;
				}
			}
			
			$sub_where = (!empty($sub_where) ? implode(' OR ', $sub_where): '');
			if (!empty($sub_where)) {
				$where[] = $sub_where;
			}
		}
	}
	
	protected function getDateWhere(&$where, $db_field, $db_field2 = '0', $linux = 0) {
		$sub_where = "";
        $filter = JRequest::getInt('filter');

		if ($this->search_fields == false && !empty($filter)) {
            $sub_where = array();

			if ($this->filter_params->get('start_date','') != ''){
				$sub_where[] = $db_field." >= '".$this->filter_params->get('start_date')."'";
			}
			
			if ($this->filter_params->get('end_date','')!= ''){
				$sub_where[] = $db_field." <= '".$this->filter_params->get('end_date')."'";
			}
			
			if (!empty($sub_where)) {
				$sub_where = '('.(count($sub_where) ? '' . implode(' AND ', $sub_where): '').')'; 
			}
		}
		elseif ($this->search_fields == true && ($this->params->get('days', '1') == '1' || $this->params->get('daterange', '1') == '1' || !empty($filter))) {
            if ($db_field2 == '0') {
				$db_field2 = $db_field;
			}
			
			$days = self::getInt('days');
			
			if (!empty($days) && $days != '-1') {
				$date = '';
				
				if ($days == 1) {
					if ($linux == 1) {
						$date = mktime(12, 00, 00, date('m'), date("d")-1, date('Y'));
					}
					else {
						$date = date('Y-m-d', mktime(12, 00, 00, date('m'), date("d")-1, date('Y')));
					}
				}
				elseif ($days == 3 || $days == 6) {
					if ($linux == 1) {
						$date = mktime(12, 00, 00, date("m") - $days, date('d'), date('Y'));
					}
					else {
						$date = date('Y-m-d', mktime(12, 00, 00, date("m") - $days, date('d'), date('Y')));
					}
				}
				elseif ($days == 12) {
					if ($linux == 1) {
						$date =	mktime(12, 00, 00, 01, 01, date('Y') -1);
					}
					else {
						$date = date('Y-m-d', mktime(12, 00, 00, 01, 01, date('Y') -1));
					}
				}
				
				$sub_where = "({$db_field} >= '".$date."')";
			}
			else {
                $fltr = !empty($this->filter_params) ? $this->filter_params->get('start_date', '2000-01-01') : '2000-01-01';
                list($fltr_year, $fltr_month, $fltr_day) = explode('-', $fltr);

                $from_year	= self::getInt('fromyear', $fltr_year);
                $to_year	= self::getInt('toyear', date('Y'));
                $from_month	= self::getInt('frommonth', $fltr_month);
                $to_month	= self::getInt('tomonth', date('m'));
                $from_day	= self::getInt('fromday', $fltr_day);
                $to_day		= self::getInt('today', date('d'));

                if ($to_year == date('Y') && $to_month == date('m') && $to_day == date('d') && $from_year == 2000 && $from_month == 01 && $from_day == 01) {
                   return;
                }

                if ($linux == '1') {
                    $from_date     = mktime(date("H"), date("i"), date("s"), $from_month, $from_day, $from_year);
                    $to_date       = mktime(date("H"), date("i"), date("s"), $to_month, $to_day, $to_year);
                }
                else {
                    $from_date = $from_year.'-'.$from_month.'-'.$from_day;
                    $to_date = $to_year.'-'.$to_month.'-'.$to_day;
                }

				$sub_where = "({$db_field} >='".$from_date."' AND {$db_field2} <= '".$to_date."')";
			}
		}
		
		if (!empty($sub_where)) {
			$where[] = $sub_where;
		}
	}
	
	public function getOrderBy(&$where, $prefix = '', $just_relevance = false) {
		$where .= " ORDER BY acesearch_relevance DESC";
		
		/*if ($just_relevance == true) {
			$where .= " ORDER BY acesearch_relevance DESC";
			return;
		}
		
		$order = self::getWord('order');
		$orderdir = self::getWord('orderdir');
		if (!empty($order) && !empty($orderdir)) {
			if ($order == 'acesearch_relevance') {
				$where .= " ORDER BY {$order} {$orderdir}";
			}
			else {
				$where .= " ORDER BY {$prefix}{$order} {$orderdir}";
			}
		}
		else {
			$where .= " ORDER BY acesearch_relevance DESC";
		}*/
	}
	
	public function getOrder($date = 1, $hits = 1, $relevance = 1) {
		$ret = '';
		
		if ($this->AcesearchConfig->google_more_results == '0') {
			//return $ret;
		}

        $default = $relevance ? 'relevance' : '';
		
		$order = JRequest::getWord('order', $default);

        if (empty($order)) {
            return $ret;
        }
		
		if ($order == 'relevance') {
            if ($relevance == 0) {
                return $ret;
            }

            $order = 'acesearch_relevance';
        }
        else if ($order == 'date' && $date == 0) {
            return $ret;
        }
        else if ($order == 'hits' && $hits == 0) {
            return $ret;
        }
		
		$ret = " ORDER BY {$order} DESC";

		return $ret;
	}
	
	public function getIdentifier($type = 'Item') {
		return "'{$this->extension->extension}' AS acesearch_ext, '{$type}' AS acesearch_type";
	}
	
	public function getRelevance($fields) {
		$relevance = '';
		$is_exact = true;
		$sub_rel = array();
		
		$q = JRequest::getString('exact');
		
		if (empty($q)) {
			$is_exact = false;
			
			$q = JRequest::getString('query');
			if (empty($q)) {
				$q = JRequest::getString('any');
			}
		}
		
		if (empty($q)) {
			return $relevance;
		}
		
		$q = JString::strtolower($q);
		
		foreach ($fields as $type => $field) {
			$flds = explode(',', $field);

            foreach ($flds as $fld) {
                $fld = JString::trim($fld);

                if (empty($fld)) {
                    continue;
                }

                self::_getRelevanceQuery($sub_rel, $type, $fld, $q, $is_exact);
            }
		}

		$sub_rel = (count($sub_rel) ? implode(' + ', $sub_rel) : '');

		if (!empty($sub_rel)) {
			$relevance = '('.$sub_rel.') AS acesearch_relevance';
		}
		
		return $relevance;
	}
	
	public function _getRelevanceQuery(&$sub_rel, $type, $field, $q, $is_exact) {
		if ($type == 'title') {
			$sub_rel[] = self::_getRelevanceQuerySql($field, $q, 100, 90, 80);
		}
		else {
			$sub_rel[] = self::_getRelevanceQuerySql($field, $q, 10, 9, 8);
		}
		
		if ($is_exact == true || !strpos(JString::trim($q), ' ')) {
            return;
        }
        
        $words = explode(' ', $q);

        if (empty($words) || !is_array($words)) {
            return;
        }

        foreach ($words as $word) {
            if (empty($word)) {
                continue;
            }

            $sub_rel[] = self::_getRelevanceQuerySql($field, $word, 3, 2, 1);
        }
	}
	
	public function _getRelevanceQuerySql($field, $q, $point_1, $point_2, $point_3, $point_false = 0) {
		$q_1 = self::_getRelevanceSecureText($q, '', '');
		$q_2 = self::_getRelevanceSecureText($q, '', '%');
		$q_3 = self::_getRelevanceSecureText($q, '%', '%');
		
		return "(CASE ".
				"WHEN {$field} = {$q_1} THEN {$point_1} ".
				"WHEN {$field} LIKE {$q_2} THEN {$point_2} ".
				"WHEN {$field} LIKE {$q_3} THEN {$point_3} ".
				"ELSE {$point_false} ".
				"END)";
	}
	
	public function _getRelevanceSecureText($text, $sep_1 = '%', $sep_2 = '%') {
		if (empty($text)) {
			return $text;
		}
	
		return AceDatabase::quote(''.$sep_1.''.AceDatabase::getEscaped(urldecode($text), true).''.$sep_2.'', false);
	}
	
	public function getSlug($id = 'id', $alias = 'alias', $name = 'slug') {
		return "CASE WHEN CHAR_LENGTH({$alias}) THEN CONCAT_WS(':', {$id}, {$alias}) ELSE {$id} END AS {$name}";
	}
	
	public function insertCckFieldsAllJoins(&$query, $sql, $prefix) {
		// all araması için son tabloyu çoğaltmamız lazım ki her kelime aranabilsin
        $words = explode(' ', self::getString('all', ''));
        if (empty($words) || count($words) <= 1) {
			return;
		}
		
		$pre_no = 0;

		foreach($words as $word) {
			$word = JString::trim($word);

			if (empty($word)) {
				continue;
			}

			$pre_no++;

			$query .= str_replace('{prefix}', $prefix.$pre_no, $sql);
		}
	}
	
	public function getSqlLimit() {
		if ($this->site) {
			$limit = $this->params->get('result_limit', '');
			
			if (empty($limit)) {
				$limit = $this->AcesearchConfig->result_limit;
			}
			
			return $limit;
		}
		else {
			return $this->AcesearchConfig->admin_result_limit;
		}
	}
	
	public function getUser() {
		return "";
	}
	
	// --------------------
	
	public function _getItemProperties(&$item) {
		$properties = '';
        
		if ($this->params->get('show_section', '1') == '1'){
            $properties .= self::_getProperty($item, 'section');
        }
		
		if ($this->params->get('show_category', '1') == '1'){
            $properties .= self::_getProperty($item, 'category');
        }
		
		if ($this->params->get('show_date', '1') == '1'){
            $properties .= self::_getProperty($item, 'date');
        }
		
		if ($this->params->get('show_hits', '1') == '1'){
            $properties .= self::_getProperty($item, 'hits');
        }
		
		$item->properties = rtrim($properties, ' | ');
		
		unset($item->category);
		unset($item->date);
		unset($item->hits);
	}
	
	public function _getCategoryProperties(&$cat) {
		self::_getItemProperties($cat);
	}
	
	public function _getProperty($row, $type, $field = null) {
		$property = '';
		
		switch($type) {
			case 'section':
				if ($this->params->get('custom_name', '')) {
					$property = JText::_('COM_ACESEARCH_SEARCH_SECTION').': '.$this->params->get('custom_name', '').' | ';
				}
				else {
					$property = JText::_('COM_ACESEARCH_SEARCH_SECTION').': '.$this->extension->name.' | ';
				}
				break;
			case 'category':
				if (!empty($field)) {
					$fld = $field;
				}
				else {
					$fld = $type;
				}
				
				if (!empty($row->$fld)){ 
					$property = JText::_('COM_ACESEARCH_FIELDS_CATEGORY').': '.$row->$fld.' | ';
				}
				break;
			case 'date':
				if (!empty($field)) {
					$fld = $field;
				}
				else {
					$fld = $type;
				}
				
				if (!empty($row->$fld)){ 
					if (is_numeric($row->$fld)) {
						$date = $row->$fld;				
					}
					else {
						$date = strtotime($row->$fld);
					}
					
					$property = JText::_('COM_ACESEARCH_FIELDS_DATE').': '.date($this->AcesearchConfig->date_format, $date).' | ';
				}
				break;
			case 'hits':
				if (!empty($field)) {
					$fld = $field;
				}
				else {
					$fld = $type;
				}
				
				if (!empty($row->$fld)) {
					$property = JText::_('COM_ACESEARCH_FIELDS_HITS').': '.$row->$fld.' | ';
				}
				break;
		}
		
		return $property;
	}
	
	// --------------------
	
	public function getCategory($catid){
		static $cache = array();
		
		if (!isset($cache[$catid])) {
			$catid = intval($catid);
			$cache[$catid] = AceDatabase::loadObject("SELECT title, alias FROM #__categories WHERE id = {$catid}");
		}
		
		return $cache[$catid];
	}
	
	public function _getCategories($option) {
		$where = self::getSearchFieldsWhere('title:name, description');
		if (empty($where)){
			return array();
		}
		
		$where[] = "section = '{$option}'";
		
		if ($this->site) {
			$where[] = "published = 1";

			if ($this->AcesearchConfig->access_checker == '1') {
				$where[] = "access <= {$this->aid}";
			}
			
			$filter = JRequest::getInt('filter');
			if (!empty($filter)) {
				self::getFilterWhere($where, array('category' => 'id'));
			}
		}
		
		$where = (count($where) ? ' WHERE ' . implode(' AND ', $where): '');

        $order_by = self::getOrder(0, 0);
		
		$identifier = self::getIdentifier('Category');
		
		$relevance = self::getRelevance(array('title' => 'title', 'desc' => 'description'));
		
		$query = "SELECT {$identifier}, {$relevance}, id, alias, title AS name, description".
		" FROM #__categories".
		" {$where}{$order_by}";
		
		return AceDatabase::loadObjectList($query, '', 0, self::getSqlLimit());
	}
	
	// -------------------
	
	public function getExtraFieldsHTML($params, &$html, $is_module) {
		$fields = $params->get('extrafields', '');
		$module ="";
		if($is_module) {
			$module = '_module';
		}
		if (empty($fields)) {
			return '';
		}
		
		if (is_array($fields)) {
			foreach ($fields as $field) {
				$html[] = self::_getExtraFieldsHTML($field,$module);
			}
		}
		else {
			$html[] = self::_getExtraFieldsHTML($fields,$module);
		}
	}
	
	protected function _getExtraFieldsHTML($field,$module) {
		$output = '';
		
		list($field_id, $field_name) = explode('_', $field);
		
		$output  = '<div style="float:left; width:95%">';
		$output .= '<span class="acesearch_span_label'.$module.'">';
		$output .= JText::_($field_name);
		$output .= '</span>';
		$output .= '<span class="acesearch_span_field'.$module.'">';
		$output .= '<span><input type="checkbox" name="ja_'.$field_id.'" value="1" checked /></span>';
		$output .= '</span>';
		$output .= '</div>';
		
		return $output;
	}
	
	public function _getCategoryList($option, $apply_filter) {
		$where = array();
		
		$where[] = "section = '{$option}'";
		
		if ($this->site || $apply_filter == '1') {
			$where[] = "published = '1'";
			
			$filter = JRequest::getInt('filter');
			if (!empty($filter)) {
				self::getFilterWhere($where, array('category' => 'id'));
			}
			
			if ($this->AcesearchConfig->access_checker == '1') {
				$where[] = "access <= {$this->aid}";
			}
		}
		
		$where = (count($where) ? ' WHERE ' . implode(' AND ', $where): '');
		
		return AceDatabase::loadObjectList("SELECT id, title AS name, parent_id AS parent FROM #__categories {$where} ", '', '0', self::getSqlLimit());
	}
	
	function getExtensionName($extension) {
        static $names = array();

        if (!isset($names[$extension])) {
            $extensions = AcesearchFactory::getCache()->getExtensions();
            
            $params = new JParameter($extensions[$extension]->params);

            $custom_name = $params->get('custom_name', '');

            if (!empty($custom_name)) {
                $names[$extension] = $custom_name;
            }
            elseif (!empty($extensions[$extension]->name)) {
                $names[$extension] = $extensions[$extension]->name;
            }
            else {
                $names[$extension] = $row->extension;
            }
        }

        return $names[$extension];
	}
	
	// -------------------
	
	public function getItemid($vars = array(), $params = null) {
		$v['option'] = $this->extension->extension;
		
		$vars = array_merge($v, $vars);
		
		$item = self::findItemid($vars, $params);
		
		if (!empty($item->id)) {
			return '&Itemid='.$item->id;
		}
		
		return '';
	}
	
	// thanks to Nicholas K. Dionysopoulos, akeebabackup.com
	public function findItemid($vars = array(), $params = null) {
		if (empty($vars) || !is_array($vars)) {
			$vars = array();
		}
		
		$menus =& AcesearchUtility::getMenu();
		
		$items = $menus->getMenu();
		if (empty($items)) {
			return null;
		}
		
		$option_found = null;
		
		foreach ($items as $item) {
			if (is_object($item) && isset($item->published) && $item->published == '1') {
				$query = $item->query;
				
				if (empty($query['option'])) {
					continue;
				}
				
				if ($query['option'] != $vars['option']) {
					continue;
				}
				
				if (count($vars) == 1) {
					return $item;
				}
				
				if (is_null($option_found)) {
					$option_found = $item;
				}
				
				if (self::_checkMenu($item, $vars, $params)) {
					return $item;
				}
			}
		}
		
		if (!empty($option_found)) {
			return $option_found;
		}

		return null; 
	} 

	protected function _checkMenu($item, $vars, $params = null) {
		$query = $item->query;
		
		unset($vars['option']);
		unset($query['option']);
		
		foreach ($vars as $key => $value) {
			if (is_null($value)) {
				return false;
			}
			
			if (!isset($query[$key])) {
				return false;
			}
			
			if ($query[$key] != $value) {
				return false;
			}
		} 

		if (!is_null($params)) {
			$menus =& AcesearchUtility::getMenu(); 
			$check = $item->params instanceof JParameter ? $item->params : $menus->getParams($item->id);
			
			foreach ($params as $key => $value) {
				if (empty($value)) { // son anda değiştirildi, is_null idi, AcesearchUtility::getItemid(); çağırırken JRequest::getInt('filter'); ile ilgili
					continue;
				}
				
				if ($check->get($key) != $value) {
					return false;
				}
			}
		}

		return true;
	}
	
	public function fixVar($var) {
        if (!is_null($var)) {
            $pos = strpos($var, ':');
            if ($pos !== false) {
                $var = substr($var, 0, $pos);
			}
        }
		
		return $var;
    }
	
	public function getSecureText($text, $sep = '%') {
		if (empty($text)) {
			return $text;
		}
	
		return AceDatabase::quote(''.$sep.''.AceDatabase::getEscaped(urldecode($text), true).''.$sep.'', false);
	}
	
	public function getSearchQuery($query, $type = '') {
		return JString::trim(JString::strtolower(urldecode(JRequest::getString($query, '', $type))));
		//return preg_replace('/\s/u', ' ', trim(strtolower(urldecode(JRequest::getString($query,'',$type)))));
	}
}