<?php
/**
* @version		1.5.0
* @package		AceSearch Library
* @subpackage	Factory
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted Access');

// Factory class
abstract class AcesearchFactory {
	
	public static function &getConfig() {
		static $instance;

        if (version_compare(PHP_VERSION, '5.2.0', '<')) {
			JError::raiseWarning('100', JText::sprintf('AceSearch requires PHP 5.2.x to run, please contact your hosting company.'));
			return false;
		}
		
		if (!is_object($instance)) {
			$instance = new stdClass();
			
			jimport('joomla.application.component.helper');
			$acesearch =& JComponentHelper::getComponent('com_acesearch');
			
			$params = explode("\n", $acesearch->params);
			if (!empty($params)) {
				$array_keys = array();
				
				foreach ($params as $param){
					$pos = strpos($param, '=');
					
					$key = trim(substr($param, 0, $pos));
					$value = trim(substr($param, $pos + 1));
					
					if (empty($key)) {
						continue;
					}
					
					if (!isset($value)) {
						$value = '';
					}
					
					if (!empty($array_keys) && in_array($key, $array_keys)) {
						$value = json_decode(stripslashes($value), true);
					}
					
					$instance->$key = $value;
				}
			}
		}
		
		return $instance;
	}
	
	public static function &getCache($lifetime = '315360000') {
		static $instances = array();
		
		if (!isset($instances[$lifetime])) {
			require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesearch'.DS.'library'.DS.'cache.php');
			$instances[$lifetime] = new AcesearchCache($lifetime);
		}
		
		return $instances[$lifetime];
	}

	public static function getTable($name) {
		static $tables = array();
		
		if (!isset($tables[$name])) {
			JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesearch'.DS.'tables');
			$tables[$name] =& JTable::getInstance($name, 'Table');
		}
		
		return $tables[$name];
	}
	
	public static function &getExtension($option, $apply_filter = 0) {
		static $instances = array();

		$filter_prms = null;
        $cache = self::getCache();

		// Filters params
		$group_id = JRequest::getInt('filter');
		if (is_object($option)) {
			$filter_prms = new JParameter($option->params);
			$option = $option->extension;
		}
		elseif (!empty($group_id)) { //For Html class
			$filter_prms = $cache->getFilterParams($group_id, $option);
		}
		
		if (!isset($instances[$option])) {
			jimport('joomla.html.parameter');
			$file = JPATH_ADMINISTRATOR.'/components/com_acesearch/extensions/'.$option.'.php';
			
			if (!file_exists($file)) {
				$instances[$option] = null;
				
				return $instances[$option];
			}
			
			require_once($file);

			$extensions = $cache->getExtensions($apply_filter);
			$ext_params = new JParameter($extensions[$option]->params);
			
			$class_name = 'AceSearch_'.$option;
			
			$instances[$option] = new $class_name($extensions[$option], $ext_params , $filter_prms);
		}
		
		return $instances[$option];
	}

    public static function getExtraFields($option, $is_module = false) {
		$html = '';

		$xml_file = JPATH_ACESEARCH_ADMIN.'/extensions/'.$option.'.xml';

		$xml =& JFactory::getXMLParser('Simple');
		if (!$xml->loadFile($xml_file)) {
			unset($xml);
			return $html;
		}

		if (is_null($xml)) {
			unset($xml);
			return $html;
		}

		$manifest =& $xml->document;

        $fields_xml = $manifest->getElementByPath('fields');
		if (!is_a($fields_xml, 'JSimpleXMLElement') || (count($fields_xml->children()) == 0)) {
			return $html;
		}

		$extensions = self::getCache()->getExtensions();
		$params = new JParameter($extensions[$option]->params);

		if ($params->get('handler', '1') == '2') {
			return $html;
		}

		$custom_name = $params->get('custom_name', '');
		if (!empty($custom_name)) {
			$name = $custom_name;
		} else {
			$name = $extensions[$option]->name;
		}

		$filter_params = null;
		$group_id = JRequest::getInt('filter');
		if (!empty($group_id)) {
			$filter_params = AcesearchCache::getFilterParams($group_id, $extension);
		}

		$html_class = new AcesearchHTML($option, $params, $is_module, $filter_params);

        $html = $html_class->getExtraFields($fields_xml, $name);

        return $html;
    }

    public static function &getClass($class, $options = null) {
        static $instances = array();

		if (!isset($instances[$class])) {
			require_once(JPATH_ADMINISTRATOR.'/components/com_acesearch/library/'.$class.'.php');

            $class_name = 'Acesearch'.ucfirst($class);
			$instance[$class] = new $class_name($options);
		}

		return $instances[$class];
    }
}