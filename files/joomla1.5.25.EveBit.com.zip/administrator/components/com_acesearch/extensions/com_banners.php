<?php
/*
* @package		AceSearch
* @subpackage	Banners
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSearch_com_banners extends AcesearchExtension {
	
	public function getResults() {
		$cats = $items = array();
		$items = self::_getItems();
	
		$cat = parent::getInt('category');
		if ($this->admin && empty($cat) && $this->params->get('search_categories', '1') == '1') {
			$cats = parent::_getCategories('com_banner');
		}
		
		$results = array_merge($items, $cats);
		
		return $results;
	}
	
	protected function _getItems() {
		$where = parent::getSearchFieldsWhere('b.name:name, b.description:description');
		if (empty($where)){
			return array();
		}
		
		if ($this->site) {
			$where[] = 'b.showBanner = 1';
		}
		
		parent::getFilterWhere($where, array('category' => 'b.catid'));
		
		$where = (count($where) ? ' WHERE ' . implode(' AND ', $where) : '');
		
		$order_by = parent::getOrder();
		
		$identifier = parent::getIdentifier();
		
		$relevance = parent::getRelevance(array('title' => 'b.name', 'desc' => 'b.description'));
		
		$query = "SELECT {$identifier}, {$relevance}, b.bid AS id, b.name, b.description, b.date, b.clicks AS hits, c.title AS category".
		" FROM #__banner AS b LEFT JOIN #__categories AS c ON b.catid = c.id".
		" {$where}{$order_by}";
		
		return AceDatabase::loadObjectList($query, '', 0, parent::getSqlLimit());
	}
	
	public function _getItemURL(&$item) {
		if ($this->site){				
			$item->link = 'index.php?option=com_banners&task=click&bid='.$item->id . parent::getItemid(array('task'=>'click'));
		}
		else {
			$item->link = 'index.php?option=com_banners&task=edit&cid[]='.$item->id;
		}
    }
	
	public function _getCategoryURL(&$cat) {
		if ($this->admin) {
			$cat->link = 'index.php?option=com_categories&section=com_banner&task=edit&cid[]='.$cat->id.'&type=other';
		}
	}
	
	public function getCategoryList($apply_filter = '0') {
		return parent::_getCategoryList('com_banner', $apply_filter);
	}
}