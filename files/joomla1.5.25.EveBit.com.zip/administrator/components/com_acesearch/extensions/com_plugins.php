<?php
/*
* @package		AceSearch
* @subpackage	Plugins
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		http://www.joomace.net/company/license
*/

// No Permission
defined('_JEXEC') or die('Restricted access');

class AceSearch_com_plugins extends AcesearchExtension{

	public function getResults() {
		$results = self::_getItems();
		
		return $results;
	}

	protected function _getItems() {
		$where = parent::getSearchFieldsWhere('name');
		if (empty($where)){
			return array();
		}
		
		$where = (count($where) ? ' WHERE ' . implode(' AND ', $where): '');
		
		$order_by = parent::getOrder();
		
		$identifier = parent::getIdentifier();
		
		$relevance = parent::getRelevance(array('title' => 'name'));
		
		$query = "SELECT {$identifier}, {$relevance}, id, name, 0 AS date, 0 AS hits".
		" FROM #__plugins".
		" {$where}{$order_by}";
		
		return AceDatabase::loadObjectList($query, '', 0, parent::getSqlLimit());
	}
	
	public function _getItemURL(&$item) {			
		$item->link = 'index.php?option=com_plugins&view=plugin&client=site&task=edit&cid[]='.$item->id;
    }
}