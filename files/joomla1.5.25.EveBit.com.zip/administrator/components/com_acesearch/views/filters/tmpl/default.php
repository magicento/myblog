<?php
/**
* @version		1.5.0
* @package		AceSearch
* @subpackage	AceSearch
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//No Permision
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<table align="center">
	<tr>
		<td nowrap="nowrap">
			<br/><b><?php echo JText::_('COM_ACESEARCH_COMMON_PRO_VERSION'); ?></b><br/><br/>
		</td>
	</tr>
	<tr>
		<td width="505">
			<a href="http://www.joomace.net/joomla-extensions/acesearch" target="_blank">
			<img border="0" src="http://www.joomace.net/images/stories/acesearch/acesearch_packages.png" />
			</a>
		</td>
	</tr>
</table>