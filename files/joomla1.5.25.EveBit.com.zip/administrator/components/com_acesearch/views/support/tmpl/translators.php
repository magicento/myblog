<?php
/**
* @version		1.5.0
* @package		AceSEARCH
* @subpackage	AceSEARCH
* @copyright	2009-2010 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die('Restricted access');
?>

<div id="editcell">
	<table class="adminform">
		<tr>
			<td align="left" width="50px">
				<b>Code</b>
			</td>
			<td align="left" width="100px">
				<b>Language</b>
			</td>
			<td align="left">
				<b>Translator</b>
			</td>
		</tr>
		<tr>
			<td align="left">
				en-GB
			</td>
			<td align="left">
				English
			</td>
			<td align="left">
				<a href="http://www.joomace.net" target="_blank">JoomAce LLC</a>
			</td>
		</tr>
	</table>
</div>