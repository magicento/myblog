<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', '3.3.13');
define('AKEEBA_DATE', '2012-01-29');