<?php
/**
 * CategoryBlock Joomla! 1.5 Native Component
 * @version 1.1.5
 * @author DesignCompass corp< <admin@designcompasscorp.com>
 * @link http://www.designcompasscorp.com
 * @license GNU/GPL
 **/


defined('_JEXEC') or die('Restricted access');

$document = &JFactory::getDocument();
$document->addScript( 'modules/mod_categoryblock/categoryblock.js' );


require_once(JPATH_SITE.DS.'components'.DS.'com_categoryblock'.DS.'includes'.DS.'render.php');

		$catid=$params->get( 'catid' );
	
		$layoutsettings=new CategoryBlockSettings();
		$layoutsettings->getSettings($params);
		
		$cbm=new CategoryBlockMisc;
		$cbm->layoutsettings=&$layoutsettings;
		
		
		$rows=$cbm->getArticles('catid='.$catid);
		$pagination=$cbm->getPagination();
				
//echo '<form action="" method="post" name="modcatalogblock" id="modcatalogblock">';

$modulecssstyle=$params->get( 'modulecssstyle' );
$blockcssstyle=$params->get( 'blockcssstyle' );
$content_width_real=$params->get( 'modulewidth' );

$articleslimit=(int)$params->get( 'limit' );
$skipnarticles=(int)$params->get( 'skipnarticles' );

$overflow=$params->get( 'overflow' );
$widthinpx=true;


$content_width=$params->get( 'modulewidth' );
if(strpos($content_width,'%')===false)
	$widthinpx=true;
else
{
	$widthinpx=false;
	
	$content_width_real=(int)str_replace('%','',$content_width_real);
	
}	

if($overflow=='scroll' or $overflow=='scroll-x' or $overflow=='scroll-y')
	$content_width=$content_width_real-17;
else
{
	$content_width=$content_width_real;
	
	
}



$content_height=(int)$params->get( 'moduleheight' );


if($content_width<100)
	$content_width=100;
		




$column_width=floor($content_width/$layoutsettings->columns);

//$categorytitle='Category';
	/*if($cbm->TotalRows>5 and ($layoutsettings->pagination==2 or $layoutsettings->pagination==3))
	{
			$result.='
	<table cellpadding="0" cellspacing="0" width="100%" >
        <tr height="30">
                <td width="'.$content_width.'" valign="top">'.JText::_( 'SHOW' ).': '.$pagination->getLimitBox("").'</td>
                <td align="center" valign=top>'.$pagination->getPagesLinks("").'<br></td>
                <td width="'.$content_width.'" valign="top"></td>
        </tr>
    </table>
		';
	}
	
	echo $result;
	$result='';*/
	
	
if($content_height!=0)
{
	if($overflow=='autoflow-slow' or $overflow=='autoflow-normal' or $overflow=='autoflow-fast')
	{
		echo '
		
		';
	}
	else
	{
		if($overflow=='scroll')
			$overflowcase='overflow:scroll;';
		elseif($overflow=='scroll-x')
			$overflowcase='overflow: -moz-scrollbars-horizontal;overflow-x: auto;overflow-y: hidden;';
		elseif($overflow=='scroll-y')
			$overflowcase='overflow: -moz-scrollbars-vertical;overflow-x: hidden;overflow-y: auto;';
			
		if($widthinpx)
			echo '<div style="width:'.$content_width_real.'px;height:'.$content_height.'px;'.$overflowcase.';'.$modulecssstyle.'">';
		else
			echo '<div style="width:'.$content_width_real.';height:'.$content_height.'px;'.$overflowcase.';'.$modulecssstyle.'">';
	}
	
}
else
{
	if($widthinpx)
		echo '<div style="width:'.$content_width_real.'px;'.$modulecssstyle.' ">';
	else
		echo '<div style="width:'.$content_width_real.';'.$modulecssstyle.' ">';
}	
	


	/*if($cbm->TotalRows>5 and ($layoutsettings->pagination==2 or $layoutsettings->pagination==3))
	{
			$result.='
	<table cellpadding="0" cellspacing="0" width="100%" >
        <tr height="30">
                <td width="'.$content_width.'" valign="top">'.JText::_( 'SHOW' ).': '.$pagination->getLimitBox("").'</td>
                <td align="center" valign=top>'.$pagination->getPagesLinks("").'<br></td>
                <td width="'.$content_width.'" valign="top"></td>
        </tr>
    </table>
		';
	}	*/

	$result.='';

	$result.='
	<table border="0" width="'.$content_width.($widthinpx ? '' : '%').'" cellspacing="0" cellpadding="'.$layoutsettings->padding.'">
	<tbody>
	';
	
	
	
    $tr=0;
		
	$count=0;
	$catresult='';
	
	
	
	foreach($rows as $row)
	{
		if($count>=$skipnarticles)
		{
			if($tr==0)
				$catresult.='<tr>';
						
			    $catresult.='<td width="'.$column_width.($widthinpx ? '' : '%').'" valign="top" '.($blockcssstyle!='' ? 'style="'.$blockcssstyle.'"' : '').'>';
			
				$catresult.=$cbm->render($row);
		
				$catresult.='</td>';
				
		
			$tr++;
			if($tr==$layoutsettings->columns)
			{
				$catresult.='
								</tr>
							';
		
				$tr	=0;
		
			}
		}
		
		$count++;
		
		if($count>=$articleslimit+$skipnarticles and $articleslimit!=0)
			break;
		
	}	
		if($tr>0)
				$catresult.='<td colspan="'.($layoutsettings->columns-$tr).'">&nbsp;</td></tr>';
	  	

	  
	  
       $result.=$catresult.'</tbody>
        
    </table>
	';
	

	
	if($overflow=='autoflow-slow' or $overflow=='autoflow-normal' or $overflow=='autoflow-fast')
	{
		if($overflow=='autoflow-slow')
			$speed=1;
			
		if($overflow=='autoflow-normal')
			$speed=2;
			
		if($overflow=='autoflow-fast')
			$speed=5;
			
//
		if($widthinpx)
		{
			echo '<div style="position: relative;width:'.$content_width_real.'px;overflow:hidden;height:'.$content_height.'px;'.$modulecssstyle.';">';
			echo '
		<div id="MODCategoryBlock'.$module->id.'_Div1" name="MODCategoryBlock'.$module->id.'_Div1"  style="position: absolute;display: block;top: 0px;width:'.$content_width_real.'px;">'.$result.'</div>
		<div id="MODCategoryBlock'.$module->id.'_Div2" name="MODCategoryBlock'.$module->id.'_Div2"  style="position: absolute;display: none;top: 0px;width:'.$content_width_real.'px;">'.$result.'</div>';
		}
		else
		{
			echo '<div style="position: relative;width:'.$content_width_real.'%;overflow:hidden;height:'.$content_height.'px;'.$modulecssstyle.';">';
			echo '
		<div id="MODCategoryBlock'.$module->id.'_Div1" name="MODCategoryBlock'.$module->id.'_Div1" style="position: absolute;display: block;top: 0px;width:'.$content_width_real.'%;">'.$result.'</div>
		<div id="MODCategoryBlock'.$module->id.'_Div2" name="MODCategoryBlock'.$module->id.'_Div2" style="position: absolute;display: none;top: 0px;width:'.$content_width_real.'%;">'.$result.'</div>';
		}	
		
	echo '
	</div>';
	

	echo '
	
	<script language="javascript">
		var MODCategoryBlock'.$module->id.'_height = 0;
		var MODCategoryBlock'.$module->id.'_position=0;
		var MODCategoryBlock'.$module->id.'_turn=1;
		
		function MODCB'.$module->id.'_Move()
		{
			
			
			var y=MODCategoryBlock'.$module->id.'_position-'.$speed.';
			var h=MODCategoryBlock'.$module->id.'_height;
			
			if(y<=-h)
			{
				MODCategoryBlock'.$module->id.'_turn++;
				if(MODCategoryBlock'.$module->id.'_turn>2)
					MODCategoryBlock'.$module->id.'_turn=1;
					
				
				var hidden_idx=0;
				if(MODCategoryBlock'.$module->id.'_turn==1)
					hidden_idx=2;
				else
					hidden_idx=1;
				
				var Hidden_Obj=document.getElementById("MODCategoryBlock'.$module->id.'_Div"+hidden_idx);
				Hidden_Obj.style.display="none";
				
				y=0;
			}
			
			var hidden_idx=0;
			if(MODCategoryBlock'.$module->id.'_turn==1)
				hidden_idx=2;
			else
				hidden_idx=1;
			
			//if(y<=h)
			//{
				
				var Hidden_Obj=document.getElementById("MODCategoryBlock'.$module->id.'_Div"+hidden_idx);
				if(Hidden_Obj.style.display=="none")
				{
					Hidden_Obj.style.display="block";
				}
				
				Hidden_Obj.style.top=(y+h)+"px";
				
			//}
			
			
			
			var Shown_Obj=document.getElementById("MODCategoryBlock'.$module->id.'_Div"+MODCategoryBlock'.$module->id.'_turn);
			
			Shown_Obj.style.top=y+"px";
			
			
			MODCategoryBlock'.$module->id.'_position=y;
			setTimeout("MODCB'.$module->id.'_Move()", 100);
		}
		function MODCB'.$module->id.'_Start()
		{
			var h=document.getElementById("MODCategoryBlock'.$module->id.'_Div1").offsetHeight;
			MODCategoryBlock'.$module->id.'_height=h;
		
			if( h >'.$content_height.')
			{
				setTimeout("MODCB'.$module->id.'_Move()", 100);
			}
		}
		
		//Add module to start list
		cbmodarray[cbmodarray.length]="MODCB'.$module->id.'_Start()";
		
		
			
		
	</script>
	';
	}
	else
		echo '
	
	'.$result.'
	</div>';
	
	
	
		/*if($cbm->TotalRows>5 and ($layoutsettings->pagination==2 or $layoutsettings->pagination==3))
	{
			$result.='
	<table cellpadding="0" cellspacing="0" width="100%" >
        <tr height="30">
                <td width="'.$content_width.'" valign="top">'.JText::_( 'SHOW' ).': '.$pagination->getLimitBox("").'</td>
                <td align="center" valign=top>'.$pagination->getPagesLinks("").'<br></td>
                <td width="'.$content_width.'" valign="top"></td>
        </tr>
    </table>
		';
	}	*/
	
	echo $cbm->SubRenderer($cbm->mainframel.$cbm->l);
	
	
	//echo '</form>'.$this->cbm->SubRenderer($this->cbm->mainframel.$this->cbm->l);	
	
	
	


?>

