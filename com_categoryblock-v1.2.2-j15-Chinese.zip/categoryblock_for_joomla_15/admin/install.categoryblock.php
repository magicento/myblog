<?php
/**
 * CategoryBlock Joomla! 1.5 Native Component
 * @version 1.2.2
 * @author DesignCompass corp< <admin@designcompasscorp.com>
 * @link http://www.designcompasscorp.com
 * @license GNU/GPL
 **/

// no direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install()
{
	jimport('joomla.filesystem.file');

	$filestodelete=array();

	//Modules 
	$filestodelete[]=JPATH_SITE.DS.'modules'.DS.'mod_categoryblock'.DS.'index.html';
	$filestodelete[]=JPATH_SITE.DS.'modules'.DS.'mod_categoryblock'.DS.'mod_categoryblock.php';
	$filestodelete[]=JPATH_SITE.DS.'modules'.DS.'mod_categoryblock'.DS.'mod_categoryblock.xml';
	$filestodelete[]=JPATH_SITE.DS.'modules'.DS.'mod_categoryblock'.DS.'categoryblock.js';
	$filestodelete[]=JPATH_SITE.DS.'modules'.DS.'mod_categoryblock';
	
	
	foreach($filestodelete as $file)
	{
		if(file_exists($file))
		{
			if(is_dir($file))
				rmdir($file);
				
			else
				unlink($file);
		}
		
	}	
	
		
	rename(JPATH_SITE.DS.'components'.DS.'com_categoryblock'.DS.'module',JPATH_SITE.DS.'modules'.DS.'mod_categoryblock');
	
	
	if (file_exists(JPATH_SITE.DS."components".DS."com_categoryblock".DS."categoryblock.php"))
       	{

//****************************************************
		echo '<h1>Category Block 1.2.2 installed succesfully</h1>
		<p>For more info go to Components/Category Block/Documentation.</p>';
		

//****************************************************
		echo '
		<div style="text-align:right;"><a href="http://www.designcompasscorp.com/index.php?option=com_content&view=article&id=508&Itemid=709" target="_blank"><img src="../components/com_customflash/images/compasslogo.png" border=0></a></div>';
	}
	else
	{
		echo '<font color="red">Sorry, something went wrong while installing Category Block to your web site</font>';
	}
		
		
	$db	= & JFactory::getDBO();
	
	//Add module
	$query = 'SELECT count(*) FROM #__modules WHERE `module`="mod_categoryblock"';
	$db->setQuery( $query );
	$total_rows = $db->loadResult();
	if($total_rows==0)
	{
		//add module
		
		$query ='INSERT `#__modules` SET '
			.' `title`="Category Block", '
			.' `position`="left", '
			.' `published`=0, '
			.' `module`="mod_categoryblock", '
			.' `params`=""';
			
		$db->setQuery( $query );
		if (!$db->query())    die( $db->stderr());
		
		
		//Check menu Items
		$query = 'SELECT id FROM #__modules WHERE '
			.' `title`="Category Block" AND'
			.' `module`="mod_categoryblock" AND'
			.' `position`="left" AND'
			.' `published`=0'
			.' LIMIT 1';
			
		//Add menu Items	
		$db->setQuery( $query );
		$rows = $db->loadObjectList();
		
		if(count($rows)==1)
		{
			$id=$rows[0]->id;
			
			$query = 'SELECT count(*)  FROM #__modules_menu WHERE moduleid='.$id;
			$db->setQuery( $query );
			$total_rows = $db->loadResult();
			if($total_rows==0)
			{
				$query ='INSERT `#__modules_menu` SET `menuid`=0, `moduleid`='.$id;
				$db->setQuery( $query );
				if (!$db->query())    die( $db->stderr());
			}
		}
		else
			echo '<p>Database error, cannot add module</p>';
		
		
	}


}	
	
?>
