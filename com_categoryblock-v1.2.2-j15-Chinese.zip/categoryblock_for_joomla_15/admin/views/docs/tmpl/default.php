<?php
/**
* CategoryBlock Joomla! 1.5 Native Component
* @version 1.2.2
* @author DesignCompass corp <admin@designcompasscorp.com>
* @link http://www.designcompasscorp.com
* @license GNU/GPL **/

defined('_JEXEC') or die('Restricted access');

?>


<a href='http://extensions.designcompasscorp.com/index.php/category-block' target='_blank'><img src='../components/com_categoryblock/images/compasslogo.png' border='0' align='right'></a>
<h2>Category Block <span style='font-size: 8pt;'>v 1.2.2</span> EXTENDED VERSION</h2>


<p>The extension to show an articles in a blog mode, this component extracts first photo and first few words from the article, to make a nice description with "Read More..." link. There is a lot of settings like number of columns, styles etc. So it's very good replacement for the built-in Joomla category/section blog layout.

</p>
<p>Module added with mouse scroll and auto floating effects.</p>


<p>From version to version, whats new:</p>

<ul>
    <li>1.2.2 Open in a new window (optional), with or without navigation added, image (in text wrap mode) link fixed.</li>
    <li>1.2.1 Versions for Joomla 1.5 and 1.6 have the same functionality. Title link fixed (for website installed not into root folder).</li>
    <li>1.2.0 Leading Article and default image options has been added. Image proportion rare bug fixed.</li>
    <li>1.1.9 Image proportion rare bug fixed.</li>
    <li>1.1.8 Readmore link for non SEF websites fixed.</li>
    <li>1.1.7 SEF link creation, XHTML validation. Thanx to Daniel Pardons.</li>
    <li>1.1.6 Minor fixes.</li>
    <li>1.1.5 Minor fixes.</li>
    <li>1.1.4 Module width fixed, scroll bars now automatic. Title issue fixed for sections and categories.</li>
    <li>1.1.3 Pagination in Category view has been fixed. Turn On/Off for "Read more" and "Title" added.</li>
    <li>1.1.2 Uninstall fixed</li>
    <li>1.1.1 Date format option added, Language pack fixed. Creates default module after extension installation.</li>
    <li>1.1.0 Language file added for: English, Spanish, German, French, Greek, Russian and Czech languages.</li>
    <li>1.0.9 Module flow effect fixed, component block and module style available.</li>
    <li>1.0.8 Minor fix.</li>
    <li>1.0.7 SEF support - supports Search Engine Friendly URLs.</li>
    <li>1.0.6 Module added with mouse scroll and auto floating effects.</li>
    <li>1.0.4 Now it will not show deleted or unpublished articles.</li>
    <li>1.0.1 First release.</li>

</ul>



<p><b>Free and Extended version comparison table:</b><p>


  
<table border='1' cellpadding='3' cellspacing='0'>
    <tr style='font-size:12px;'>
        <th style='width:400px;' width='400'>Feature</th>
        <th align='center'><b>Free</b></th>
        <th align='center'><b>Extended</b>
<br>

<a href='http://extensions.designcompasscorp.com/index.php/category-block/542' target='_blank'>Buy Now</a>



</th>
    </tr>

    <tr>
        <td style='width:400px;' width='400'>Our Logo</td>
        <td align='center'>Yes</td>
        <td align='center'>No Logo</td>
    </tr>

    
    <tr>
        <td>Category Title</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Category Description</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Columns Setting</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Padding</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Ordering</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Order Direction</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Target Window (new)</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Block Layouts</td>
        <td align='center'>3</td>
        <td align='center'>3</td>
    </tr>
    
    
    <tr>
        <td>Word Count Limit</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Character Count Limit</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Image Size Settings</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Module CSS</td>
        <td align='center'>-</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Block CSS</td>
        <td align='center'>-</td>
        <td align='center'>+</td>
    </tr>
    
    
    
    <tr>
        <td>Article Title</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Article Title CSS</td>
        <td align='center'>-</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Creation Date</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Date CSS</td>
        <td align='center'>-</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Date Format Settings</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Read More Link</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Read More Link CSS</td>
        <td align='center'>-</td>
        <td align='center'>+</td>
    </tr>
    
    <tr>
        <td>Go to comments link</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Pagination</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    
    
    <tr>
        <td>Leading Article</td>
        <td align='center'>+</td>
        <td align='center'>+</td>
    </tr>
    

    
</table>
    

			








<br/>


<p style='text-align: left;'>Thank you for the purchase of Extended - Logo Free version of Category Block.</a></p>


