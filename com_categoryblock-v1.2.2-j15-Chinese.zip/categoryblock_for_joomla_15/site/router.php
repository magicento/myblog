<?php
/**
 * CategoryBlock Joomla! 1.5 Native Component
 * @version 1.1.7
 * @author DesignCompass corp< <admin@designcompasscorp.com>
 * @link http://www.designcompasscorp.com
 * @license GNU/GPL
 **/

// no direct access
defined('_JEXEC') or die('Restricted access');
function CategoryBlockBuildRoute(&$query) {

       $segments = array();
       if(isset($query['view']))
       {
                $segments[] = $query['view'];
                unset( $query['view'] );
				
				
       }

       return $segments;
	
}
function CategoryBlockParseRoute($segments) {

  $vars = array();
       switch($segments[0])
       {
            case 'categoryblock':
                       $vars['view'] = 'categoryblock';
                       break;
				
			case 'sectionblock':
                       $vars['view'] = 'sectionblock';
                       break;	
              
       }
       return $vars;

}
?>