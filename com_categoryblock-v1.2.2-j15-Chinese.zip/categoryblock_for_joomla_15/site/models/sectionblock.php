<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla modelitem library
jimport('joomla.application.component.modelitem');

jimport( 'joomla.application.menu' );


 
/**
 * CategoryBlock Model
 */
class CategoryBlockModelSectionBlock extends JModel
{
        /**
         * @var string msg
         */
        protected $categoryblockcode;
		protected $limitstart;
		protected $limit;
        
		function __construct()
		{
			parent::__construct();
			
			$mainframe = JFactory::getApplication();
			// Get pagination request variables
			$this->limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$this->limitstart = JRequest::getVar('limitstart', 0, '', 'int');
 
			// In case limit has been changed, adjust it
			$this->limitstart = ($this->limit != 0 ? (floor($this->limitstart / $this->limit) * $this->limit) : 0);
 
			if($this->limit>100)
				$this->limit=100;
				
							
			return;
	
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);
		
		
			$this->limitstart=$this->getState('limitstart');
			$this->limit=$this->getState('limit');	
		}
		
		
		/**
         * Get the message
         * @return string The message to be displayed to the user
         */
		
		
        public function getcategoryblockCode() 
        {
                if (!isset($this->categoryblockcode)) 
                {
                        
						$app		= JFactory::getApplication();
						$params	= $app->getParams();
						
						$sectionid=(int)$params->get( 'sectionid' );
                        
                        
                        //Build flash movie
                        if($sectionid!=0)
                        {
								$this->categoryblockcode='';
								
                                require_once(JPATH_SITE.DS.'components'.DS.'com_categoryblock'.DS.'includes'.DS.'render.php');
								
								
								
								
                                $align=$params->get( 'align' );
								
								
								
		
								$layoutsettings=new CategoryBlockSettings();
								$layoutsettings->getSettings($params);
		
								$cbm=new CategoryBlockMisc;
								$cbm->layoutsettings=&$layoutsettings;
				
								$cbm->limitstart=$Model->limitstart;
								$cbm->limit=$Model->limit;			
		
		
								$rows=$cbm->getArticles('sectionid='.$sectionid);
		
								$pagination=$cbm->getPagination();

						
								// render code
						
						
								/////////////////////////////////////////////
								
								
								//name="catalogblock" id="catalogblock"
								$this->categoryblockcode.='<form action="" method="post" >';
		
								if($cbm->TotalRows>5 and ($layoutsettings->pagination==2 or $layoutsettings->pagination==3))
								{
										$this->categoryblockcode.='
										<table cellpadding="0" cellspacing="0" width="100%" >
									    <tr height="30">
								            <td width="140" valign="top">'.JText::_( 'SHOW' ).': '.$pagination->getLimitBox("").'</td>
								            <td align="center" valign=top>'.$pagination->getPagesLinks("").'<br></td>
								            <td width="140" valign="top"></td>
										</tr>
										</table>
										';
								}


								$content_width='100';
								$column_width=floor($content_width/$layoutsettings->columns);
								$modulecssstyle=$params->get( 'modulecssstyle' );
								$blockcssstyle=$params->get( 'blockcssstyle' );

								$result='';

								if($modulecssstyle!='')
										$result.='<div style="'.$modulecssstyle.' ">';


								if($params->get( 'showtitle' ) or $params->get( 'showcatdesc' ))
								{
										$categorytitle='';
										$categorycatdesc='';
										//if($cbm->getCategoryTitle($sectionid,$categorytitle,$categorycatdesc))
										if($cbm->getSectionTitle($sectionid,$categorytitle,$categorycatdesc))
										{
												$result.='<h1>'.$categorytitle.'</h1>';
												$result.='<div>'.$categorycatdesc.'</div>';
										}
								}


								$result.='
										<table border="0" width="'.$content_width.'%" cellpadding="'.$layoutsettings->padding.'">
										<tbody>
								';
	
								
	
								$tr=0;
		
								$count=0;
								$catresult='';
										
								foreach($rows as $row)
								{
										//echo 'row->language='.$row->language.'<br>';
				
										if($tr==0)
											$catresult.='<tr>';
						
										$catresult.='<td width="'.$column_width.'%" valign="top" align="center" '.($blockcssstyle!='' ? 'style="'.$blockcssstyle.'"' : '').'>';
			
										$catresult.=$cbm->render($row);
		
										$catresult.='</td>';
				
										$tr++;
										if($tr==$layoutsettings->columns)
										{
												$catresult.='</tr>';
		
												$tr	=0;
					
												$count++;
		
										}
								}//foreach($rows as $row)
								if($tr>0)
										$catresult.='<td colspan="'.($layoutsettings->columns-$tr).'">&nbsp;</td></tr>';
	  	

								$result.=$catresult.'</tbody></table>';
	
								if($modulecssstyle!='')
										$result.='</div>';
	
								$this->categoryblockcode.=$result;

								//pagination
								if($cbm->TotalRows>5 and ($layoutsettings->pagination==1 or $layoutsettings->pagination==3))
								{
												$this->categoryblockcode.='
    <table cellpadding="0" cellspacing="0" width="100%" >
        <tr height="30">
                <td width="140" valign="top">'.JText::_( 'SHOW' ).': '.$pagination->getLimitBox("").'</td>
                <td align="center" valign="top">'.$pagination->getPagesLinks("").'<br></td>
                <td width="140" valign="top"></td>
        </tr>
    </table>
		';
								}
	
	
								$this->categoryblockcode.='</form>';
								
								if(count($rows)>0)
										$this->categoryblockcode.=$cbm->SubRenderer($cbm->mainframel.$cbm->l);	
	
								
								/////////////////////////////////////////////

                        
                        }//if($sectionid!=0)
                        
                        
                }//if (!isset($this->categoryblockcode)) 
                return $this->categoryblockcode;
        }
}
