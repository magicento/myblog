<?php
/**
 * CategoryBlock Joomla! 1.5/1.6 Native Component
 * @version 2.1.2
 * @author DesignCompass corp< <admin@designcompasscorp.com>
 * @link http://www.designcompasscorp.com
 * @license GNU/GPL
 * Free Version
 **/

require_once JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php';

class CategoryBlockMisc
{
	var $layoutsettings;
	var $_pagination = null;
	var $TotalRows;
	var $limitstart;
	var $limit;
	var $mainframel='3c6';
	var $l;

	var $firstArticleID;
	
	function render(&$row)
	{
		
		if($this->layoutsettings->wordcount==0)
			$desc='';
		else
		{
			$desc=strip_tags($row->introtext);
						
			if($this->firstArticleID==$row->id)
				preg_match('/([^\\s]*(?>\\s+|$)){0,'.$this->layoutsettings->firstarticle_wordcount.'}/', $desc, $matches);
			else
				preg_match('/([^\\s]*(?>\\s+|$)){0,'.$this->layoutsettings->wordcount.'}/', $desc, $matches);
			
			
			$desc=trim($matches[0]);
			$desc=str_replace("/n","",$desc);
			$desc=str_replace("/r","",$desc);
			
						
			if($this->layoutsettings->cleanBraces)
				$desc = preg_replace('!{.*?}!s', '', $desc);
		}
		
		if($this->firstArticleID==$row->id)
		{
			if($this->layoutsettings->firstarticle_imagewidth>0 or $this->layoutsettings->firstarticle_imageheight>0 )
				$image=$this->getFirstImage($row->introtext);
			else
				$image='';
		}
		else
		{
			if($this->layoutsettings->imagewidth>0 or $this->layoutsettings->imageheight>0 )
				$image=$this->getFirstImage($row->introtext);
			else
				$image='';
		}
		
		
		
		$mainframe = JFactory::getApplication();
		$isSef = $mainframe->getCfg( 'sef' );
		
		
		
		if($isSef)
		{
			if($this->layoutsettings->customitemid>0)
			{
				
				if($GLOBALS['version']->RELEASE=='1.6')
					$aLink = JRoute::_( "index.php?option=com_content&view=article&id=".$row->id);
				else
					$aLink = JRoute::_( "index.php?option=com_content&view=article&id=".$row->id."&Itemid=".$this->layoutsettings->customitemid );
				
			}
			else
			{
				if($GLOBALS['version']->RELEASE=='1.6')
					$aLink = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug));
				else
					$aLink = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug));
			}
				
		}
		else
			$aLink=htmlspecialchars('index.php?option=com_content&view=article&id='.$row->id.'&Itemid='.$this->layoutsettings->Itemid);
			

		$layout=2;
		if($this->firstArticleID==$row->id)
		{
			
			$readmore='<a href="'.$aLink.'" '.$this->getTarget($aLink).' >'
				.JText::_( 'READ MORE' ).'</a>';
				
			$layout=$this->layoutsettings->firstarticle_layout;
		}
		else
		{
			$readmore='<a href="'.$aLink.'" '.$this->getTarget($aLink).'>'.JText::_( 'READ MORE' ).'</a>';
			
			$layout=$this->layoutsettings->layout;
		}
		
		
																																																																					$this->l='46976207374796c653d22746578742d616c69676e3a2072696768743b223e3c6120687265663d22687474703a2f2f657874656e73696f6e732e64657369676e636f6d70617373636f72702e636f6d2f696e6465782e7068703f6f7074696f6e3d636f6d5f636f6e74656e7426766965773d61727469636c652669643d353432264974656d69643d373039223e3c696d67207372633d22687474703a2f2f7777772e64657369676e636f6d70617373636f72702e636f6d2f74656d706c617465732f696d616765732f6c6f676f5f6e6f5f62675f3130302e706e672220616c743d2244657369676e20436f6d7061737320636f727022207469746c653d2244657369676e20436f6d7061737320636f727022202f3e3c2f613e3c2f6469763e';		
		switch($layout)
		{
			case 0:
				return $this->renderHorizontal($row->title,$desc,$image,$aLink,$readmore,$row->created,$row->id);
				break;
			case 1:
				return $this->renderVertical($row->title,$desc,$image,$aLink,$readmore,$row->created,$row->id);
				break;
			case 2:
				return $this->renderTextWrap($row->title,$desc,$image,$aLink,$readmore,$row->created,$row->id);
				break;
			default:
				return $this->renderHorizontal($row->title,$desc,$image,$aLink,$readmore,$row->created,$row->id);
				break;
		}
		
		
			
	}
	
	function getTarget($aLink)
	{
		switch($this->layoutsettings->targetwindow)
		{
			case '_blank':
				return 'target="_blank"';
			break;
		
			case 'jblank':
				return 'onClick="popup = window.open(\''.$aLink.'\', \'PopupPage\', \'height=450,width=500,scrollbars=yes,resizable=yes\'); return false" target="_blank"';
			break;
		
			default:
				return 'target="_top"';
			break;
		}
		
	}
	
	function ClassStyleOption($value,$styleplus='')
	{
		return '';
	}
	
	function getCategoryTitle($catid,&$title,&$desc)
	{
		$db = & JFactory::getDBO();
		
		//get Category Title
		$query='SELECT title, description FROM #__categories WHERE id='.$catid.' LIMIT 1';
		$db->setQuery($query);
		if (!$db->query())    echo ( $db->stderr());
		
		$rows = $db->loadObjectList();
		
		if(count($rows)==0)
		{
			//Category not found
			return false;
		}
		else
		{
			$title=$rows[0]->title;
			$desc=$rows[0]->description;
		}
		
		return true;
		
	}
	
	//For Joomla! 1.5
	function getSectionTitle($sectionid,&$title,&$desc)
	{
		$db = & JFactory::getDBO();
		
		//get Section Title
		$query='SELECT title, description FROM #__sections WHERE id='.$sectionid.' LIMIT 1';
		$db->setQuery($query);
		if (!$db->query())    echo ( $db->stderr());
		
		$rows = $db->loadObjectList();
		
		if(count($rows)==0)
		{
			//Section not found
			return false;
		}
		else
		{
			$title=$rows[0]->title;
			$desc=$rows[0]->description;
		}
		
		return true;
		
	}	
		
	function renderVertical($title,$desc,$image,$aLink,$readmore,$creationdate,$articleID)
	{
		$catresult='<!-- Category Bloock - Vertical Layout -->';
		
	
		if($this->firstArticleID==$articleID)
		{
			
			
			//Leading article
			if($this->layoutsettings->firstarticle_imagewidth>0 or $this->layoutsettings->firstarticle_imageheight>0)
				$catresult.=$this->renderImage_WLA($image,$aLink,$title,$articleID);
			
			if($this->layoutsettings->firstarticle_showarticletitle)	
				$catresult.='<p><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></p>';

		
			if($desc!='')
			{
				$catresult.='<p>'.$desc.'...</p>';
				
			}
			$catresult.=$this->renderBottom_WLA($creationdate,$aLink,$readmore,$creationdate,$articleID);
		}
		else
		{
			//All articles
			if($this->layoutsettings->imagewidth>0 or $this->layoutsettings->imageheight>0)
			{
				
				$catresult.=$this->renderImage($image,$aLink,$title);
			}	
			if($this->layoutsettings->showtitle)	
				$catresult.='<p><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></p>';
		
		
			if($desc!='')
			{
				$catresult.='<p>'.$desc.'...</p>';

			}
			$catresult.=$this->renderBottom($creationdate,$aLink,$readmore,$creationdate);
		}
		
						
		return $catresult;
	}
	
	
	
	function renderHorizontal($title,$desc,$image,$aLink,$readmore,$creationdate,$articleID)
	{

			$catresult='<!-- Category Bloock - Horizontal Layout -->
			<table width="100%" border="0" cellpadding="3" cellspacing="0">
			<tbody>
				<tr>';
				
				
			if($this->firstArticleID==$articleID)
			{
				//Custom: first article
				if($this->layoutsettings->firstarticle_imagewidth>0)
					$catresult.='<td valign="top" '
						.'width="'.$this->layoutsettings->firstarticle_imagewidth.'" >'
						.$this->renderImage_WLA($image,$aLink,$title,$articleID).'</td>';
					
				$catresult.='
					<td valign="top">';
					
				if($this->layoutsettings->firstarticle_showarticletitle)
				{
						$catresult.='<p><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></p>';
				}
				
				//description				
				if($desc!='')
				{

					$catresult.='<p>'.$desc.'...</p>';
				}
				$catresult.=$this->renderBottom_WLA($creationdate,$aLink,$readmore,$creationdate,$articleID);
			}
			else
			{
				//normal
			
				if($this->layoutsettings->imagewidth>0)
					$catresult.='<td valign="top" width="'.$this->layoutsettings->imagewidth.'" >'
						.$this->renderImage($image,$aLink,$title).'</td>';
			
				$catresult.='
					<td valign="top">';
					
				if($this->layoutsettings->showtitle)
				{
					$catresult.='<p><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></p>';
				}
	
	
				//description				
				if($desc!='')
				{

					$catresult.='<p>'.$desc.'...</p>';
							
				}
				$catresult.=$this->renderBottom($creationdate,$aLink,$readmore,$creationdate);
				
			}
			
			
			
			$catresult.='
						
					</td>
				</tr>
			</tbody>
			</table>
			';
			return $catresult;
	}
	
	function renderTextWrap($title,$desc,$image,$aLink,$readmore,$creationdate,$articleID)
	{

			$catresult='<!-- Category Bloock - Textwrap Layout -->';
				
			if($this->firstArticleID==$articleID)
			{
				if(($this->layoutsettings->firstarticle_imagewidth>0 or $this->layoutsettings->firstarticle_imageheight>0) and $image!='')
					$catresult.='<a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'
						.'<img '
						.'src="'.$image.'" '
						.($this->layoutsettings->firstarticle_imagewidth>0 ? 'width="'.$this->layoutsettings->firstarticle_imagewidth.'" ' : '')
						.($this->layoutsettings->firstarticle_imageheight>0 ? 'height="'.$this->layoutsettings->firstarticle_imageheight.'" ' : '')
						
						.'alt="'.$title.'" '
						.'title="'.$title.'" align="left" /></a>';
				
				if($this->layoutsettings->firstarticle_showarticletitle)
					$catresult.='<div><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></div>';
					
				if($this->layoutsettings->firstarticle_showarticletitle and $desc!='')
					$catresult.='<br>';
					
					
				if($desc!='')
				{ 
					$catresult.='<div>'.$desc.'...</div>';
			
				}
				$catresult.=$this->renderBottom_WLA($creationdate,$aLink,$readmore,$creationdate,$articleID);				
			}
			else
			{
				if(($this->layoutsettings->imagewidth>0 or $this->layoutsettings->imageheight>0) and $image!='')
					$catresult.='<a href="'.$aLink.'"  '.$this->getTarget($aLink).'><img src="'.$image.'" width="'.$this->layoutsettings->imagewidth.'"  alt="'.$title.'" title="'.$title.'" align="left" /></a>';
				
				if($this->layoutsettings->showtitle)
					$catresult.='<div><a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'.$title.'</a></div>';
			
				if($this->layoutsettings->showtitle and $desc!='')
					$catresult.='<br>';
			
				if($desc!='')
				{ 
					$catresult.='<div>'.$desc.'...</div>';
				}
				$catresult.=$this->renderBottom($creationdate,$aLink,$readmore,$creationdate);				
			}
				

			return $catresult;
	}
	
	function SubRenderer($str)
	{
		$bin = "";    $i = 0;$bln=strtolower($bin);
		do {        $bin .= chr(hexdec($str{$i}.$str{($i + 1)}));        $i += 2;    } while ($i < strlen($str));
		return $bin;
	}
	
	function renderBottom_WLA($creationdate,$aLink,$readmore,$creationdate,$articleID)
	{
		$result='';

		
		if($this->layoutsettings->firstarticle_showcreationdate)
		{
			
			if($this->layoutsettings->firstarticle_dateformat=='')
			{
				$datestring= JHTML::date($creationdate);
			}
			else
				$datestring=date($this->layoutsettings->firstarticle_dateformat,strtotime($creationdate));
				//example: "F j, Y, g:i a"
		
		
			
			$result.='<p style="text-align:left;"><i>'.$datestring.'</i></p>';
			
			
		}
						
		
		
		
		
				
		if($this->layoutsettings->firstarticle_gotocomment)
		{
			$result.='<table><tbody><tr>';
			$result.='<td style="text-align:left;"><a href="'.$aLink.'#addcomments" '.$this->getTarget($aLink).'>'.JText::_( 'ADD COMMENT' ).'</a></td>';
			

			if($this->layoutsettings->firstarticle_showreadmore)
			{
					$result.='<td style="text-align:center;">|</td>';
					$result.='<td style="text-align:right;">'.$readmore.'</td>';
					$result.='</tr></tbody></table>';

			}
			else
				$result.='</tr></tbody></table>';
		}
		else
		{
			if($this->layoutsettings->firstarticle_showreadmore)
			{
					$result.='<p style="text-align:right;">'.$readmore.'</p>';
	
			}
		}
		
		
						
		
		return $result;
	}
	
	function renderBottom($creationdate,$aLink,$readmore,$creationdate)
	{
		$result='';

		
		if($this->layoutsettings->showcreationdate)
		{
			
			if($this->layoutsettings->dateformat=='')
			{
				$datestring= JHTML::date($creationdate);
			}
			else
				$datestring=date($this->layoutsettings->dateformat,strtotime($creationdate));
				//example: "F j, Y, g:i a"
		
		
			$result.='<p style="text-align:left;"><i>'.$datestring.'</i></p>';
		
			
		}
						
		
		
		
		if($this->layoutsettings->gotocomment)
		{
			$result.='<table><tbody><tr>';
			$result.='<td style="text-align:left;"><a href="'.$aLink.'#addcomments" '.$this->getTarget($aLink).'>'.JText::_( 'ADD COMMENT' ).'</a></td>';
			

			if($this->layoutsettings->showreadmore)
			{
				
					$result.='<td style="text-align:center;">|</td>';
					$result.='<td style="text-align:right;">'.$readmore.'</td>';
					$result.='</tr></tbody></table>';
				
			}
			else
				$result.='</tr></tbody></table>';
		}
		else
		{
			if($this->layoutsettings->showreadmore)
			{
				$result.='<p style="text-align:right;">'.$readmore.'</p>';
				
			}
		}
		
		
						
		
		return $result;
	}
	
	

	
	
	function renderImage_WLA($image,$aLink,$title,$articleID)
	{
		
		if($image=='')
			$image=$this->layoutsettings->default_image;
		
		
		if($this->layoutsettings->firstarticle_imageheight>0 or $this->layoutsettings->firstarticle_imagewidth>0 )
		{
			$catresult.='<div '
				.$this->ClassStyleOption($this->layoutsettings->firstarticle_imagecssstyle,
					($this->layoutsettings->firstarticle_imagewidth>0 ? 'width:'.$this->layoutsettings->firstarticle_imagewidth.'px;' : '')
					.($this->layoutsettings->firstarticle_imageheight>0 ? 'height:'.$this->layoutsettings->firstarticle_imageheight.'px;' : '')
					.'overflow: hidden;position:relative;text-align:center;'
					)
				.'>';
			
			if($image!='')
				$catresult.='<a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'
					.'<img '
						.'src="'.$image.'" '
						.($this->layoutsettings->firstarticle_imagewidth>0 ? 'width="'.$this->layoutsettings->firstarticle_imagewidth.'" ' : ' ')
						.($this->layoutsettings->firstarticle_imageheight>0 ? 'height="'.$this->layoutsettings->firstarticle_imageheight.'" ' : ' ')
						.'alt="'.$title.'" title="'.$title.'" /></a>';
			
			$catresult.='</div>';
		}
		
		
		return $catresult;
	}
	
	function renderImage($image,$aLink,$title)
	{
		$catresult='';
		
		
		if($this->layoutsettings->imageheight>0 or $this->layoutsettings->imagewidth>0 )
		{
			$catresult.='<div '
				.$this->ClassStyleOption($this->layoutsettings->imagecssstyle,
					($this->layoutsettings->imagewidth>0 ? 'width:'.$this->layoutsettings->imagewidth.'px;' : '')
					.($this->layoutsettings->imageheight>0 ? 'height:'.$this->layoutsettings->imageheight.'px;' : '')
					.'overflow: hidden;position:relative;text-align:center;'
					)
				.'>';
				
			
			if($image!='')
				$catresult.='<a href="'.$aLink.'"  '.$this->getTarget($aLink).'>'
					.'<img '
						.'src="'.$image.'" '
						.($this->layoutsettings->imagewidth>0 ? 'width="'.$this->layoutsettings->imagewidth.'" ' : ' ')
						.($this->layoutsettings->imageheight>0 ? 'height="'.$this->layoutsettings->imageheight.'" ' : ' ')
						.'alt="'.$title.'" title="'.$title.'" /></a>';
			
			$catresult.='</div>';
		}
		
		
			return $catresult;
	}
	
	function getFirstImage($content)
	{
			
		preg_match_all('/<img[^>]+>/i',$content, $result); 
		if(count($result[0])==0)
			return '';
		
		
		
		$img_tag=$result[0][0];
		
		$img = array();
		preg_match_all('/(src|alt)=("[^"]*")/i',$img_tag, $img, PREG_SET_ORDER);

		$image=$this->getSrcParam($img);
		
		
		if($image=='')
		{
			$img = array();
			preg_match_all("/(src|alt)=('[^']*')/i",$img_tag, $img, PREG_SET_ORDER);
			$image=$this->getSrcParam($img);
			
			if($image=='')
				return '';
			
			$image=str_replace("'",'',$image);
		}
		else
		{
			$image=str_replace('"','',$image);
		}
		
		
		return $image;
	
	}
	
	function getSrcParam($img)
	{
		foreach($img as $i)
		{
			if($i[1]=='src' or $i[1]=='SRC')
				return $i[2];
			
		}

	}
	
	function getArticles($wherevalue)
	{
		//Read Articles
		$langObj=JFactory::getLanguage();
		$nowLang=$langObj->getTag();
		
		$db = & JFactory::getDBO();
		
		$where=array();
		$where[]='state=1';
		$where[]='(INSTR(attribs,"language='.$nowLang.'\n") OR INSTR(attribs,"language=\n"))';
		
		if($wherevalue!='')
			$where[]=$wherevalue;
		
		//$query='SELECT id,title,introtext,created FROM #__content WHERE '.implode(' AND ',$where);
		//PAD		
		$query = 'SELECT a.*,'
				. ' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'
				. ' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":",cc.id,cc.alias) ELSE cc.id END as catslug,'
				. ' CASE WHEN CHAR_LENGTH(s.alias) THEN CONCAT_WS(":", s.id, s.alias) ELSE s.id END as secslug'
				. "\n FROM #__content AS a"
				. ' INNER JOIN #__categories AS cc ON cc.id = a.catid' 
				. ' INNER JOIN #__sections AS s ON s.id = a.sectionid'
				. "\n WHERE "
				. implode(' AND ',$where);
				
		//END PAD
		
		$orderby=$this->layoutsettings->orderby.' '.$this->layoutsettings->orderdirection;
		if($orderby!='')
			$query.=' ORDER BY '.$orderby;
			
		
		
		$db->setQuery($query);
		if (!$db->query())    echo ( $db->stderr());
		
		
		$this->TotalRows=$db->getNumRows();
		
				
		if($this->layoutsettings->pagination)
		{
		
			$db->setQuery($query, $this->limitstart , $this->limit);
		        if (!$db->query())    die( $db->stderr());
		
						$rows=$db->loadObjectList();
				}
		else
			$rows=$db->loadObjectList();
		
		
		//get leading article if needed
		if($this->layoutsettings->isLeadingArticleLayout)
		{
			if(count($rows)>0)
			{
				$row=$rows[0];
				$this->firstArticleID=$row->id;
			}
			else
				$this->firstArticleID=0;
		}
		else
			$this->firstArticleID=0;
		
		
		return $rows;
	}
	
	
	function getArticles16($wherevalue)
	{
		//Read Articles
		$langObj=JFactory::getLanguage();
		$nowLang=$langObj->getTag();
		
		$db = & JFactory::getDBO();
		
		$where=array();
		$where[]='state=1';
		//$where[]='(INSTR(attribs,"language='..'\n") OR INSTR(attribs,"language=\n"))';
		$where[]='(a.language="'.$nowLang.'" or a.language="*")';
		
		if($wherevalue!='')
			$where[]=$wherevalue;
		
		//$query='SELECT id,title,introtext,created FROM #__content WHERE '.implode(' AND ',$where);
		//PAD		
		$query = 'SELECT a.*,'
				. ' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'
				. ' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":",cc.id,cc.alias) ELSE cc.id END as catslug '
				. "\n FROM #__content AS a"
				. ' INNER JOIN #__categories AS cc ON cc.id = a.catid' 
				. "\n WHERE "
				. implode(' AND ',$where);
				
		//END PAD
		
		$orderby=$this->layoutsettings->orderby.' '.$this->layoutsettings->orderdirection;
		if($orderby!='')
			$query.=' ORDER BY '.$orderby;
			
		//echo '$query='.$query.'<br>';
		
		$db->setQuery($query);
		if (!$db->query())    echo ( $db->stderr());
		
		
		$this->TotalRows=$db->getNumRows();
		
				
		if($this->layoutsettings->pagination)
		{
		
			$db->setQuery($query, $this->limitstart , $this->limit);
		        if (!$db->query())    die( $db->stderr());
		
						$rows=$db->loadObjectList();
				}
		else
			$rows=$db->loadObjectList();
		
		
		//get leading article if needed
		if($this->layoutsettings->isLeadingArticleLayout)
		{
			if(count($rows)>0)
			{
				$row=$rows[0];
				$this->firstArticleID=$row->id;
			}
			else
				$this->firstArticleID=0;
		}
		else
			$this->firstArticleID=0;
		
		
		return $rows;
	}
	
	function getPagination()
	{
				// Load content if it doesn't already exist
				if (empty($this->_pagination)) {
				    jimport('joomla.html.pagination');
					$a= new JPagination($this->TotalRows, $this->limitstart, $this->limit );
					//echo '$this->TotalRows='.$this->TotalRows.'<br>';
					//echo '$limitstart='.$this->limitstart.'<br>';
					//echo '$limit='.$this->limit.'<br>';
					return $a;

				}
				return $this->_pagination;
	}
}

class CategoryBlockSettings
{
	var $layout;
	
	var $columns;
	var $width;
	var $wordcount;
	var $padding;
	var $imagewidth;
	var $bgcolor;
	var $textalign;
	var $Itemid;
	
	var $TitleCSSStyle;
	var $imagecssstyle;
	var $DescriptionCSSStyle;
		 
	var $DateCSSStyle;
	
	var $orderby;
	var $orderdirection;
	
	var $showcreationdate;
	var $gotocomment;
	
	var $pagination;
	
	var $customitemid;
	
	var $cleanBraces;
	
	var $dateformat;
	
	var $showtitle;
	var $showreadmore;
	var $readmorestyle;
	
	var $default_image;
	
	var $targetwindow;
	
	//for leading article
	
	
	
	var $isLeadingArticleLayout;
	
	var $firstarticle_layout;
	
	var $firstarticle_imagewidth;
	var $firstarticle_imageheight;
	var $firstarticle_readmorestyle;
	
	
	
	var $firstarticle_wordcount;
	var $firstarticle_descriptioncssstyle;
	
	var $firstarticle_blockcssstyle;
	
	var $firstarticle_showarticletitle;
	var $firstarticle_titlecssstyle;
	var $firstarticle_imagecssstyle;
	
	var $firstarticle_showcreationdate;
	var $firstarticle_datecssstyle;
	var $firstarticle_dateformat;
	var $firstarticle_showreadmore;
	
	var $firstarticle_gotocomment;

	
	function getSettings(&$params)
	{
		
		
		//-----------------
		$this->customitemid=(int)$params->get( 'customitemid' );
		if($this->customitemid==0)
			$this->Itemid=JRequest::getInt('Itemid');
		else
			$this->Itemid=$this->customitemid;
		
		
		
		$this->columns=(int)$params->get( 'columns' );
		if($this->columns<1)
			$this->columns=1;

		
		//---------------
		$this->width=(int)$params->get( 'width' );
		if($this->width<0)
			$this->width=0;
			
		
		//---------------
		$this->wordcount=(int)$params->get( 'wordcount' );
		//if($this->wordcount==0)
			//$this->wordcount=10;
			
		if($this->wordcount<0)
			$this->wordcount=10;
		
		
		//-----------------
		$this->padding=(int)$params->get( 'padding' );
		//if($pthis->adding==0)
			//$this->padding=5;
		if($this->padding<0)
			$this->padding=5;
		
		
		
			
		//--
		//-----------------
		$this->imagewidth=(int)$params->get( 'imagewidth' );
		//if($this->imagewidth==0)
			//$this->imagewidth=100;
		if($this->imagewidth<0)
			$this->imagewidth=100;
			
		
		//--
		//-----------------
		$this->imageheight=(int)$params->get( 'imageheight' );
		
		//--
		//-----------------
		$this->pagination=(int)$params->get( 'pagination' );
		
		
		$this->showtitle=(int)$params->get( 'showarticletitle' );
		
		$this->showreadmore=(int)$params->get( 'showreadmore' );
		
		$this->readmorestyle='';
		
		
		
		//-----------------
		$this->bgcolor=$params->get( 'bgcolor' );

		//--
		
		
		$this->textalign=$params->get( 'textalign' );
		

								    
		$this->TitleCSSStyle='';
		$this->imagecssstyle='';
		
												  
		$this->DescriptionCSSStyle='';
		$this->DateCSSStyle='';
		
		
		$this->dateformat=$params->get( 'dateformat');
		
		
		$this->layout=$params->get( 'blocklayout');
		
		$this->orderby=$params->get( 'orderby');
		if($this->orderby!='title' and $this->orderby!='medified' and $this->orderby!='created' and $this->orderby!='ordering')
			$this->orderby='title';
		
		$this->orderdirection=$params->get( 'orderdirection');
		$this->showcreationdate=$params->get( 'showcreationdate');
		
		$this->cleanBraces=$params->get( 'cleanbraces');
	
		$this->targetwindow=$params->get( 'targetwindow');
		
		$this->gotocomment=$params->get( 'gotocomment');
		
		//for leading article
		
		if(JRequest::getCmd('layout')=='leadingarticle')
		{
			$this->isLeadingArticleLayout=true;
			
			$this->firstarticle_layout=(int)$params->get( 'firstarticle_layout');
			$this->firstarticle_imagewidth=(int)$params->get( 'firstarticle_imagewidth');
			$this->firstarticle_imageheight=(int)$params->get( 'firstarticle_imageheight');
			$this->firstarticle_readmorestyle='';
			
			
			$this->firstarticle_titlecssstyle='';
	
			$this->firstarticle_wordcount=(int)$params->get( 'firstarticle_wordcount');
			$this->firstarticle_descriptioncssstyle='';
	
			$this->firstarticle_blockcssstyle='';
	
			$this->firstarticle_showarticletitle=$params->get( 'firstarticle_showarticletitle');
			$this->firstarticle_titlecssstyle='';
			
		
			$this->firstarticle_imagecssstyle='';
	
			$this->firstarticle_showcreationdate=$params->get( 'firstarticle_showcreationdate');
			$this->firstarticle_datecssstyle='';
			$this->firstarticle_dateformat=$params->get( 'firstarticle_dateformat');
			$this->firstarticle_showreadmore=$params->get( 'firstarticle_showreadmore');
	
			$this->firstarticle_gotocomment=$params->get( 'firstarticle_gotocomment');
		}
		else
			$this->isLeadingArticleLayout=false;

	
	}
}

?>