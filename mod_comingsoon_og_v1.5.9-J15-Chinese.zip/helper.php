<?php
/**
* @version		$Id: helper.php 10857 2008-08-30 06:41:16Z willebil $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modComingSoon_OgHelper
{
  
	function getList(&$params)
	{
		global $mainframe;

		$db			=& JFactory::getDBO();
		$user		=& JFactory::getUser();
		$userId		= (int) $user->get('id');

    if ($params->get('mode')==2){
    $count=1;
    } else {
		$count		= (int) $params->get('count', 5);
		}
		$offset	= $mainframe->getCfg('offset') * 3600;
		$dst = (int) $params->get('dst',0);
		if ($params->get('own_format')){
      $dateformat = $params->get('own_format');
    } else {
      $dateformat = $params->get('date_format');
    }
    $sminutes = $params->get('sminutes');
		$catid		= trim( $params->get('catid') );
		$secid		= trim( $params->get('secid') );
		$show_front	= 1;
		$aid		= $user->get('aid', 0);

		$contentConfig = &JComponentHelper::getParams( 'com_content' );
		$access		= !$contentConfig->get('show_noauth');

		$nullDate	= $db->getNullDate();

		$date =& JFactory::getDate();
		$now = $date->toMySQL();

    $state		= (int) $params->get('state', 1);
    switch ($state){
      case 1:
        $astate = 'a.state = 1';
        break;
      case 2:
        $astate = 'a.state = 0';
        break;
      case 3:
        $astate = 'a.state <= 1';   
    }
    
		$where		= $astate
			. ' AND ( a.publish_up > '.$db->Quote($now).' )'
			;

		// User Filter
		switch ($params->get( 'user_id' ))
		{
			case 'by_me':
				$where .= ' AND (created_by = ' . (int) $userId . ' OR modified_by = ' . (int) $userId . ')';
				break;
			case 'not_me':
				$where .= ' AND (created_by <> ' . (int) $userId . ' AND modified_by <> ' . (int) $userId . ')';
				break;
		}

		// Ordering
		switch ($params->get( 'ordering' ))
		{
			case 'm_dsc':
			default:
				$ordering		= 'a.publish_up ASC, a.created DESC';
				break;
			case 'c_asc':
				$ordering		= 'a.created ASC';
				break;
			case 'c_dsc':
			  $ordering		= 'a.created DESC';
				break;
		}

		if ($catid)
		{
			$ids = explode( ',', $catid );
			JArrayHelper::toInteger( $ids );
			$catCondition = ' AND (cc.id=' . implode( ' OR cc.id=', $ids ) . ')';
		}
		if ($secid)
		{
			$ids = explode( ',', $secid );
			JArrayHelper::toInteger( $ids );
			$secCondition = ' AND (s.id=' . implode( ' OR s.id=', $ids ) . ')';
		}
    
		// Content Items only
		$query = 'SELECT a.*, ' .
			' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
			' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug'.
			' FROM #__content AS a' .
			($show_front == '0' ? ' LEFT JOIN #__content_frontpage AS f ON f.content_id = a.id' : '') .
			' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
			' INNER JOIN #__sections AS s ON s.id = a.sectionid' .
			' WHERE '. $where .' AND s.id > 0' .
			($access ? ' AND a.access <= ' .(int) $aid. ' AND cc.access <= ' .(int) $aid. ' AND s.access <= ' .(int) $aid : '').
			($catid ? $catCondition : '').
			($secid ? $secCondition : '').
			($show_front == '0' ? ' AND f.content_id IS NULL ' : '').
			' AND s.published = 1' .
			' AND cc.published = 1' .
			' ORDER BY '. $ordering;
		$db->setQuery($query, 0, $count);
		$db->query();
		$rows = $db->loadObjectList();

    
		$i		= 0;
		$lists	= array();
		foreach ( $rows as $row )
		{
			$lists[$i]->text = htmlspecialchars( $row->title );
			$lists[$i]->p_up = JHTML::_('date', (strtotime( $row->publish_up ) /*+ $offset*/), $dateformat);
			$lists[$i]->rem  = (strtotime(htmlspecialchars( $row->publish_up ))) - strtotime($now) - $dst;
			$lists[$i]->rem2 = modComingSoon_OgHelper::remaining($lists[$i]->rem,$sminutes);
			$i++;
		}

		return $lists;
	}
	
	function getK2items(&$params){
  
  		if ($params->get('mode')==2){
      $count=1;
      } else {
		  $count		= (int) $params->get('count', 5);
		  }
  		$catid		= trim( $params->get('catid') );
  		if ($params->get('own_format')){
      $dateformat = $params->get('own_format');
      } else {
        $dateformat = $params->get('date_format');
      }
      $sminutes = $params->get('sminutes');

  		$date =& JFactory::getDate();
  		$now = $date->toMySQL();

      $db			=& JFactory::getDBO();
  		
      $state		= (int) $params->get('state', 1);
      switch ($state){
        case 1:
          $astate = 'i.published = 1';
          break;
        case 2:
          $astate = 'i.published = 0';
          break;
        case 3:
          $astate = 'i.published <= 1';   
      }
    
		  $where = $astate;
		  
		  switch ($params->get( 'ordering' ))
		  {
			case 'm_dsc':
			default:
				$ordering		= 'i.publish_up ASC, i.created DESC';
				break;
			case 'c_asc':
				$ordering		= 'i.created ASC';
				break;
			case 'c_dsc':
			  $ordering		= 'i.created DESC';
				break;
		  }
		  
  		$user		=& JFactory::getUser();
  		$aid		= $user->get('aid', 0);  		
			$query = " SELECT i.*, c.name AS categoryname,c.id AS categoryid, c.alias AS categoryalias, c.params AS categoryparams";
			$query .= " FROM #__k2_items as i LEFT JOIN #__k2_categories c ON c.id = i.catid";
			$query .= " WHERE {$where} AND i.access <= {$aid} AND i.trash = 0 AND c.published = 1 AND c.access <= {$aid} AND c.trash = 0";
			$query .= " AND i.publish_up >= ".$db->Quote($now);
			$query .= " AND i.catid IN(".$catid.")";
			$query .= " ORDER BY {$ordering}";

      $db->setQuery($query, 0, $count);
			$items = $db->loadObjectList();
			
      $lists	= array();
  		foreach ( $items as $row )
  		{
  			
  			$lists[$i]->text = htmlspecialchars( $row->title );
  			$lists[$i]->p_up = JHTML::_('date', (strtotime( $row->publish_up ) /*+ $offset*/), $dateformat) ;
  			$lists[$i]->rem  = (strtotime(htmlspecialchars( $row->publish_up ))) - strtotime($now) - $dst;
  			$lists[$i]->rem2 = modComingSoon_OgHelper::remaining($lists[$i]->rem,$sminutes);
  			$i++;
  		}
        
      return $lists;
  }
	
	function getHide(&$params)
	{
		global $mainframe;
		$hide=(int)$params->get('hide',1);
		return $hide;
	}
	
	function remaining($seconds,$mmode) {
      $week = 604800;
      $day = 86400;
      $hour = 3600;
      $minute = 60;
      $weeks = (int)($seconds / $week);
      $days = ((int)($seconds / $day))-($weeks*7);
      $daysonly = (int)($seconds / $day);
      $hours = ((int)($seconds / $hour))-($weeks*168)-($days*24);
      $minutes = ((int)($seconds / $minute))-($weeks*10080)-($days*1440)-($hours*60);
      if ($daysonly==1){
        $dayv=$daysonly.JText::_('DAY').", ";
        } elseif ($daysonly>1) {
        $dayv=$daysonly.JText::_('DAYS').", ";
        } else {
        $dayv="";
        };
      if ($hours==1){
        $hourv=$hours.JText::_('HOUR').", ";
        } elseif ($hours>1){
        $hourv=$hours.JText::_('HOURS').", ";
        } else {
        $hourv="";
        };
      if ($minutes==1){
        $minutev=$minutes.JText::_('MINUTE');
        } elseif ($minutes>1){
        $minutev=$minutes.JText::_('MINUTES');
        } else {
        $minutev="";
        };
        if ($mmode==2 || ($mmode == 3 && $seconds>$week)||($mmode == 4 && $seconds>$day)||($mmode == 5 && $seconds>$hour)){
        return $dayv.$hourv." ".JText::_('YET');
        } else {
        return $dayv.$hourv.$minutev." ".JText::_('YET');
        }
       }
}
?>