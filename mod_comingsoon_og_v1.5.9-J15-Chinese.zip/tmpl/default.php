<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php if($params->get('alt_title')) : ?>
<h4><?php echo $params->get('alt_title'); ?></h4>
<?php endif; ?>
<?php if ($params->get('mode')==1) : ?>
<?php if(!count($list)):?>
<span class="small"><?php echo $params->get('nothing'); ?></span>
<?php else: ?>
<ul class="comingsoon_og<?php echo $params->get('moduleclass_sfx'); ?>">
<?php foreach ($list as $item) :  ?>
	<li class="comingsoon_og<?php echo $params->get('moduleclass_sfx'); ?>">
		<a class="comingsoon_og<?php echo $params->get('moduleclass_sfx'); ?>">
			<?php echo $item->text; ?></a>
			<?php if ($params->get('show_date') == 1) : ?>
        <span style="display: block" class="small"><?php echo $item->p_up; ?></span>
      <?php endif; ?>
      <?php if ($params->get('show_rem') == 1) : ?>
        <span style="display: block;" class="small"><?php echo $item->rem2; ?></span>
      <?php endif; ?>
	</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
<?php else : ?>
<div>
<?php foreach ($list as $item) :  ?>
<?php if ($params->get('show_date') == 1) : ?>
<span style="display: block" class="small"><?php echo $item->p_up; ?></span>
<?php endif; ?>
<?php if ($params->get('show_rem') == 1) : ?>
<span style="display: block;" class="small"><?php echo $item->rem2; ?></span>
<?php endif; ?>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php if($params->get('footer')) : ?>
<div class="comingsoonfooter">
  <span class="small" ><a style="color:<?php echo $params->get('footercolor'); ?>" href="http://www.obolgraf.hu/comingsoon-og/en">Powered by Comingsoon OG</a></span>
</div>
<?php endif; ?>