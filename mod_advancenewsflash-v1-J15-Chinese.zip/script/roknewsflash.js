/**
 * RokNewsFlash Module
 *
 * @package		Joomla
 * @subpackage	RokNewsFlash Module
 * @copyright Copyright (C) 2009 RocketTheme. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see RT-LICENSE.php
 * @author RocketTheme, LLC
 *
 */

eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('o R=9 17({16:1.2,m:{H:J,Q:15,w:18},19:4(b,c){3.1c(c);3.t=$(b)||14;3.t.A({\'B\':3.v.n(3),\'C\':3.k.n(3)});3.l=3.t.1a(\'1d 11\');3.8=0;3.h=[];3.l.X().F(\'K\',\'Y\');o d=3;3.l.13(4(a,i){a.F(\'K\',\'Z\');3.h[i]=9 10.1b(a,\'M\',{w:3.m.w,1f:4(){d.r=J},1e:4(){d.r=1o}}).1q(1);j(!i)6;a.F(\'M\',0)},3);j(3.m.H)3.O();3.x=\'v\';1l.D(\'1g\',3.k.n(3));6 3},O:4(){o a=9 G(\'E\',{\'I\':\'H\'}).1h(3.t);3.z=9 G(\'E\',{\'I\':\'5-e\'}).L(a).N(\'<p>&1k;-</p>\');3.y=9 G(\'E\',{\'I\':\'5-7\'}).L(a).N(\'<p>-&1j;</p>\');3.z.D(\'P\',3.T.n(3));3.y.D(\'P\',3.7.n(3));3.z.A({\'B\':4(){3.s(\'5-e-u\')},\'C\':4(){3.f(\'5-e-u\').f(\'5-e-g\')},\'U\':4(){3.s(\'5-e-g\')},\'V\':4(){{3.f(\'5-e-g\')}}});3.y.A({\'B\':4(){3.s(\'5-7-u\')},\'C\':4(){3.f(\'5-7-u\').f(\'5-7-g\')},\'U\':4(){3.s(\'5-7-g\')},\'V\':4(){{3.f(\'5-7-g\')}}});6 3},T:4(){j(3.r)6 3;o a=(!3.8)?3.l.S-1:3.8-1;3.h[3.8].q(0);3.h[a].q(1);3.8=a;6 3},7:4(){j(3.r)6 3;o a=(3.8==3.l.S-1)?0:3.8+1;3.h[3.8].q(0);3.h[a].q(1);3.8=a;6 3},k:4(){j(3.x==\'k\')6 3;3.x=\'k\';3.W=3.7.1i(3.m.Q+3.m.w,3);6 3},v:4(){3.x=\'v\';$1m(3.W);6 3}});R.1p(9 12,9 1n);',62,89,'|||this|function|control|return|next|current|new|||||prev|removeClass|down|fx||if|play|news|options|bind|var|span|start|transitioning|addClass|element|hover|stop|duration|status|arrowNext|arrowPrev|addEvents|mouseenter|mouseleave|addEvent|div|setStyle|Element|controls|class|true|position|inject|opacity|setHTML|addControls|click|delay|RokNewsFlash|length|previous|mousedown|mouseup|timer|getParent|relative|absolute|Fx|li|Options|each|null|2000|version|Class|800|initialize|getElements|Style|setOptions|ul|onComplete|onStart|domready|injectTop|periodical|gt|lt|window|clear|Events|false|implement|set'.split('|'),0,{}))
