<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php 
$height = $params->get('module_height');
?>
<div id="mynewsflash" style="position: relative;height: <?php echo $height; ?>px">
<ul style="position: relative; list-style-type: none; padding: 0; margin:0; ">
<?php for ($i = 0, $n = count($list); $i < $n; $i ++) :
	modAdvanceNewsFlashHelper::renderItem($list[$i], $params, $access);
	if ($n > 1 && (($i < $n - 1) || $params->get('showLastSeparator'))) : ?>
 	<?php endif; ?>
<?php endfor; ?>
</ul>
</div>