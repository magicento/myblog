<?php
/**
* 
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
* THIS MOdULE IS MODIFICATON OF DEFAULT JOOMLA MODULE mod_newsfalsh and mod_roknewsflash MODULE from rockettheme.com
* 
* distributed under GPL License
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

$params->set('intro_only', 1);
$params->set('hide_author', 1);
$params->set('hide_createdate', 0);
$params->set('hide_modifydate', 1);


// Disable edit ability icon
$access = new stdClass();
$access->canEdit	= 0;
$access->canEditOwn = 0;
$access->canPublish = 0;

$list = modAdvanceNewsFlashHelper::getList($params, $access);

// check if any results returned
$items = count($list);
if (!$items) {
	return;
}

$layout = 'default';
$layout = JFilterInput::clean($layout, 'word');
$path = JModuleHelper::getLayoutPath('mod_advancenewsflash', $layout);
if (file_exists($path)) {
	require($path);
}

JHTML::_('behavior.mootools');
$doc = &JFactory::getDocument();
$doc->addScript(JURI::Root(true).'/modules/mod_advancenewsflash/script/roknewsflash.js');

$jsinit = "window.addEvent('domready', function() {
		var x = new RokNewsFlash('mynewsflash', {
			controls: 1,
			delay: 2500,
			duration: 600
		});
	});";
		
$doc->addScriptDeclaration($jsinit);
	
$document =& JFactory::getDocument();
$document->addStyleSheet(JURI::Root(true)."/modules/mod_advancenewsflash/script/roknewsflash.css");
