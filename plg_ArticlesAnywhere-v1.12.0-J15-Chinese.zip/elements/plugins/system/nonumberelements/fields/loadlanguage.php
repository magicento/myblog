<?php
// No direct access
defined( '_JEXEC' ) or die();

// Redirect to new NoNumber! Framework
require_once str_replace( DS.'nonumberelements'.DS, DS.'nnframework'.DS, __FILE__ );