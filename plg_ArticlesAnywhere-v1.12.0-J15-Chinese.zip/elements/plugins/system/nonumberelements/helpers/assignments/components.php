<?php
// No direct access
defined( '_JEXEC' ) or die();

// Redirect to new NoNumber! Framework
require_once str_replace( 'nonumberelements', 'nnframework', __FILE__ );

class NoNumberElementsAssignmentsComponents extends NNFrameworkAssignmentsComponents
{
}