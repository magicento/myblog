<?php
/**
 * Language Include File (Simplified Chinese)
 * Can overrule set variables used in different elements
 *
 * @package     Articles Anywhere
 * @version     1.10.2
 *
 * @author      Peter van Westen <peter@nonumber.nl>
 * @link        http://www.nonumber.nl
 * @copyright   Copyright © 2011 NoNumber! All Rights Reserved
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @translation Peter van Westen <peter@nonumber.nl> NoNumber!
 */

// Ensure this file is being included by a parent file
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Variables that can be overruled:
 * $image
 * $title
 * $description
 * $help
 */

$description = '
		<p>本插件可以让你方便地在网站任何位置插入文章。</p>
		<p>你可以使用下列语法来插入文章：<br />
		使用文章的标题： {<span style="color:green">article</span> <span style="color:blue">Some article</span>}...{/<span style="color:green">article</span>}<br />
		使用文章的别名：{<span style="color:green">article</span> <span style="color:blue">some-article</span>}...{/<span style="color:green">article</span>}<br />
		使用文章的 ID：{<span style="color:green">article</span> <span style="color:blue">123</span>}...{/<span style="color:green">article</span>}</p>
		<p>在上述标记中，你可以使用不同标记来插入不同的文章数据/详情：<br />
		{<span style="color:red">text</span>} (文章全文： introtext+fulltext)<br />
		{<span style="color:red">readmore</span>} (“阅读全文”链接)<br />
		{<span style="color:red">url</span>} (文章的网址)<br />
		{<span style="color:red">introtext</span>}<br />
		{<span style="color:red">fulltext</span>}<br />
		{<span style="color:red">title</span>}<br />
		{<span style="color:red">id</span>}<br />
		或者其它任何可提取的数据（必须与数据表中的列名称相符）</p>
		<p>在显示文章内容（全文，引言，或者正文）时，你可以只显示指定数量的文字：<br />
		{<span style="color:red">text:100</span>} (显示文章全文的前 100 个字符)</p>
		<p>在显示“阅读全文”链接时，你也可以使用自定义的“阅读全文”的说法：<br />
		{<span style="color:red">readmore:继续阅读</span>}</p>
		<p><strong>上面示范中的颜色是为了方便你阅读，在真正插入标记时，不要使用颜色。那样会导致插件失效。</strong></p>
';