<?php
/**
 * Language Include File (Traditional Chinese)
 * Can overrule set variables used in different elements
 *
 * @package     Articles Anywhere
 * @version     1.10.2
 *
 * @author      Peter van Westen <peter@nonumber.nl>
 * @link        http://www.nonumber.nl
 * @copyright   Copyright © 2011 NoNumber! All Rights Reserved
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @translation Peter van Westen <peter@nonumber.nl> NoNumber!
 */

// Ensure this file is being included by a parent file
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Variables that can be overruled:
 * $image
 * $title
 * $description
 * $help
 */

$description = '
		<p>本插件可以讓你方便地在網站任何位置插入文章。</p>
		<p>你可以使用下列語法來插入文章：<br />
		使用文章的標題： {<span style="color:green">article</span> <span style="color:blue">Some article</span>}...{/<span style="color:green">article</span>}<br />
		使用文章的別名：{<span style="color:green">article</span> <span style="color:blue">some-article</span>}...{/<span style="color:green">article</span>}<br />
		使用文章的 ID：{<span style="color:green">article</span> <span style="color:blue">123</span>}...{/<span style="color:green">article</span>}</p>
		<p>在上述標記中，你可以使用不同標記來插入不同的文章資料/細節：<br />
		{<span style="color:red">text</span>} (文章全文： introtext+fulltext)<br />
		{<span style="color:red">readmore</span>} (“閱讀全文”連結)<br />
		{<span style="color:red">url</span>} (文章的網址)<br />
		{<span style="color:red">introtext</span>}<br />
		{<span style="color:red">fulltext</span>}<br />
		{<span style="color:red">title</span>}<br />
		{<span style="color:red">id</span>}<br />
		或者其它任何可提取的資料（必須與資料表中的列名稱相符）</p>
		<p>在顯示文章內容（全文，引言，或者正文）時，你可以只顯示指定數量的文字：<br />
		{<span style="color:red">text:100</span>} (顯示文章全文的前 100 個字符)</p>
		<p>在顯示“閱讀全文”連結時，你也可以使用自定義的“閱讀全文”的說法：<br />
		{<span style="color:red">readmore:繼續閱讀</span>}</p>
		<p><strong>上面示范中的顏色是為了方便你閱讀，在真正插入標記時，不要使用顏色。那樣會導致插件失效。</strong></p>
';