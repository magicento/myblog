<?php
// No direct access
defined( '_JEXEC' ) or die();

require_once dirname(__FILE__) . DS . 'nonumberelements' . DS . 'nonumberelements.php';