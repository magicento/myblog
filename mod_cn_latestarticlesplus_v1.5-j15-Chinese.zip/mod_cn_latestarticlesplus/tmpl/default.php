<?php

/**
 * @version		1.5
 * @package		mod_cn_latestarticlesplus
 * @author    	Caleb Nance
 * @copyright	Copyright (c) 2009 - 2010 CalebNance.com. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 *
 *				default.php
 */
	// no direct access
	defined('_JEXEC') or die('Direct Access to this location is not allowed.'); 
	
	# GET VARIABLES
	$introtext 	= $params->get('introtext', 1);
	$title_size = $params->get('title_size', 'h3');
	$use_li 	= $params->get('use_li', 0);
	$add_rm		= $params->get('add_rm', 1);
	$created_by = $params->get('created_by_show', 0);
	$created = $params->get('created_show', 0);
	
	# CHECK FOR H OR PX
	$title_tag	= strpos($title_size, 'h');
	if(strpos($title_size, 'h') !== false){
		$title_tag_start = '<'.$title_size.'>';
		$title_tag_end = '</'.$title_size.'>';
	}
	else{
		$title_tag_start = '<div style="font-size: '.$title_size.'" >';
		$title_tag_end = '</div><br />';
	}
	
if($use_li == '1') { ?><ul class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"> <?php }else{ ?><div class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"> <?php } ?>
<?php foreach ($list as $item) :  ?>
	<?php if($use_li == '1') { ?><li class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"> <?php }else{ ?> <div class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"> <?php } ?>
		<?php echo $title_tag_start; ?>
        	<a href="<?php echo $item->link; ?>" class="latestnews<?php echo $params->get('moduleclass_sfx'); ?>"><?php echo $item->text; ?></a>
        <?php echo $title_tag_end; ?>
		<?php if($created_by == '1'){echo $item->created_by; }?>
		<?php if($created == '1' & $created == '1'){ echo ' | '; }?>
		<?php if($created == '1'){echo date('D j, Y',$item->created); }?>
		<?php if($created == '1' || $created == '1'){ echo '<br /><br />'; }?>
		<?php if($introtext == '1'){ echo $item->introtext;} ?>
		<?php if($add_rm == '1'){ echo ' <a href="'.$item->link.'" >Read More</a>'; } ?>
	<?php if($use_li == '1') { ?></li><br /><?php }else{ ?></div><br /> <?php } ?>
<?php endforeach; ?>
<?php if($use_li == '1') { ?></ul><?php }else{ ?></div> <?php } ?>