<?php

/**
 * @version		1.5
 * @package		mod_cn_latestarticlesplus
 * @author    	Caleb Nance
 * @copyright	Copyright (c) 2009 - 2010 CalebNance.com. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 *
 *				sections.php
 */
	// no direct access
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');

class JElementSections extends JElement {

  var   $_name = 'Sections';

	function fetchElement($name, $value, &$node, $control_name)
	{
			$db =& JFactory::getDBO();
			$query = "SELECT id, title FROM #__sections WHERE published = '1'";
			$db->setQuery($query);
			$options = $db->loadObjectList();
			$result = '<select name="'.$control_name.'['.$name.'][]" id="'.$name.'">';

		foreach( $options as $option ) {
			if(is_array( $value) ) {
				if( in_array( $option->id, $value ) ) {
					$result .= '<option selected="true" value="" >'.$option->title.' - '.$option->id.'</option>';
				} else {
					$result .= '<option value="" >'.$option->title.'</option>';
				}
			} elseif ( $value ) {
				if( $value == $option->id ) {
					$result .= '<option selected="true" value="" >'.$option->title.' - '.$option->id.'</option>';
				} else {
					$result .= '<option value="" >'.$option->title.' - '.$option->id.'</option>';
				}
			} elseif ( !( $value ) ) {
				$result .= '<option value="" >'.$option->title.' - '.$option->id.'</option>';
			}
		}
		$result .= '</select>';
		return $result;

	}
}
?>