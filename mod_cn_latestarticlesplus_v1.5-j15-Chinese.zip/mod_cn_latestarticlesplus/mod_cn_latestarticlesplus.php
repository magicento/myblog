<?php

/**
 * @version		1.5
 * @package		mod_cn_latestarticlesplus
 * @author    	Caleb Nance
 * @copyright	Copyright (c) 2009 - 2010 CalebNance.com. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 *
 *				mod_cn_latestarticlesplus.php
 */
	// no direct access
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');

	// Include the syndicate functions only once
	require_once (dirname(__FILE__).DS.'helper.php');

	$list = modLatestArticlePlusHelper::getList($params);
	require(JModuleHelper::getLayoutPath('mod_cn_latestarticlesplus'));