<?php

/**
 * @version		1.5
 * @package		mod_cn_latestarticlesplus
 * @author    	Caleb Nance
 * @copyright	Copyright (c) 2009 - 2010 CalebNance.com. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 *
 *				helper.php
 */
	// no direct access
	defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modLatestArticlePlusHelper
{
	function getList(&$params)
	{
		global $mainframe;

		$db				=& JFactory::getDBO();
		$user			=& JFactory::getUser();
		$userId			= (int) $user->get('id');

		$count			= (int) $params->get('count', 5);
		$intro_length 	= $params->get('intro_length', 100);
		$add_dot 		= $params->get('add_dot', 1);
		$catid			= trim( $params->get('catid') );
		$secid			= trim( $params->get('secid') );
		$show_front		= $params->get('show_front', 1);
		$aid			= $user->get('aid', 0);
		$remove_tags	= $params->get('remove_tags', 1);

		$contentConfig 	= &JComponentHelper::getParams( 'com_content' );
		$access			= !$contentConfig->get('show_noauth');
		$nullDate		= $db->getNullDate();
		$date 			=& JFactory::getDate();
		$now 			= $date->toMySQL();

		$where		= 'a.state = 1'
			. ' AND ( a.publish_up = '.$db->Quote($nullDate).' OR a.publish_up <= '.$db->Quote($now).' )'
			. ' AND ( a.publish_down = '.$db->Quote($nullDate).' OR a.publish_down >= '.$db->Quote($now).' )'
			;

		// User Filter
		switch ($params->get( 'user_id' ))
		{
			case 'by_me':
				$where .= ' AND (created_by = ' . (int) $userId . ' OR modified_by = ' . (int) $userId . ')';
				break;
			case 'not_me':
				$where .= ' AND (created_by <> ' . (int) $userId . ' AND modified_by <> ' . (int) $userId . ')';
				break;
		}

		// Ordering
		switch ($params->get( 'ordering' ))
		{
			case 'm_dsc':
				$ordering		= 'a.modified DESC, a.created DESC';
				break;
			case 'c_dsc':
			default:
				$ordering		= 'a.created DESC';
				break;
		}
		if ($catid)
		{
			$ids = explode( ',', $catid );
			JArrayHelper::toInteger( $ids );
			$catCondition = ' AND (cc.id=' . implode( ' OR cc.id=', $ids ) . ')';
		}
		if ($secid)
		{
			$ids = explode( ',', $secid );
			JArrayHelper::toInteger( $ids );
			$secCondition = ' AND (s.id=' . implode( ' OR s.id=', $ids ) . ')';
		}

		// Content Items only
		$query = 'SELECT a.*, ' .
			' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
			' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":", cc.id, cc.alias) ELSE cc.id END as catslug'.
			' FROM #__content AS a' .
			($show_front == '0' ? ' LEFT JOIN #__content_frontpage AS f ON f.content_id = a.id' : '') .
			' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
			' INNER JOIN #__sections AS s ON s.id = a.sectionid' .
			' WHERE '. $where .' AND s.id > 0' .
			($access ? ' AND a.access <= ' .(int) $aid. ' AND cc.access <= ' .(int) $aid. ' AND s.access <= ' .(int) $aid : '').
			($catid ? $catCondition : '').
			($secid ? $secCondition : '').
			($show_front == '0' ? ' AND f.content_id IS NULL ' : '').
			' AND s.published = 1' .
			' AND cc.published = 1' .
			' ORDER BY '. $ordering;
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();
		$i		= 0;
		$lists	= array();
		foreach ( $rows as $row )
		{
			if($row->access <= $aid)
			{
				$lists[$i]->link = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
			} else {
				$lists[$i]->link = JRoute::_('index.php?option=com_user&view=login');
			}
			/* SET TITLE OF ARTICLE */
			$lists[$i]->text = htmlspecialchars( $row->title );
			
			/* SET CREATED OF ARTICLE AND SET PHP READABLE FORMAT OF DATE */
			$lists[$i]->created = strtotime($row->created);
			
			/* SET CREATED BY OF ARTICLE */
			$query = "SELECT name FROM #__users WHERE id=".$row->created_by;
			$db->setQuery($query);
			$created_by = $db->loadRow();
			$lists[$i]->created_by = $created_by['0'];
			
			/* REMOVE IMAGES */
			$introtext = preg_replace("/<img[^>]+\>/i", "", $row->introtext);
			
			/* REMOVE TAGS */
			if($remove_tags == '1'){ 
				$introtext = strip_tags($introtext);
			}
			/* LIMIT STRING */
			$introtext = mb_substr($introtext, 0 , $intro_length); 
			
			/* ADD ... TO THE END? */
			if($add_dot == '1'){ $introtext .= '... ';}
			
			/* SET INTRO TEXT OF ARTICLE */
			$lists[$i]->introtext = $introtext;
			
			$i++;
		}

		return $lists;
	}
}